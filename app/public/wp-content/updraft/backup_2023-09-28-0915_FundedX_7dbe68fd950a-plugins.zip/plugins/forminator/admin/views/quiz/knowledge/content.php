<?php // phpcs:ignoreFile this file only html container for wizard which is handled by js. ?>
<div id="forminator-knowledge-builder"></div>