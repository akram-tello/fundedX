<div class="sui-notice">
    <div class="sui-notice-content">
        <div class="sui-notice-message">
            <i aria-hidden="true" class="sui-notice-icon sui-icon-info sui-md"></i>
            <p><?php echo esc_html( $args['content'] ); ?></p>
        </div>
    </div>
</div>