<div data-dismissible="bialty-rating-120" class="notice bialty-notice notice-success is-dismissible">
    <p class="bialty-p"><?php 
        echo sprintf( wp_kses( __( 'Show support for BIALTY - Bulk Image Alt Text (Alt tag, Alt Attribute) with Yoast SEO + WooCommerce with a 5-star rating » <a href="%s" target="_blank">Click here</a>', 'bialty' ), array(  'a' => array( 'href' => array(), 'target' => array() ) ) ), esc_url( "https://wordpress.org/support/plugin/bulk-image-alt-text-with-yoast/reviews/?rate=5#new-post" ) ); ?>
    </p>
</div>