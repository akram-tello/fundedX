<?php

namespace Forminator\Stripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
