<?php

// Free version footer.
if ( ! FORMINATOR_PRO ) {
	$this->template( 'dashboard/footer-free' );
}
