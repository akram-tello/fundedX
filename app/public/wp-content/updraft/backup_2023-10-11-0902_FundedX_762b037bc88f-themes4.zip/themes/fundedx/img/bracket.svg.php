<svg xmlns="http://www.w3.org/2000/svg" width="73.384" height="247" viewBox="0 0 73.384 247">
  <path id="Path_28624" data-name="Path 28624" d="M26.505,14.656H0V0H39.757V99.187l14.676,11.762,9.542,7.659,1.192.953-.3.439.3.439-1.192.953-9.542,7.659L39.757,140.813V240H0V225.344H26.505V133.338L43.136,120l-16.63-13.338Z" transform="translate(3.5 3.5)" fill="#cacaca" stroke="#fff" stroke-width="7"/>
</svg>
