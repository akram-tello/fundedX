<svg xmlns="http://www.w3.org/2000/svg" width="11.074" height="11.073" viewBox="0 0 11.074 11.073">
  <path id="Subtraction_11" data-name="Subtraction 11" d="M14600.635,9646.873h0l-1.5-1.5,7.624-7.624h-5.5l1.95-1.95h7v7l-1.95,1.955v-5.5l-7.619,7.619Z" transform="translate(-14599.131 -9635.8)" fill="#fff"/>
</svg>
