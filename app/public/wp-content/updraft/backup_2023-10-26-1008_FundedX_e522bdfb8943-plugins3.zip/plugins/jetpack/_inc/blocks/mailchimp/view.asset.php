<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '9af29351156d680f0f96');
