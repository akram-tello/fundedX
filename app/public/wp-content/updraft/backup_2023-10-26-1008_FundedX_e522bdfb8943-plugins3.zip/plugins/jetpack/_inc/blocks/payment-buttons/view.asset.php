<?php return array('dependencies' => array('wp-polyfill'), 'version' => '257313f331a51a3c1041');
