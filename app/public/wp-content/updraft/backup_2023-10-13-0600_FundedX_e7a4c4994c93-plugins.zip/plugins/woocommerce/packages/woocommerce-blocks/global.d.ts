// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
declare let __webpack_public_path__: string;
