<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '370afbbf2555ce9affe6');
