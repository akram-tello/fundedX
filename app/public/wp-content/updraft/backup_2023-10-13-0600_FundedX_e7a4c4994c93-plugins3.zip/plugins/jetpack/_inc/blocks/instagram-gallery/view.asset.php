<?php return array('dependencies' => array('wp-polyfill'), 'version' => '9da4ea6d1647394ae32f');
