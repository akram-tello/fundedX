<?php return array('dependencies' => array('wp-polyfill'), 'version' => '6349062f7798f75e185e');
