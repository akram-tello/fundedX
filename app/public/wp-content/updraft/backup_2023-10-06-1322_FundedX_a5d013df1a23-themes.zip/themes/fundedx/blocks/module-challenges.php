<?php 
    $className = !empty($block['className']) ? $block['className'] : null;
    $heading = get_field('heading');
    $content = get_field('content');
    $cta = get_field('cta');
?>

<section class="module module--challenges py-80px <?= $className ?>" id="take-the-challenge">
    <div class="wrapper">
        <div class="module-title-holder text-center">
            <h2 class="module--title"><?= $heading ?></h2>
            <p><?= $content ?></p>
        </div>

        <?php if(is_page('home')) : ?>
        <div class="card--carousel mt-40px">
            <?php if( have_rows('cards') ): // Outer loop for Cards ?>
                <?php while( have_rows('cards') ): the_row(); ?>

                    <div class="card-holder">
                        <div class="card-header text-light">
                            <h3><?php the_sub_field('card_title'); ?></h3>
                            <div class="card-price">
                                <p><?php the_sub_field('card_price_label'); ?></p>
                                <h4><?php the_sub_field('card_price_amount'); ?></h4>
                            </div>
                        </div>

                        <div class="card-body">
                            <?php if( have_rows('card_body_list') ): // Nested loop for card_body_list ?>
                                <?php while( have_rows('card_body_list') ): the_row(); ?>
                                    <div class="card-body-list">
                                        <p class="body-title"><?php the_sub_field('body_title'); ?></p>
                                        <p><?php the_sub_field('body_value'); ?></p>
                                    </div>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </div>

                        <div class="card-btn text-center">
                            <a href="<?php the_sub_field('buy_now_url'); ?>" class="btn btn--primary w-full">Buy Now</a>
                        </div>
                    </div>

                <?php endwhile; ?>
            <?php endif; ?>
        </div>
        

    </div>
        
        <div class="wrapper" style="margin-top: 5rem">
            <div class="module-title-holder text-center mw-511 m-auto module-challenge-text">
                <p>FundedX Traders Challenge allows participants in both Stage 1 and Stage 2 to complete their trading without any time constraints.</p>
            </div>
            <span id="tooltip_bar" class="tooltip-bar custom-tooltip-bar"></span>
            <div class="progress-bar" id="slider-progress">
                <div class="progress-bar-fill" id="slider-progress-fill">
                </div>
            </div>
            <?php endif; ?>              
            <div class="btn-holder text-center mt-40px">
            <a href="<?= $cta['url'] ?>" class="btn btn--primary"><?= $cta['title'] ?> <?= get_template_part('img/arrow-up.svg'); ?></a>
            </div>

        </div>

</section>


