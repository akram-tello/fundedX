<?php 
    $className = !empty($block['className']) ? $block['className'] : null;
    $heading = get_field('heading');
    $content = get_field('content');
?>

<section class="module module--trader py-80px <?= $className ?>">
    <div class="wrapper">
        <div class="module-title-holder text-center">
            <h2 class="module--title"><?= $heading ?></h2>
            <p class="max-w-2xl m-auto mt-3"><?= $content ?></p>
        </div>
    </div>
</section>