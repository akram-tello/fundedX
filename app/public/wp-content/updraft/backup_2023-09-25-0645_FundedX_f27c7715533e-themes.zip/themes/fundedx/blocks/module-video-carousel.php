<section class="module module--video-carousel py-80px">
    <div class="wrapper">
        <div class="module-title-holder text-center">
            <h2 class="module--title">Our FundedX Traders Success Is Our Success.</h2>
            <p>Here is what our FundedX traders have to say.</p>
        </div>

        <div class="card--carousel mt-40px">
            <div class="card-holder">
               <div class="card-img">
                <img data-src="<?= get_template_directory_uri(); ?>/img/video-1.png" src="<?= get_template_directory_uri() ?>/img/placeholder.png" alt="">
               </div>
            </div>

            <div class="card-holder">
               <div class="card-img">
                <img data-src="<?= get_template_directory_uri(); ?>/img/video-1.png" src="<?= get_template_directory_uri() ?>/img/placeholder.png" alt="">
               </div>
            </div>

            <div class="card-holder">
               <div class="card-img">
                <img data-src="<?= get_template_directory_uri(); ?>/img/video-1.png" src="<?= get_template_directory_uri() ?>/img/placeholder.png" alt="">
               </div>
            </div>

            <div class="card-holder">
               <div class="card-img">
                <img data-src="<?= get_template_directory_uri(); ?>/img/video-1.png" src="<?= get_template_directory_uri() ?>/img/placeholder.png" alt="">
               </div>
            </div>
        </div>

    </div>
</section>