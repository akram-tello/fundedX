const assets = ( state = {} ) => {
	return state;
};

export default assets;
