const API = ( state = {} ) => {
	return state;
};

export default API;
