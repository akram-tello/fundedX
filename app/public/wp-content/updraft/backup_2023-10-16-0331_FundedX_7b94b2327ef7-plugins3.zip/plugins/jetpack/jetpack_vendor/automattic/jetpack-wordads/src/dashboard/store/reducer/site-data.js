const siteData = ( state = {} ) => {
	return state;
};

export default siteData;
