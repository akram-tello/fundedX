<?php

abstract class Forminator_Calculator_Parser_Node_Abstract {

}
