<?php

class Forminator_Calculator_Symbol_Closing_Bracket extends Forminator_Calculator_Symbol_Abstract {

	/**
	 * @inheritdoc
	 */
	protected $identifiers = array( ')' );

}
