<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$forminator_admin_locale = array(
"Appearance" => array( null, __("Appearance", "forminator" ), ), // src/form/components/appearance.js:66
"Apply Preset" => array( null, __("Apply Preset", "forminator" ), ), // src/form/components/appearance.js:75
"Fields" => array( null, __("Fields", "forminator" ), ), // src/form/components/appearance.js:114
"Behavior" => array( null, __("Behavior", "forminator" ), ), // src/form/components/appearance.js:125
"User Registration" => array( null, __("User Registration", "forminator" ), ), // src/form/components/appearance.js:133
"User Login" => array( null, __("User Login", "forminator" ), ), // src/form/components/appearance.js:141
"Colors" => array( null, __("Colors", "forminator" ), ), // src/form/components/appearance/colors.js:225
"Adjust the default color combinations to match your theme styling." => array( null, __("Adjust the default color combinations to match your theme styling.", "forminator" ), ), // src/form/components/appearance/colors.js:226
"Use Default Colors" => array( null, __("Use Default Colors", "forminator" ), ), // src/form/components/appearance/colors.js:240
"Custom" => array( null, __("Custom", "forminator" ), ), // src/form/components/appearance/colors.js:243
"Element" => array( null, __("Element", "forminator" ), ), // src/form/components/appearance/colors.js:248
"Form Container" => array( null, __("Form Container", "forminator" ), ), // src/form/components/appearance/colors.js:253
"Submission Indicator" => array( null, __("Submission Indicator", "forminator" ), ), // src/form/components/appearance/colors.js:261
"Response Success" => array( null, __("Response Success", "forminator" ), ), // src/form/components/appearance/colors.js:269
"Successful response message will be displayed after form submission succeeds." => array( null, __("Successful response message will be displayed after form submission succeeds.", "forminator" ), ), // src/form/components/appearance/colors.js:271
"Response Error" => array( null, __("Response Error", "forminator" ), ), // src/form/components/appearance/colors.js:280
"Error response message will be displayed after form submission fails." => array( null, __("Error response message will be displayed after form submission fails.", "forminator" ), ), // src/form/components/appearance/colors.js:282
"Pagination Steps" => array( null, __("Pagination Steps", "forminator" ), ), // src/form/components/appearance/colors.js:292
"Pagination Progress Bar" => array( null, __("Pagination Progress Bar", "forminator" ), ), // src/form/components/appearance/colors.js:300
"Fields Basics" => array( null, __("Fields Basics", "forminator" ), ), // src/form/components/appearance/colors.js:308
"Section" => array( null, __("Section", "forminator" ), ), // src/form/components/appearance/colors.js:316
"Input and Textarea" => array( null, __("Input and Textarea", "forminator" ), ), // src/form/components/appearance/colors.js:324
"Input Extras" => array( null, __("Input Extras", "forminator" ), ), // src/form/components/appearance/colors.js:337
"Radio and Checkbox" => array( null, __("Radio and Checkbox", "forminator" ), ), // src/form/components/appearance/colors.js:350
"Select" => array( null, __("Select", "forminator" ), ), // src/form/components/appearance/colors.js:366
"Dropdown List" => array( null, __("Dropdown List", "forminator" ), ), // src/form/components/appearance/colors.js:372
"Dropdown Search" => array( null, __("Dropdown Search", "forminator" ), ), // src/form/components/appearance/colors.js:382
"Multi Select" => array( null, __("Multi Select", "forminator" ), ), // src/form/components/appearance/colors.js:394
"Calendar Basics" => array( null, __("Calendar Basics", "forminator" ), ), // src/form/components/appearance/colors.js:405
"Calendar Table" => array( null, __("Calendar Table", "forminator" ), ), // src/form/components/appearance/colors.js:412
"File Upload" => array( null, __("File Upload", "forminator" ), ), // src/form/components/appearance/colors.js:424
"E-Signature" => array( null, __("E-Signature", "forminator" ), ), // src/form/components/appearance/colors.js:438
"Field Group" => array( null, __("Field Group", "forminator" ), ), // src/form/components/appearance/colors.js:451
"Repeater Button" => array( null, __("Repeater Button", "forminator" ), ), // src/form/components/appearance/colors.js:458
"Button Back" => array( null, __("Button Back", "forminator" ), ), // src/form/components/appearance/colors.js:481
"Button Next" => array( null, __("Button Next", "forminator" ), ), // src/form/components/appearance/colors.js:488
"Consent" => array( null, __("Consent", "forminator" ), ), // src/form/components/appearance/colors.js:499
"Submit Button" => array( null, __("Submit Button", "forminator" ), ), // src/form/components/appearance/colors.js:507
"Container" => array( null, __("Container", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:22
"Border" => array( null, __("Border", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:28
"Header background" => array( null, __("Header background", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:29
"Background" => array( null, __("Background", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:38
"Main background" => array( null, __("Main background", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:39
"Navigation" => array( null, __("Navigation", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:48
"Arrows background" => array( null, __("Arrows background", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:53
"Arrows color" => array( null, __("Arrows color", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:60
"Color" => array( null, __("Color", "forminator" ), ), // src/form/components/appearance/colors/calendar-basics.js:86
"Default" => array( null, __("Default", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:22
"Table head color" => array( null, __("Table head color", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:27
"Table cell border" => array( null, __("Table cell border", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:35
"Table cell BG" => array( null, __("Table cell BG", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:43
"Table cell color" => array( null, __("Table cell color", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:50
"Hover" => array( null, __("Hover", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:58
"Active" => array( null, __("Active", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:86
"Current" => array( null, __("Current", "forminator" ), ), // src/form/components/appearance/colors/calendar-table.js:114
"Border color" => array( null, __("Border color", "forminator" ), ), // src/form/components/appearance/colors/consent.js:29
"Background color" => array( null, __("Background color", "forminator" ), ), // src/form/components/appearance/colors/consent.js:35
"Text color" => array( null, __("Text color", "forminator" ), ), // src/form/components/appearance/colors/consent.js:42
"Checked" => array( null, __("Checked", "forminator" ), ), // src/form/components/appearance/colors/consent.js:48
"Icon color" => array( null, __("Icon color", "forminator" ), ), // src/form/components/appearance/colors/consent.js:69
"Error" => array( null, __("Error", "forminator" ), ), // src/form/components/appearance/colors/consent.js:76
"Container border" => array( null, __("Container border", "forminator" ), ), // src/form/components/appearance/colors/dropdown.js:33
"Container BG" => array( null, __("Container BG", "forminator" ), ), // src/form/components/appearance/colors/dropdown.js:41
"Option color" => array( null, __("Option color", "forminator" ), ), // src/form/components/appearance/colors/dropdown.js:48
"Option background" => array( null, __("Option background", "forminator" ), ), // src/form/components/appearance/colors/dropdown.js:60
"Selected" => array( null, __("Selected", "forminator" ), ), // src/form/components/appearance/colors/dropdown.js:72
"Label" => array( null, __("Label", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:18
"Required asterisk" => array( null, __("Required asterisk", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:24
"Description" => array( null, __("Description", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:30
"Error message BG" => array( null, __("Error message BG", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:37
"Error message color" => array( null, __("Error message color", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:46
"Global error color" => array( null, __("Global error color", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:47
"This color will be used when fields throw an error as text color, border color, etc." => array( null, __("This color will be used when fields throw an error as text color, border color, etc.", "forminator" ), ), // src/form/components/appearance/colors/fields-basics.js:50
"Focus" => array( null, __("Focus", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-delete.js:60
"File preview border color" => array( null, __("File preview border color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:29
"Default state border will not appear when file uploaded is an image." => array( null, __("Default state border will not appear when file uploaded is an image.", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:30
"File preview background color" => array( null, __("File preview background color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:42
"File preview icon color" => array( null, __("File preview icon color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:53
"File name color" => array( null, __("File name color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:60
"File size color" => array( null, __("File size color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:67
"Loading icon color" => array( null, __("Loading icon color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:74
"File size icon color" => array( null, __("File size icon color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-file-multiple.js:114
"Cloud icon color" => array( null, __("Cloud icon color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:48
"Message text color" => array( null, __("Message text color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:56
"Message link color" => array( null, __("Message link color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:63
"Drop" => array( null, __("Drop", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:107
"Left border color" => array( null, __("Left border color", "forminator" ), ), // src/form/components/appearance/colors/file-upload/upload-panel-multiple.js:158
"Divider color" => array( null, __("Divider color", "forminator" ), ), // src/form/components/appearance/colors/group.js:32
"Prefix color" => array( null, __("Prefix color", "forminator" ), ), // src/form/components/appearance/colors/inputs-extra.js:53
"Suffix color" => array( null, __("Suffix color", "forminator" ), ), // src/form/components/appearance/colors/inputs-extra.js:63
"Placeholder" => array( null, __("Placeholder", "forminator" ), ), // src/form/components/appearance/colors/inputs.js:44
"Option border" => array( null, __("Option border", "forminator" ), ), // src/form/components/appearance/colors/multi-select.js:32
"Label color" => array( null, __("Label color", "forminator" ), ), // src/form/components/appearance/colors/pagination-back.js:33
"Progress bar BG" => array( null, __("Progress bar BG", "forminator" ), ), // src/form/components/appearance/colors/pagination-progress.js:24
"Progress status BG" => array( null, __("Progress status BG", "forminator" ), ), // src/form/components/appearance/colors/pagination-progress.js:32
"Dot" => array( null, __("Dot", "forminator" ), ), // src/form/components/appearance/colors/pagination-steps.js:63
"Default state colors" => array( null, __("Default state colors", "forminator" ), ), // src/form/components/appearance/colors/pagination-steps.js:69
"Page number color" => array( null, __("Page number color", "forminator" ), ), // src/form/components/appearance/colors/pagination-steps.js:95
"Current state colors" => array( null, __("Current state colors", "forminator" ), ), // src/form/components/appearance/colors/pagination-steps.js:106
"Footer border color" => array( null, __("Footer border color", "forminator" ), ), // src/form/components/appearance/colors/pagination.js:15
"Image border" => array( null, __("Image border", "forminator" ), ), // src/form/components/appearance/colors/radio.js:49
"Image background" => array( null, __("Image background", "forminator" ), ), // src/form/components/appearance/colors/radio.js:58
"Button" => array( null, __("Button", "forminator" ), ), // src/form/components/appearance/colors/repeater.js:21
"Icon" => array( null, __("Icon", "forminator" ), ), // src/form/components/appearance/colors/repeater.js:110
"Link" => array( null, __("Link", "forminator" ), ), // src/form/components/appearance/colors/repeater.js:157
"Title color" => array( null, __("Title color", "forminator" ), ), // src/form/components/appearance/colors/section.js:15
"Subtitle color" => array( null, __("Subtitle color", "forminator" ), ), // src/form/components/appearance/colors/section.js:19
"Signature Color" => array( null, __("Signature Color", "forminator" ), ), // src/form/components/appearance/colors/signature.js:52
"Reset icon color" => array( null, __("Reset icon color", "forminator" ), ), // src/form/components/appearance/colors/signature.js:59
"Single File Uploader" => array( null, __("Single File Uploader", "forminator" ), ), // src/form/components/appearance/colors/uploaded-files.js:43
"Multiple Files Uploader" => array( null, __("Multiple Files Uploader", "forminator" ), ), // src/form/components/appearance/colors/uploaded-files.js:56
"Uploaded File" => array( null, __("Uploaded File", "forminator" ), ), // src/form/components/appearance/colors/uploaded-files.js:63
"Uploaded File Delete Button" => array( null, __("Uploaded File Delete Button", "forminator" ), ), // src/form/components/appearance/colors/uploaded-files.js:73
"Custom CSS" => array( null, __("Custom CSS", "forminator" ), ), // src/form/components/appearance/custom-css.js:16
"For more advanced customization options use custom CSS." => array( null, __("For more advanced customization options use custom CSS.", "forminator" ), ), // src/form/components/appearance/custom-css.js:18
"Enable custom CSS" => array( null, __("Enable custom CSS", "forminator" ), ), // src/form/components/appearance/custom-css.js:26
"Design Style" => array( null, __("Design Style", "forminator" ), ), // src/form/components/appearance/design.js:18
"Choose a pre-made style for your form and further customize it's appearance below." => array( null, __("Choose a pre-made style for your form and further customize it's appearance below.", "forminator" ), ), // src/form/components/appearance/design.js:20
"Flat" => array( null, __("Flat", "forminator" ), ), // src/form/components/appearance/design.js:35
"Bold" => array( null, __("Bold", "forminator" ), ), // src/form/components/appearance/design.js:38
"Material" => array( null, __("Material", "forminator" ), ), // src/form/components/appearance/design.js:41
"None" => array( null, __("None", "forminator" ), ), // src/form/components/appearance/design.js:47
"Field Label" => array( null, __("Field Label", "forminator" ), ), // src/form/components/appearance/design/basic.js:13
"Text" => array( null, __("Text", "forminator" ), ), // src/form/components/appearance/design/basic.js:22
"You have opted for no stylesheet to be enqueued. The form will inherit styles from your theme's CSS." => array( null, __("You have opted for no stylesheet to be enqueued. The form will inherit styles from your theme's CSS.", "forminator" ), ), // src/form/components/appearance/design/none.js:28
"Radius" => array( null, __("Radius", "forminator" ), ), // src/form/components/appearance/field-container/border-custom.js:20
"in px" => array( null, __("in px", "forminator" ), ), // src/form/components/appearance/field-container/border-custom.js:21
"Thickness" => array( null, __("Thickness", "forminator" ), ), // src/form/components/appearance/field-container/border-custom.js:30
"Field Container" => array( null, __("Field Container", "forminator" ), ), // src/form/components/appearance/fields-container.js:14
"Customize the field container's border." => array( null, __("Customize the field container's border.", "forminator" ), ), // src/form/components/appearance/fields-container.js:16
"Add an border style around the field." => array( null, __("Add an border style around the field.", "forminator" ), ), // src/form/components/appearance/fields-container.js:26
"Fonts" => array( null, __("Fonts", "forminator" ), ), // src/form/components/appearance/fonts.js:152
"By default this form will inherit the fonts your theme uses. You can overwrite these fonts with custom ones from {{link}}Bunny Fonts{{/link}}." => array( null, __("By default this form will inherit the fonts your theme uses. You can overwrite these fonts with custom ones from {{link}}Bunny Fonts{{/link}}.", "forminator" ), ), // src/form/components/appearance/fonts.js:153
"Use Theme Fonts" => array( null, __("Use Theme Fonts", "forminator" ), ), // src/form/components/appearance/fonts.js:174
"Response Message" => array( null, __("Response Message", "forminator" ), ), // src/form/components/appearance/fonts.js:186
"Fields Label" => array( null, __("Fields Label", "forminator" ), ), // src/form/components/appearance/fonts.js:231
"Fields Description" => array( null, __("Fields Description", "forminator" ), ), // src/form/components/appearance/fonts.js:245
"Fields Error Message" => array( null, __("Fields Error Message", "forminator" ), ), // src/form/components/appearance/fonts.js:259
"Section Title" => array( null, __("Section Title", "forminator" ), ), // src/form/components/appearance/fonts.js:276
"Section Subtitle" => array( null, __("Section Subtitle", "forminator" ), ), // src/form/components/appearance/fonts.js:290
"Input Prefix" => array( null, __("Input Prefix", "forminator" ), ), // src/form/components/appearance/fonts.js:321
"Input Suffix" => array( null, __("Input Suffix", "forminator" ), ), // src/form/components/appearance/fonts.js:338
"Dropdown" => array( null, __("Dropdown", "forminator" ), ), // src/form/components/appearance/fonts.js:396
"Calendar" => array( null, __("Calendar", "forminator" ), ), // src/form/components/appearance/fonts.js:414
"Single File Upload" => array( null, __("Single File Upload", "forminator" ), ), // src/form/components/appearance/fonts.js:445
"Upload Button" => array( null, __("Upload Button", "forminator" ), ), // src/form/components/appearance/fonts.js:458
"File Name" => array( null, __("File Name", "forminator" ), ), // src/form/components/appearance/fonts.js:469
"Multiple Files Upload" => array( null, __("Multiple Files Upload", "forminator" ), ), // src/form/components/appearance/fonts.js:485
"Upload Panel" => array( null, __("Upload Panel", "forminator" ), ), // src/form/components/appearance/fonts.js:498
"File Size" => array( null, __("File Size", "forminator" ), ), // src/form/components/appearance/fonts.js:520
"E-Signature Placeholder" => array( null, __("E-Signature Placeholder", "forminator" ), ), // src/form/components/appearance/fonts.js:536
"Pagination Buttons" => array( null, __("Pagination Buttons", "forminator" ), ), // src/form/components/appearance/fonts.js:571
"Customize the form container's padding and border." => array( null, __("Customize the form container's padding and border.", "forminator" ), ), // src/form/components/appearance/form-container.js:18
"Padding" => array( null, __("Padding", "forminator" ), ), // src/form/components/appearance/form-container.js:27
"By default the form will fill the available space where you insert it. You can add some padding here to better suit your theme." => array( null, __("By default the form will fill the available space where you insert it. You can add some padding here to better suit your theme.", "forminator" ), ), // src/form/components/appearance/form-container.js:28
"Add an optional border around the form." => array( null, __("Add an optional border around the form.", "forminator" ), ), // src/form/components/appearance/form-container.js:47
"Spacing" => array( null, __("Spacing", "forminator" ), ), // src/form/components/appearance/form-container.js:63
"Choose how much spacing you want between each form field." => array( null, __("Choose how much spacing you want between each form field.", "forminator" ), ), // src/form/components/appearance/form-container.js:65
"Comfortable" => array( null, __("Comfortable", "forminator" ), ), // src/form/components/appearance/form-container.js:69
"Compact" => array( null, __("Compact", "forminator" ), ), // src/form/components/appearance/form-container.js:72
"Style" => array( null, __("Style", "forminator" ), ), // src/form/components/appearance/form-container/border-custom.js:43
"Solid" => array( null, __("Solid", "forminator" ), ), // src/form/components/appearance/form-container/border-custom.js:46
"Dashed" => array( null, __("Dashed", "forminator" ), ), // src/form/components/appearance/form-container/border-custom.js:49
"Dotted" => array( null, __("Dotted", "forminator" ), ), // src/form/components/appearance/form-container/border-custom.js:52
"Note: Set the color of the border in the Colors settings area above." => array( null, __("Note: Set the color of the border in the Colors settings area above.", "forminator" ), ), // src/form/components/appearance/form-container/border-custom.js:60
"Top" => array( null, __("Top", "forminator" ), ), // src/form/components/appearance/form-container/padding-custom.js:20
"Bottom" => array( null, __("Bottom", "forminator" ), ), // src/form/components/appearance/form-container/padding-custom.js:29
"Left" => array( null, __("Left", "forminator" ), ), // src/form/components/appearance/form-container/padding-custom.js:38
"Right" => array( null, __("Right", "forminator" ), ), // src/form/components/appearance/form-container/padding-custom.js:47
"Set your custom padding in pixels." => array( null, __("Set your custom padding in pixels.", "forminator" ), ), // src/form/components/appearance/form-container/padding-custom.js:56
"in pixels" => array( null, __("in pixels", "forminator" ), ), // src/form/components/appearance/form-container/spacing-custom.js:17
"0" => array( null, __("0", "forminator" ), ), // src/form/components/appearance/form-container/spacing-custom.js:19
"Layout" => array( null, __("Layout", "forminator" ), ), // src/form/components/appearance/layout.js:13
"Adjust the layout of fields." => array( null, __("Adjust the layout of fields.", "forminator" ), ), // src/form/components/appearance/layout.js:15
"Radio/Checkbox Image Size" => array( null, __("Radio/Checkbox Image Size", "forminator" ), ), // src/form/components/appearance/layout.js:24
"Set radio/checkbox image size." => array( null, __("Set radio/checkbox image size.", "forminator" ), ), // src/form/components/appearance/layout.js:25
"Automatic" => array( null, __("Automatic", "forminator" ), ), // src/form/components/appearance/layout.js:31
"Note: If value is empty or zero, image will fallback to default size." => array( null, __("Note: If value is empty or zero, image will fallback to default size.", "forminator" ), ), // src/form/components/appearance/layout/field-image-size.js:32
"Width" => array( null, __("Width", "forminator" ), ), // src/form/components/appearance/layout/field-image-size.js:46
"Height" => array( null, __("Height", "forminator" ), ), // src/form/components/appearance/layout/field-image-size.js:56
"Set your custom dimensions in pixels." => array( null, __("Set your custom dimensions in pixels.", "forminator" ), ), // src/form/components/appearance/layout/field-image-size.js:66
"Our PDF builder is constantly improving and we’ll be adding more features over time. While the current release has limited customization options, we appreciate your patience as we work to bring you the best experience possible. Keep an eye out for updates. To manually adjust the appearance of the fields, you can enable the Custom CSS option below." => array( null, __("Our PDF builder is constantly improving and we’ll be adding more features over time. While the current release has limited customization options, we appreciate your patience as we work to bring you the best experience possible. Keep an eye out for updates. To manually adjust the appearance of the fields, you can enable the Custom CSS option below.", "forminator" ), ), // src/form/components/appearance/page-settings.js:26
"Page settings" => array( null, __("Page settings", "forminator" ), ), // src/form/components/appearance/page-settings.js:38
"Configure the PDF file settings" => array( null, __("Configure the PDF file settings", "forminator" ), ), // src/form/components/appearance/page-settings.js:40
"Page size" => array( null, __("Page size", "forminator" ), ), // src/form/components/appearance/page-settings.js:45
"Choose the standard paper size for your PDF document. The default resolution for each page is set at 96dpi." => array( null, __("Choose the standard paper size for your PDF document. The default resolution for each page is set at 96dpi.", "forminator" ), ), // src/form/components/appearance/page-settings.js:48
"Enable RTL (right-to-left)" => array( null, __("Enable RTL (right-to-left)", "forminator" ), ), // src/form/components/appearance/page-settings.js:65
"Pagination" => array( null, __("Pagination", "forminator" ), ), // src/form/components/appearance/pagination.js:23
"Customize the appearance of pagination of your form." => array( null, __("Customize the appearance of pagination of your form.", "forminator" ), ), // src/form/components/appearance/pagination.js:27
"Note: " => array( null, __("Note: ", "forminator" ), ), // src/form/components/appearance/pagination.js:34
"If you have added multiple pagination fields in your form, these settings will affect all of them." => array( null, __("If you have added multiple pagination fields in your form, these settings will affect all of them.", "forminator" ), ), // src/form/components/appearance/pagination.js:35
"Progress Indicator" => array( null, __("Progress Indicator", "forminator" ), ), // src/form/components/appearance/pagination.js:47
"By default we don’t show how many pages the user has left before completing the form. You can turn on a stepped progress bar to indicate to the user how far they are through your form." => array( null, __("By default we don’t show how many pages the user has left before completing the form. You can turn on a stepped progress bar to indicate to the user how far they are through your form.", "forminator" ), ), // src/form/components/appearance/pagination.js:49
"Hide" => array( null, __("Hide", "forminator" ), ), // src/form/components/appearance/pagination.js:57
"Show" => array( null, __("Show", "forminator" ), ), // src/form/components/appearance/pagination.js:63
"Progress Bar" => array( null, __("Progress Bar", "forminator" ), ), // src/form/components/appearance/pagination.js:72
"Steps" => array( null, __("Steps", "forminator" ), ), // src/form/components/appearance/pagination.js:78
"Page Margin" => array( null, __("Page Margin", "forminator" ), ), // src/form/components/appearance/pdf/page-margin.js:21
"Default margin for all paper sizes is 30px. Use the custom tab to set a different value." => array( null, __("Default margin for all paper sizes is 30px. Use the custom tab to set a different value.", "forminator" ), ), // src/form/components/appearance/pdf/page-margin.js:23
"Margin" => array( null, __("Margin", "forminator" ), ), // src/form/components/appearance/pdf/page-margin.js:39
"Some of the settings you'd find in a regular form are unavailable in this form template because they are either unnecessary or controlled by the parent quiz automatically." => array( null, __("Some of the settings you'd find in a regular form are unavailable in this form template because they are either unnecessary or controlled by the parent quiz automatically.", "forminator" ), ), // src/form/components/behaviour.js:71
"Settings" => array( null, __("Settings", "forminator" ), ), // src/form/components/behaviour.js:142
"PDF" => array( null, __("PDF", "forminator" ), ), // src/form/components/behaviour.js:151
"Form does not have fields that can be autofilled." => array( null, __("Form does not have fields that can be autofilled.", "forminator" ), ), // src/form/components/behaviour/autofill.js:77
"Autofill" => array( null, __("Autofill", "forminator" ), ), // src/form/components/behaviour/autofill.js:186
"If the user filling out the form is logged in, we can auto-fill fields with any available data." => array( null, __("If the user filling out the form is logged in, we can auto-fill fields with any available data.", "forminator" ), ), // src/form/components/behaviour/autofill.js:188
"Enable Autofill" => array( null, __("Enable Autofill", "forminator" ), ), // src/form/components/behaviour/autofill.js:198
"Autofill source" => array( null, __("Autofill source", "forminator" ), ), // src/form/components/behaviour/autofill.js:234
"Disable Autofill" => array( null, __("Disable Autofill", "forminator" ), ), // src/form/components/behaviour/autofill.js:240
"Editable" => array( null, __("Editable", "forminator" ), ), // src/form/components/behaviour/autofill.js:259
"No" => array( null, __("No", "forminator" ), ), // src/form/components/behaviour/autofill.js:264
"Yes" => array( null, __("Yes", "forminator" ), ), // src/form/components/behaviour/autofill.js:267
"more condition(s)" => array( null, __("more condition(s)", "forminator" ), ), // src/form/components/behaviour/behavior.js:97
"Process behavior if" => array( null, __("Process behavior if", "forminator" ), ), // src/form/components/behaviour/behavior.js:104
"Open condition settings" => array( null, __("Open condition settings", "forminator" ), ), // src/form/components/behaviour/behavior.js:172
"Edit Behavior" => array( null, __("Edit Behavior", "forminator" ), ), // src/form/components/behaviour/behavior.js:179
"Delete" => array( null, __("Delete", "forminator" ), ), // src/form/components/behaviour/behavior.js:186
"Add Behavior" => array( null, __("Add Behavior", "forminator" ), ), // src/form/components/behaviour/behaviors.js:74
"null" => array( null, __("null", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:65
"checked" => array( null, __("checked", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:103
"Field" => array( null, __("Field", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:164
"Condition (required)" => array( null, __("Condition (required)", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:184
"Select rule" => array( null, __("Select rule", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:185
"Is null" => array( null, __("Is null", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:192
"Is not null" => array( null, __("Is not null", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:195
"Is" => array( null, __("Is", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:203
"Is not" => array( null, __("Is not", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:206
"Is greater than" => array( null, __("Is greater than", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:214
"Is less than" => array( null, __("Is less than", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:217
"Contains" => array( null, __("Contains", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:228
"Starts" => array( null, __("Starts", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:231
"Ends" => array( null, __("Ends", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:234
"Day is" => array( null, __("Day is", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:245
"Day is not" => array( null, __("Day is not", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:248
"Month is" => array( null, __("Month is", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:260
"Month is not" => array( null, __("Month is not", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:263
"Select option" => array( null, __("Select option", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:288
"Status" => array( null, __("Status", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:305
"Value" => array( null, __("Value", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:321
"Select month" => array( null, __("Select month", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:339
"Select day" => array( null, __("Select day", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:363
"Done" => array( null, __("Done", "forminator" ), ), // src/form/components/behaviour/conditions-rule.js:393
"Process behavior if " => array( null, __("Process behavior if ", "forminator" ), ), // src/form/components/behaviour/conditions.js:129
"All" => array( null, __("All", "forminator" ), ), // src/form/components/behaviour/conditions.js:138
"Any" => array( null, __("Any", "forminator" ), ), // src/form/components/behaviour/conditions.js:139
"of the conditions below match." => array( null, __("of the conditions below match.", "forminator" ), ), // src/form/components/behaviour/conditions.js:142
"Conditions" => array( null, __("Conditions", "forminator" ), ), // src/form/components/behaviour/conditions.js:155
"Add Conditions" => array( null, __("Add Conditions", "forminator" ), ), // src/form/components/behaviour/conditions.js:164
"Add conditions for when this behavior will be processed." => array( null, __("Add conditions for when this behavior will be processed.", "forminator" ), ), // src/form/components/behaviour/conditions.js:169
"Add Condition" => array( null, __("Add Condition", "forminator" ), ), // src/form/components/behaviour/conditions.js:225
"Lifespan" => array( null, __("Lifespan", "forminator" ), ), // src/form/components/behaviour/lifespan.js:17
"By default this form will always be available for submissions. However you can lock down if need be." => array( null, __("By default this form will always be available for submissions. However you can lock down if need be.", "forminator" ), ), // src/form/components/behaviour/lifespan.js:20
"Expiry" => array( null, __("Expiry", "forminator" ), ), // src/form/components/behaviour/lifespan.js:31
"Date" => array( null, __("Date", "forminator" ), ), // src/form/components/behaviour/lifespan.js:46
"20 April 2018" => array( null, __("20 April 2018", "forminator" ), ), // src/form/components/behaviour/lifespan.js:49
"Expiration Message" => array( null, __("Expiration Message", "forminator" ), ), // src/form/components/behaviour/lifespan.js:53
"Whoops! This form has expired." => array( null, __("Whoops! This form has expired.", "forminator" ), ), // src/form/components/behaviour/lifespan.js:54
"Add some custom message for users to see when your form stops appearing or leave empty to show nothing (just an empty space)." => array( null, __("Add some custom message for users to see when your form stops appearing or leave empty to show nothing (just an empty space).", "forminator" ), ), // src/form/components/behaviour/lifespan.js:56
"Submissions" => array( null, __("Submissions", "forminator" ), ), // src/form/components/behaviour/lifespan.js:67
"Payments" => array( null, __("Payments", "forminator" ), ), // src/form/components/behaviour/payments.js:13
"Choose how you want the form to behave when you are collecting payments." => array( null, __("Choose how you want the form to behave when you are collecting payments.", "forminator" ), ), // src/form/components/behaviour/payments.js:15
"Require SSL certificate to submit this form" => array( null, __("Require SSL certificate to submit this form", "forminator" ), ), // src/form/components/behaviour/payments.js:23
"Enabling this will allow the form submission on an HTTPS page only. It is highly recommended to embed the form with payments action on an HTTPS page to avoid any man in the middle attack." => array( null, __("Enabling this will allow the form submission on an HTTPS page only. It is highly recommended to embed the form with payments action on an HTTPS page to avoid any man in the middle attack.", "forminator" ), ), // src/form/components/behaviour/payments.js:25
"Rendering" => array( null, __("Rendering", "forminator" ), ), // src/form/components/behaviour/render.js:11
"Choose how you want your form to be rendered for users." => array( null, __("Choose how you want your form to be rendered for users.", "forminator" ), ), // src/form/components/behaviour/render.js:14
"Load form using AJAX" => array( null, __("Load form using AJAX", "forminator" ), ), // src/form/components/behaviour/render.js:22
"Enabling this feature will load the form via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your form." => array( null, __("Enabling this feature will load the form via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your form.", "forminator" ), ), // src/form/components/behaviour/render.js:23
"Prevent page caching on form pages" => array( null, __("Prevent page caching on form pages", "forminator" ), ), // src/form/components/behaviour/render.js:34
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic forms. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this form on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic forms. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this form on it from being cached.", "forminator" ), ), // src/form/components/behaviour/render.js:35
"Save and Continue" => array( null, __("Save and Continue", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:39
"Your {form_name} form on {site_title} has been saved as draft" => array( null, __("Your {form_name} form on {site_title} has been saved as draft", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:40
"<p>Hi there!</p><p>You've successfully saved <b>{form_name}</b> form on <a href='{site_url}' target='_blank' rel='noopener noreferrer' style='color:#17A8E3;'>{site_title}</a>.
To continue where you left off, click the link below or copy the link to your web browser.</p><p><a href='{form_link}' target='_blank' rel='noopener noreferrer' style='color:#17A8E3;'>{form_link}</a></p><p>The above link will expire in {retention_period} days. Also note that anyone visiting the link will be able to view your partially completed form data.</p>" => array( null, __("<p>Hi there!</p><p>You've successfully saved <b>{form_name}</b> form on <a href='{site_url}' target='_blank' rel='noopener noreferrer' style='color:#17A8E3;'>{site_title}</a>.
To continue where you left off, click the link below or copy the link to your web browser.</p><p><a href='{form_link}' target='_blank' rel='noopener noreferrer' style='color:#17A8E3;'>{form_link}</a></p><p>The above link will expire in {retention_period} days. Also note that anyone visiting the link will be able to view your partially completed form data.</p>", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:41
"<p>Your form has been saved as draft and a resume link has been generated so you can return to the form anytime within {retention_period} days from today. Copy and save the link or enter your email address below to have the link sent to your mail.</p><p>These fields weren't saved to your submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload. Kindly fill them out before submitting the form.</p>" => array( null, __("<p>Your form has been saved as draft and a resume link has been generated so you can return to the form anytime within {retention_period} days from today. Copy and save the link or enter your email address below to have the link sent to your mail.</p><p>These fields weren't saved to your submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload. Kindly fill them out before submitting the form.</p>", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:73
"Enable this option if you want to allow users save their progress and return to complete the form at a later time." => array( null, __("Enable this option if you want to allow users save their progress and return to complete the form at a later time.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:96
"Enable save and continue" => array( null, __("Enable save and continue", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:108
"Configuration" => array( null, __("Configuration", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:126
"Draft retention period" => array( null, __("Draft retention period", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:132
"Enter the number of days a form's draft will be stored on your server before they are automatically deleted." => array( null, __("Enter the number of days a form's draft will be stored on your server before they are automatically deleted.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:134
"Save form link text" => array( null, __("Save form link text", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:144
"Save as Draft" => array( null, __("Save as Draft", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:145
"Edit text for the save draft link." => array( null, __("Edit text for the save draft link.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:146
"Resume message" => array( null, __("Resume message", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:156
"This message will be shown when a form is successfully saved as draft." => array( null, __("This message will be shown when a form is successfully saved as draft.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:157
"These fields will not be saved in the submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload." => array( null, __("These fields will not be saved in the submission draft: Paypal, Stripe, Signature, Password, Captcha, and Upload.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:173
"Allow send draft link to email" => array( null, __("Allow send draft link to email", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:184
"Enable to allow users send the draft form's link to their email." => array( null, __("Enable to allow users send the draft form's link to their email.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:185
"Configure the send link email form below. You can edit the email contents in the {{link}}Email Notifications{{/link}} tab." => array( null, __("Configure the send link email form below. You can edit the email contents in the {{link}}Email Notifications{{/link}} tab.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:196
"Email input label" => array( null, __("Email input label", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:212
"Send draft link to" => array( null, __("Send draft link to", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:213
"Placeholder (Optional)" => array( null, __("Placeholder (Optional)", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:219
"E.g., johndoe@gmail.com" => array( null, __("E.g., johndoe@gmail.com", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:220
"Send link button label" => array( null, __("Send link button label", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:226
"Send draft link" => array( null, __("Send draft link", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:227
"Permission" => array( null, __("Permission", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:238
"Select which users can save their forms as draft." => array( null, __("Select which users can save their forms as draft.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:243
"Public" => array( null, __("Public", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:259
"Every user can save their forms as draft." => array( null, __("Every user can save their forms as draft.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:263
"Registered Users" => array( null, __("Registered Users", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:273
"Only registered users can save their forms as draft." => array( null, __("Only registered users can save their forms as draft.", "forminator" ), ), // src/form/components/behaviour/save-and-continue.js:277
"Submission Behavior" => array( null, __("Submission Behavior", "forminator" ), ), // src/form/components/behaviour/submission.js:21
"Configure what should happen when a user submits this form." => array( null, __("Configure what should happen when a user submits this form.", "forminator" ), ), // src/form/components/behaviour/submission.js:24
"After submission" => array( null, __("After submission", "forminator" ), ), // src/form/components/behaviour/submission.js:35
"Choose what happens after successful submission of this form. Multiple submission behaviors can be added and conditionally processed based on submitted form data." => array( null, __("Choose what happens after successful submission of this form. Multiple submission behaviors can be added and conditionally processed based on submitted form data.", "forminator" ), ), // src/form/components/behaviour/submission.js:41
"You’ll need to configure conditional logic for each submission behavior to ensure Forminator knows when each behavior should be processed. If no conditions have been set, the first submission behavior will be processed." => array( null, __("You’ll need to configure conditional logic for each submission behavior to ensure Forminator knows when each behavior should be processed. If no conditions have been set, the first submission behavior will be processed.", "forminator" ), ), // src/form/components/behaviour/submission.js:67
"Method" => array( null, __("Method", "forminator" ), ), // src/form/components/behaviour/submission.js:91
"Choose whether you want to use AJAX to send this form without reloading the page, or use the more traditional method of reloading the page." => array( null, __("Choose whether you want to use AJAX to send this form without reloading the page, or use the more traditional method of reloading the page.", "forminator" ), ), // src/form/components/behaviour/submission.js:93
"Ajax" => array( null, __("Ajax", "forminator" ), ), // src/form/components/behaviour/submission.js:101
"Note that you can only use the Ajax submission method while using the Stripe field in your form. The Ajax method will hide your form after the successful submission and only your inline success message will be shown. The form will be available again when the page is reloaded." => array( null, __("Note that you can only use the Ajax submission method while using the Stripe field in your form. The Ajax method will hide your form after the successful submission and only your inline success message will be shown. The form will be available again when the page is reloaded.", "forminator" ), ), // src/form/components/behaviour/submission.js:121
"Page Reload" => array( null, __("Page Reload", "forminator" ), ), // src/form/components/behaviour/submission.js:140
"Validation" => array( null, __("Validation", "forminator" ), ), // src/form/components/behaviour/submission.js:184
"For fields that you've chosen to validate, choose how you want the validation to behave. On submission will run validation checks when the user submits the form using Ajax (recommended). The Live method will check fields at the same time as the user fills them out. Server side does the validation using PHP and returns any error messages after a page reload." => array( null, __("For fields that you've chosen to validate, choose how you want the validation to behave. On submission will run validation checks when the user submits the form using Ajax (recommended). The Live method will check fields at the same time as the user fills them out. Server side does the validation using PHP and returns any error messages after a page reload.", "forminator" ), ), // src/form/components/behaviour/submission.js:185
"On Submit" => array( null, __("On Submit", "forminator" ), ), // src/form/components/behaviour/submission.js:195
"Server Side" => array( null, __("Server Side", "forminator" ), ), // src/form/components/behaviour/submission.js:196
"Enable inline validation (as user types)" => array( null, __("Enable inline validation (as user types)", "forminator" ), ), // src/form/components/behaviour/submission.js:200
"Choose whether you want to show a loader on your form until it is submitted. We highly recommend using this on long forms or forms with payment field since they may take a few seconds to submit." => array( null, __("Choose whether you want to show a loader on your form until it is submitted. We highly recommend using this on long forms or forms with payment field since they may take a few seconds to submit.", "forminator" ), ), // src/form/components/behaviour/submission.js:210
"Show Loader" => array( null, __("Show Loader", "forminator" ), ), // src/form/components/behaviour/submission.js:220
"E.g. Submitting..." => array( null, __("E.g. Submitting...", "forminator" ), ), // src/form/components/behaviour/submission.js:225
"Choose the text to show on the right of loading icon" => array( null, __("Choose the text to show on the right of loading icon", "forminator" ), ), // src/form/components/behaviour/submission.js:228
"if" => array( null, __("if", "forminator" ), ), // src/form/components/builder/field.js:852
"Swipe" => array( null, __("Swipe", "forminator" ), ), // src/form/components/builder/field.js:871
"Field options" => array( null, __("Field options", "forminator" ), ), // src/form/components/builder/field.js:1037
"Edit Field" => array( null, __("Edit Field", "forminator" ), ), // src/form/components/builder/field.js:1049
"Duplicate" => array( null, __("Duplicate", "forminator" ), ), // src/form/components/builder/field.js:1062
"Insert Fields" => array( null, __("Insert Fields", "forminator" ), ), // src/form/components/builder/insert-fields.js:12
"Add fields to group" => array( null, __("Add fields to group", "forminator" ), ), // src/form/components/builder/insert-fields.js:12
"A form without fields isn’t going to be very useful… Add your first field above!" => array( null, __("A form without fields isn’t going to be very useful… Add your first field above!", "forminator" ), ), // src/form/components/builder/insert-fields.js:64
"Page Footer" => array( null, __("Page Footer", "forminator" ), ), // src/form/components/builder/page-footer.js:32
"Edit field" => array( null, __("Edit field", "forminator" ), ), // src/form/components/builder/page-footer.js:62
"Page Header" => array( null, __("Page Header", "forminator" ), ), // src/form/components/builder/page-header.js:32
"Since you are using Page Break field(s) to divide your form into multiple pages, use the pagination settings to customize the page label, progress indicator, and the buttons on each page." => array( null, __("Since you are using Page Break field(s) to divide your form into multiple pages, use the pagination settings to customize the page label, progress indicator, and the buttons on each page.", "forminator" ), ), // src/form/components/builder/pagination.js:44
"PayPal Checkout" => array( null, __("PayPal Checkout", "forminator" ), ), // src/form/components/builder/paypal.js:170
"Pay with PayPal" => array( null, __("Pay with PayPal", "forminator" ), ), // src/form/components/builder/paypal.js:178
"PayPal" => array( null, __("PayPal", "forminator" ), ), // src/form/components/builder/paypal.js:181
"PayPal field replaces the submit button of your form with the PayPal Smart Payment Buttons. The PayPal buttons will automatically submit the form after a successful payment." => array( null, __("PayPal field replaces the submit button of your form with the PayPal Smart Payment Buttons. The PayPal buttons will automatically submit the form after a successful payment.", "forminator" ), ), // src/form/components/builder/paypal.js:200
"Submit" => array( null, __("Submit", "forminator" ), ), // src/form/components/builder/submit.js:86
"Get the Add-on" => array( null, __("Get the Add-on", "forminator" ), ), // src/form/components/fields/addon-required.js:47
"Address" => array( null, __("Address", "forminator" ), ), // src/form/components/fields/address.js:25
"Apartment, suite, etc." => array( null, __("Apartment, suite, etc.", "forminator" ), ), // src/form/components/fields/address.js:29
"City" => array( null, __("City", "forminator" ), ), // src/form/components/fields/address.js:33
"State / Province" => array( null, __("State / Province", "forminator" ), ), // src/form/components/fields/address.js:37
"ZIP / Postal code" => array( null, __("ZIP / Postal code", "forminator" ), ), // src/form/components/fields/address.js:41
"Country" => array( null, __("Country", "forminator" ), ), // src/form/components/fields/address.js:45
"Note: The query parameter's value passed in URL should match with the {{link}}alpha-2 country code{{/link}} of the country you want to pre-populate dynamically." => array( null, __("Note: The query parameter's value passed in URL should match with the {{link}}alpha-2 country code{{/link}} of the country you want to pre-populate dynamically.", "forminator" ), ), // src/form/components/fields/address.js:69
"Enter label" => array( null, __("Enter label", "forminator" ), ), // src/form/components/fields/address.js:102
"Placeholder (optional)" => array( null, __("Placeholder (optional)", "forminator" ), ), // src/form/components/fields/address.js:110
"Enter Placeholder" => array( null, __("Enter Placeholder", "forminator" ), ), // src/form/components/fields/address.js:111
"Description (optional)" => array( null, __("Description (optional)", "forminator" ), ), // src/form/components/fields/address.js:126
"Enter description" => array( null, __("Enter description", "forminator" ), ), // src/form/components/fields/address.js:127
"At least one field must be enabled" => array( null, __("At least one field must be enabled", "forminator" ), ), // src/form/components/fields/address.js:232
"The Autocomplete feature simplifies entering addresses by offering real-time suggestions as you type. This feature requires the Forminator Geolocation Add-on." => array( null, __("The Autocomplete feature simplifies entering addresses by offering real-time suggestions as you type. This feature requires the Forminator Geolocation Add-on.", "forminator" ), ), // src/form/components/fields/address.js:258
"Field Type" => array( null, __("Field Type", "forminator" ), ), // src/form/components/fields/calculation.js:83
"By default, the calculation field is read-only. You can also hide the field if you don't want to show the calculated result on the form." => array( null, __("By default, the calculation field is read-only. You can also hide the field if you don't want to show the calculated result on the form.", "forminator" ), ), // src/form/components/fields/calculation.js:91
"Read-only" => array( null, __("Read-only", "forminator" ), ), // src/form/components/fields/calculation.js:102
"Hidden" => array( null, __("Hidden", "forminator" ), ), // src/form/components/fields/calculation.js:112
"Visibility rules have been added for this field. Enabling the Hidden option will remove the existing visibility rules." => array( null, __("Visibility rules have been added for this field. Enabling the Hidden option will remove the existing visibility rules.", "forminator" ), ), // src/form/components/fields/calculation.js:135
"Formatting" => array( null, __("Formatting", "forminator" ), ), // src/form/components/fields/calculation.js:154
"Choose how do you want to format the value of this field." => array( null, __("Choose how do you want to format the value of this field.", "forminator" ), ), // src/form/components/fields/calculation.js:162
"E.g., $" => array( null, __("E.g., $", "forminator" ), ), // src/form/components/fields/calculation.js:175
"Prefix" => array( null, __("Prefix", "forminator" ), ), // src/form/components/fields/calculation.js:177
"E.g., Kg" => array( null, __("E.g., Kg", "forminator" ), ), // src/form/components/fields/calculation.js:187
"Suffix" => array( null, __("Suffix", "forminator" ), ), // src/form/components/fields/calculation.js:189
"Separators" => array( null, __("Separators", "forminator" ), ), // src/form/components/fields/calculation.js:209
"1234567.89" => array( null, __("1234567.89", "forminator" ), ), // src/form/components/fields/calculation.js:219
"1,234,567.89" => array( null, __("1,234,567.89", "forminator" ), ), // src/form/components/fields/calculation.js:220
"1.234.567,89" => array( null, __("1.234.567,89", "forminator" ), ), // src/form/components/fields/calculation.js:221
"1 234 567,89" => array( null, __("1 234 567,89", "forminator" ), ), // src/form/components/fields/calculation.js:222
"E.g. $" => array( null, __("E.g. $", "forminator" ), ), // src/form/components/fields/calculation.js:235
"Thousand Separator" => array( null, __("Thousand Separator", "forminator" ), ), // src/form/components/fields/calculation.js:238
"Decimal Separator" => array( null, __("Decimal Separator", "forminator" ), ), // src/form/components/fields/calculation.js:247
"Round To" => array( null, __("Round To", "forminator" ), ), // src/form/components/fields/calculation.js:267
"0 decimals" => array( null, __("0 decimals", "forminator" ), ), // src/form/components/fields/calculation.js:270
"1 decimals" => array( null, __("1 decimals", "forminator" ), ), // src/form/components/fields/calculation.js:271
"2 decimals" => array( null, __("2 decimals", "forminator" ), ), // src/form/components/fields/calculation.js:272
"3 decimals" => array( null, __("3 decimals", "forminator" ), ), // src/form/components/fields/calculation.js:273
"4 decimals" => array( null, __("4 decimals", "forminator" ), ), // src/form/components/fields/calculation.js:274
"You can't set visibility conditions for a hidden field. Uncheck the Hidden option in the settings tab and come back here to define visibility rules." => array( null, __("You can't set visibility conditions for a hidden field. Uncheck the Hidden option in the settings tab and come back here to define visibility rules.", "forminator" ), ), // src/form/components/fields/calculation.js:354
"hCaptcha verification failed. Please try again." => array( null, __("hCaptcha verification failed. Please try again.", "forminator" ), ), // src/form/components/fields/captcha.js:25
"Captcha Provider" => array( null, __("Captcha Provider", "forminator" ), ), // src/form/components/fields/captcha.js:36
"Select your preferred CAPTCHA provider below." => array( null, __("Select your preferred CAPTCHA provider below.", "forminator" ), ), // src/form/components/fields/captcha.js:38
"reCAPTCHA" => array( null, __("reCAPTCHA", "forminator" ), ), // src/form/components/fields/captcha.js:52
"hCaptcha" => array( null, __("hCaptcha", "forminator" ), ), // src/form/components/fields/captcha.js:57
"You haven't added hCaptcha API keys in your global settings. Add your API keys {{link}}here{{/link}} and then come back to configure this field." => array( null, __("You haven't added hCaptcha API keys in your global settings. Add your API keys {{link}}here{{/link}} and then come back to configure this field.", "forminator" ), ), // src/form/components/fields/captcha.js:77
"reCAPTCHA type" => array( null, __("reCAPTCHA type", "forminator" ), ), // src/form/components/fields/captcha.js:102
"Choose the reCAPTCHA type you want to use on your form. You can read more about the different reCAPTCHA types {{link}}here{{/link}} and then choose the one which suits you the best." => array( null, __("Choose the reCAPTCHA type you want to use on your form. You can read more about the different reCAPTCHA types {{link}}here{{/link}} and then choose the one which suits you the best.", "forminator" ), ), // src/form/components/fields/captcha.js:104
"V2 Checkbox" => array( null, __("V2 Checkbox", "forminator" ), ), // src/form/components/fields/captcha.js:128
"You haven't added API keys for this reCAPTCHA type in your global settings. Add your API keys {{link}}here{{/link}} and then come back to configure this field." => array( null, __("You haven't added API keys for this reCAPTCHA type in your global settings. Add your API keys {{link}}here{{/link}} and then come back to configure this field.", "forminator" ), ), // src/form/components/fields/captcha.js:148
"Size" => array( null, __("Size", "forminator" ), ), // src/form/components/fields/captcha.js:173
"Normal" => array( null, __("Normal", "forminator" ), ), // src/form/components/fields/captcha.js:177
"Theme" => array( null, __("Theme", "forminator" ), ), // src/form/components/fields/captcha.js:185
"Light" => array( null, __("Light", "forminator" ), ), // src/form/components/fields/captcha.js:189
"Dark" => array( null, __("Dark", "forminator" ), ), // src/form/components/fields/captcha.js:190
"V2 Invisible" => array( null, __("V2 Invisible", "forminator" ), ), // src/form/components/fields/captcha.js:201
"reCAPTCHA V3" => array( null, __("reCAPTCHA V3", "forminator" ), ), // src/form/components/fields/captcha.js:255
"reCAPTCHA V3 returns a score (1 is very likely a good interaction, 0 is very likely a bot) based on user interaction. Choose the score below which the verification should fail." => array( null, __("reCAPTCHA V3 returns a score (1 is very likely a good interaction, 0 is very likely a bot) based on user interaction. Choose the score below which the verification should fail.", "forminator" ), ), // src/form/components/fields/captcha.js:296
"Score Threshold" => array( null, __("Score Threshold", "forminator" ), ), // src/form/components/fields/captcha.js:306
"0.0" => array( null, __("0.0", "forminator" ), ), // src/form/components/fields/captcha.js:310
"0.1" => array( null, __("0.1", "forminator" ), ), // src/form/components/fields/captcha.js:311
"0.2" => array( null, __("0.2", "forminator" ), ), // src/form/components/fields/captcha.js:312
"0.3" => array( null, __("0.3", "forminator" ), ), // src/form/components/fields/captcha.js:313
"0.4" => array( null, __("0.4", "forminator" ), ), // src/form/components/fields/captcha.js:314
"0.5" => array( null, __("0.5", "forminator" ), ), // src/form/components/fields/captcha.js:315
"0.6" => array( null, __("0.6", "forminator" ), ), // src/form/components/fields/captcha.js:316
"0.7" => array( null, __("0.7", "forminator" ), ), // src/form/components/fields/captcha.js:317
"0.8" => array( null, __("0.8", "forminator" ), ), // src/form/components/fields/captcha.js:318
"0.9" => array( null, __("0.9", "forminator" ), ), // src/form/components/fields/captcha.js:319
"1.0" => array( null, __("1.0", "forminator" ), ), // src/form/components/fields/captcha.js:320
"hCaptcha type" => array( null, __("hCaptcha type", "forminator" ), ), // src/form/components/fields/captcha.js:334
"hCaptcha offers two different types of CAPTCHA challenges, a Checkbox and an Invisible type. Choose the hCaptcha type you want to use in your form." => array( null, __("hCaptcha offers two different types of CAPTCHA challenges, a Checkbox and an Invisible type. Choose the hCaptcha type you want to use in your form.", "forminator" ), ), // src/form/components/fields/captcha.js:336
"Checkbox" => array( null, __("Checkbox", "forminator" ), ), // src/form/components/fields/captcha.js:352
"Invisible" => array( null, __("Invisible", "forminator" ), ), // src/form/components/fields/captcha.js:388
"To comply with online privacy laws, users should be informed that this form includes an invisible CAPTCHA field." => array( null, __("To comply with online privacy laws, users should be informed that this form includes an invisible CAPTCHA field.", "forminator" ), ), // src/form/components/fields/captcha.js:396
"Language" => array( null, __("Language", "forminator" ), ), // src/form/components/fields/captcha.js:406
"By default, the global CAPTCHA language setting will be used. However, you can manually select a different language here." => array( null, __("By default, the global CAPTCHA language setting will be used. However, you can manually select a different language here.", "forminator" ), ), // src/form/components/fields/captcha.js:408
"Select the theme for the captcha." => array( null, __("Select the theme for the captcha.", "forminator" ), ), // src/form/components/fields/captcha.js:445
"Badge Position" => array( null, __("Badge Position", "forminator" ), ), // src/form/components/fields/captcha.js:475
"Select where the reCAPTCHA badge will be displayed on your page." => array( null, __("Select where the reCAPTCHA badge will be displayed on your page.", "forminator" ), ), // src/form/components/fields/captcha.js:477
"Bottom Right" => array( null, __("Bottom Right", "forminator" ), ), // src/form/components/fields/captcha.js:494
"Bottom Left" => array( null, __("Bottom Left", "forminator" ), ), // src/form/components/fields/captcha.js:502
"Inline in Form" => array( null, __("Inline in Form", "forminator" ), ), // src/form/components/fields/captcha.js:510
"Error Message" => array( null, __("Error Message", "forminator" ), ), // src/form/components/fields/captcha.js:517
"Choose the error message you want to display on your form when reCAPTCHA verification fails." => array( null, __("Choose the error message you want to display on your form when reCAPTCHA verification fails.", "forminator" ), ), // src/form/components/fields/captcha.js:525
"Choose the error message you want to display on your form when hCaptcha verification fails." => array( null, __("Choose the error message you want to display on your form when hCaptcha verification fails.", "forminator" ), ), // src/form/components/fields/captcha.js:545
"E.g. Consent" => array( null, __("E.g. Consent", "forminator" ), ), // src/form/components/fields/consent.js:30
"Describe what your users should consent to." => array( null, __("Describe what your users should consent to.", "forminator" ), ), // src/form/components/fields/consent.js:40
"Default Value (optional)" => array( null, __("Default Value (optional)", "forminator" ), ), // src/form/components/fields/currency.js:70
"Enter default value" => array( null, __("Enter default value", "forminator" ), ), // src/form/components/fields/currency.js:71
"Currency" => array( null, __("Currency", "forminator" ), ), // src/form/components/fields/currency.js:97
"Choose the currency to display on the field. If you are going to collect payments based on this field, it is recommended to keep this currency same as your charge currency to avoid any confusions." => array( null, __("Choose the currency to display on the field. If you are going to collect payments based on this field, it is recommended to keep this currency same as your charge currency to avoid any confusions.", "forminator" ), ), // src/form/components/fields/currency.js:99
"Limit" => array( null, __("Limit", "forminator" ), ), // src/form/components/fields/currency.js:120
"Restrict the value that your users can enter in this field within a custom range." => array( null, __("Restrict the value that your users can enter in this field within a custom range.", "forminator" ), ), // src/form/components/fields/currency.js:122
"Min" => array( null, __("Min", "forminator" ), ), // src/form/components/fields/currency.js:135
"Max" => array( null, __("Max", "forminator" ), ), // src/form/components/fields/currency.js:150
"Error Messages" => array( null, __("Error Messages", "forminator" ), ), // src/form/components/fields/currency.js:167
"When number is smaller than the min limit" => array( null, __("When number is smaller than the min limit", "forminator" ), ), // src/form/components/fields/currency.js:184
"E.g. Please enter a number greater than 0." => array( null, __("E.g. Please enter a number greater than 0.", "forminator" ), ), // src/form/components/fields/currency.js:187
"When number is greater than the max limit" => array( null, __("When number is greater than the max limit", "forminator" ), ), // src/form/components/fields/currency.js:197
"E.g. Please enter a number lower than 1000." => array( null, __("E.g. Please enter a number lower than 1000.", "forminator" ), ), // src/form/components/fields/currency.js:200
"Note: The query parameter's value passed in URL should match with the selected date format." => array( null, __("Note: The query parameter's value passed in URL should match with the selected date format.", "forminator" ), ), // src/form/components/fields/date.js:31
"Type" => array( null, __("Type", "forminator" ), ), // src/form/components/fields/date.js:44
"Date Format" => array( null, __("Date Format", "forminator" ), ), // src/form/components/fields/date.js:78
"Y-m-d" => array( null, __("Y-m-d", "forminator" ), ), // src/form/components/fields/date.js:82
"m-d-Y" => array( null, __("m-d-Y", "forminator" ), ), // src/form/components/fields/date.js:83
"d-m-Y" => array( null, __("d-m-Y", "forminator" ), ), // src/form/components/fields/date.js:84
"Y/m/d" => array( null, __("Y/m/d", "forminator" ), ), // src/form/components/fields/date.js:85
"m/d/Y" => array( null, __("m/d/Y", "forminator" ), ), // src/form/components/fields/date.js:86
"d/m/Y" => array( null, __("d/m/Y", "forminator" ), ), // src/form/components/fields/date.js:87
"Y.m.d" => array( null, __("Y.m.d", "forminator" ), ), // src/form/components/fields/date.js:88
"m.d.Y" => array( null, __("m.d.Y", "forminator" ), ), // src/form/components/fields/date.js:89
"d.m.Y" => array( null, __("d.m.Y", "forminator" ), ), // src/form/components/fields/date.js:90
"Calendar Icon" => array( null, __("Calendar Icon", "forminator" ), ), // src/form/components/fields/date.js:111
"Dropdowns" => array( null, __("Dropdowns", "forminator" ), ), // src/form/components/fields/date.js:123
"Month" => array( null, __("Month", "forminator" ), ), // src/form/components/fields/date.js:176
"Label (optional)" => array( null, __("Label (optional)", "forminator" ), ), // src/form/components/fields/date.js:183
"Day" => array( null, __("Day", "forminator" ), ), // src/form/components/fields/date.js:193
"Year" => array( null, __("Year", "forminator" ), ), // src/form/components/fields/date.js:210
"Text inputs" => array( null, __("Text inputs", "forminator" ), ), // src/form/components/fields/date.js:230
"Enter placeholder" => array( null, __("Enter placeholder", "forminator" ), ), // src/form/components/fields/date.js:301
"Default Date" => array( null, __("Default Date", "forminator" ), ), // src/form/components/fields/date.js:370
"Use this feature to specify a default selected date." => array( null, __("Use this feature to specify a default selected date.", "forminator" ), ), // src/form/components/fields/date.js:372
"Today" => array( null, __("Today", "forminator" ), ), // src/form/components/fields/date.js:386
"Future Date" => array( null, __("Future Date", "forminator" ), ), // src/form/components/fields/date.js:392
"Year Range" => array( null, __("Year Range", "forminator" ), ), // src/form/components/fields/date.js:409
"By default, we select 100 years in the past, and 100 years in the future for the year dropdown field. You can set a custom year range to display in the year dropdown below." => array( null, __("By default, we select 100 years in the past, and 100 years in the future for the year dropdown field. You can set a custom year range to display in the year dropdown below.", "forminator" ), ), // src/form/components/fields/date.js:411
"From" => array( null, __("From", "forminator" ), ), // src/form/components/fields/date.js:424
"1920" => array( null, __("1920", "forminator" ), ), // src/form/components/fields/date.js:425
"To" => array( null, __("To", "forminator" ), ), // src/form/components/fields/date.js:435
"2030" => array( null, __("2030", "forminator" ), ), // src/form/components/fields/date.js:436
"Wrong field type!" => array( null, __("Wrong field type!", "forminator" ), ), // src/form/components/fields/email.js:36
"The {{strong}}GDPR Field{{/strong}} has been deprecated and replaced by the new {{strong}}Consent Field{{/strong}}. Your existing fields should continue to work as expected, but please consider using the {{strong}}Consent Field{{/strong}} in the future." => array( null, __("The {{strong}}GDPR Field{{/strong}} has been deprecated and replaced by the new {{strong}}Consent Field{{/strong}}. Your existing fields should continue to work as expected, but please consider using the {{strong}}Consent Field{{/strong}} in the future.", "forminator" ), ), // src/form/components/fields/gdprcheckbox.js:35
"Note, the form will not submit until the user has accepted the terms." => array( null, __("Note, the form will not submit until the user has accepted the terms.", "forminator" ), ), // src/form/components/fields/gdprcheckbox.js:66
"Error message" => array( null, __("Error message", "forminator" ), ), // src/form/components/fields/gdprcheckbox.js:80
"Enter required message" => array( null, __("Enter required message", "forminator" ), ), // src/form/components/fields/gdprcheckbox.js:81
"Use this field to group Forminator fields together and collect repeating data in your form. Learn more about grouping and repeating use cases in {{link}}this tutorial. {{icon/}}{{/link}}" => array( null, __("Use this field to group Forminator fields together and collect repeating data in your form. Learn more about grouping and repeating use cases in {{link}}this tutorial. {{icon/}}{{/link}}", "forminator" ), ), // src/form/components/fields/group/labels.js:20
"Field Repeater" => array( null, __("Field Repeater", "forminator" ), ), // src/form/components/fields/group/settings.js:36
"Allow fields in this group to be repeated." => array( null, __("Allow fields in this group to be repeated.", "forminator" ), ), // src/form/components/fields/group/settings.js:37
"Enable" => array( null, __("Enable", "forminator" ), ), // src/form/components/fields/group/settings.js:46
"Minimum repeater limit" => array( null, __("Minimum repeater limit", "forminator" ), ), // src/form/components/fields/group/settings.js:55
"Enter the minimum number of times this group field will be repeated by default, or select a variable from your form fields. If left empty, the minimum will default to 1." => array( null, __("Enter the minimum number of times this group field will be repeated by default, or select a variable from your form fields. If left empty, the minimum will default to 1.", "forminator" ), ), // src/form/components/fields/group/settings.js:57
"Enter minimum limit" => array( null, __("Enter minimum limit", "forminator" ), ), // src/form/components/fields/group/settings.js:78
"Variable" => array( null, __("Variable", "forminator" ), ), // src/form/components/fields/group/settings.js:87
"Choose form field" => array( null, __("Choose form field", "forminator" ), ), // src/form/components/fields/group/settings.js:96
"Maximum repeater limit" => array( null, __("Maximum repeater limit", "forminator" ), ), // src/form/components/fields/group/settings.js:115
"Enter the maximum number of times this group field can be repeated, or select a variable from your form fields. If left empty, the maximum will be unlimited." => array( null, __("Enter the maximum number of times this group field can be repeated, or select a variable from your form fields. If left empty, the maximum will be unlimited.", "forminator" ), ), // src/form/components/fields/group/settings.js:117
"Enter maximum limit" => array( null, __("Enter maximum limit", "forminator" ), ), // src/form/components/fields/group/settings.js:136
"Repeater Element Type" => array( null, __("Repeater Element Type", "forminator" ), ), // src/form/components/fields/group/settings.js:173
"Choose the element type and label text for your repeater actions." => array( null, __("Choose the element type and label text for your repeater actions.", "forminator" ), ), // src/form/components/fields/group/settings.js:174
"Buttons" => array( null, __("Buttons", "forminator" ), ), // src/form/components/fields/group/settings.js:183
"Add Button Text (optional)" => array( null, __("Add Button Text (optional)", "forminator" ), ), // src/form/components/fields/group/settings.js:191
"Add item" => array( null, __("Add item", "forminator" ), ), // src/form/components/fields/group/settings.js:192
"Remove Button Text (optional)" => array( null, __("Remove Button Text (optional)", "forminator" ), ), // src/form/components/fields/group/settings.js:201
"Remove item" => array( null, __("Remove item", "forminator" ), ), // src/form/components/fields/group/settings.js:202
"Icons" => array( null, __("Icons", "forminator" ), ), // src/form/components/fields/group/settings.js:214
"Text links" => array( null, __("Text links", "forminator" ), ), // src/form/components/fields/group/settings.js:221
"Add Link Text (optional)" => array( null, __("Add Link Text (optional)", "forminator" ), ), // src/form/components/fields/group/settings.js:229
"Disable" => array( null, __("Disable", "forminator" ), ), // src/form/components/fields/group/settings.js:256
"Group Field Styling" => array( null, __("Group Field Styling", "forminator" ), ), // src/form/components/fields/group/styling.js:23
"By default, the Group Field will apply the styles you have set in the Appearance settings, but you can remove those styles with this option." => array( null, __("By default, the Group Field will apply the styles you have set in the Appearance settings, but you can remove those styles with this option.", "forminator" ), ), // src/form/components/fields/group/styling.js:26
"Apply" => array( null, __("Apply", "forminator" ), ), // src/form/components/fields/group/styling.js:45
"Remove" => array( null, __("Remove", "forminator" ), ), // src/form/components/fields/group/styling.js:51
"Custom Value" => array( null, __("Custom Value", "forminator" ), ), // src/form/components/fields/hidden.js:55
"Enter custom value" => array( null, __("Enter custom value", "forminator" ), ), // src/form/components/fields/hidden.js:56
"Query parameter" => array( null, __("Query parameter", "forminator" ), ), // src/form/components/fields/hidden.js:69
"E.g. query_parameter_key" => array( null, __("E.g. query_parameter_key", "forminator" ), ), // src/form/components/fields/hidden.js:70
"By default, we stack the options vertically. However, you can change the options layout below." => array( null, __("By default, we stack the options vertically. However, you can change the options layout below.", "forminator" ), ), // src/form/components/fields/multivalue.js:70
"Vertical" => array( null, __("Vertical", "forminator" ), ), // src/form/components/fields/multivalue.js:83
"Horizontal" => array( null, __("Horizontal", "forminator" ), ), // src/form/components/fields/multivalue.js:84
"Choose whether to allow this field to be used in calculations or not." => array( null, __("Choose whether to allow this field to be used in calculations or not.", "forminator" ), ), // src/form/components/fields/multivalue.js:101
"First Name" => array( null, __("First Name", "forminator" ), ), // src/form/components/fields/name.js:32
"Middle Name" => array( null, __("Middle Name", "forminator" ), ), // src/form/components/fields/name.js:36
"Last Name" => array( null, __("Last Name", "forminator" ), ), // src/form/components/fields/name.js:40
"Single" => array( null, __("Single", "forminator" ), ), // src/form/components/fields/name.js:79
"Multiple" => array( null, __("Multiple", "forminator" ), ), // src/form/components/fields/name.js:86
"By default, the \"Prefix\" and \"First Name\" fields are added to the first row, and the rest of the name fields are added to the second row. Under the Custom tab, you can choose the number of columns for displaying the name fields." => array( null, __("By default, the \"Prefix\" and \"First Name\" fields are added to the first row, and the rest of the name fields are added to the second row. Under the Custom tab, you can choose the number of columns for displaying the name fields.", "forminator" ), ), // src/form/components/fields/name.js:175
"Number of columns" => array( null, __("Number of columns", "forminator" ), ), // src/form/components/fields/name.js:204
"Limits" => array( null, __("Limits", "forminator" ), ), // src/form/components/fields/number.js:89
"Set the minimum and maximum values the user can choose. Leave the fields blank to allow any number including negatives." => array( null, __("Set the minimum and maximum values the user can choose. Leave the fields blank to allow any number including negatives.", "forminator" ), ), // src/form/components/fields/number.js:91
"Minimum" => array( null, __("Minimum", "forminator" ), ), // src/form/components/fields/number.js:105
"Maximum" => array( null, __("Maximum", "forminator" ), ), // src/form/components/fields/number.js:114
"Step label" => array( null, __("Step label", "forminator" ), ), // src/form/components/fields/pagination.js:24
"Enter step label" => array( null, __("Enter step label", "forminator" ), ), // src/form/components/fields/pagination.js:25
"Buttons Text" => array( null, __("Buttons Text", "forminator" ), ), // src/form/components/fields/pagination.js:31
"Choose whether you want to use default text for the Previous and Next button or use custom text." => array( null, __("Choose whether you want to use default text for the Previous and Next button or use custom text.", "forminator" ), ), // src/form/components/fields/pagination.js:33
"Previous Button" => array( null, __("Previous Button", "forminator" ), ), // src/form/components/fields/pagination.js:49
"Enter text" => array( null, __("Enter text", "forminator" ), ), // src/form/components/fields/pagination.js:50
"Next Button" => array( null, __("Next Button", "forminator" ), ), // src/form/components/fields/pagination.js:55
"Confirm Password" => array( null, __("Confirm Password", "forminator" ), ), // src/form/components/fields/password.js:70
"Confirm password" => array( null, __("Confirm password", "forminator" ), ), // src/form/components/fields/password.js:81
"Confirm new password" => array( null, __("Confirm new password", "forminator" ), ), // src/form/components/fields/password.js:91
"Minimum password strength" => array( null, __("Minimum password strength", "forminator" ), ), // src/form/components/fields/password.js:122
"Choose a minimum password strength required to force your users to sign up with a password stronger than the minimum requirement." => array( null, __("Choose a minimum password strength required to force your users to sign up with a password stronger than the minimum requirement.", "forminator" ), ), // src/form/components/fields/password.js:124
"Short" => array( null, __("Short", "forminator" ), ), // src/form/components/fields/password.js:140
"Bad" => array( null, __("Bad", "forminator" ), ), // src/form/components/fields/password.js:141
"Good" => array( null, __("Good", "forminator" ), ), // src/form/components/fields/password.js:142
"Strong" => array( null, __("Strong", "forminator" ), ), // src/form/components/fields/password.js:143
"This is displayed when the user's password is weaker than the minimum requirement." => array( null, __("This is displayed when the user's password is weaker than the minimum requirement.", "forminator" ), ), // src/form/components/fields/password.js:156
"Password validation error message" => array( null, __("Password validation error message", "forminator" ), ), // src/form/components/fields/password.js:170
"Enter an error message to be displayed when the passwords do not match." => array( null, __("Enter an error message to be displayed when the passwords do not match.", "forminator" ), ), // src/form/components/fields/password.js:172
"Passwords do not match. Please try again." => array( null, __("Passwords do not match. Please try again.", "forminator" ), ), // src/form/components/fields/password.js:181
"In %s" => array( null, __("In %s", "forminator" ), ), // src/form/components/fields/paypal.js:84
"You have not connected your PayPal account with Forminator. Connect your PayPal account {{link}}here{{/link}} and then come back to configure this field." => array( null, __("You have not connected your PayPal account with Forminator. Connect your PayPal account {{link}}here{{/link}} and then come back to configure this field.", "forminator" ), ), // src/form/components/fields/paypal.js:116
"Mode of payment" => array( null, __("Mode of payment", "forminator" ), ), // src/form/components/fields/paypal.js:140
"We recommend using sandbox mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to the {{strong}}Live{{/strong}} payments mode." => array( null, __("We recommend using sandbox mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to the {{strong}}Live{{/strong}} payments mode.", "forminator" ), ), // src/form/components/fields/paypal.js:143
"Sandbox" => array( null, __("Sandbox", "forminator" ), ), // src/form/components/fields/paypal.js:153
"Live" => array( null, __("Live", "forminator" ), ), // src/form/components/fields/paypal.js:154
"Charge currency" => array( null, __("Charge currency", "forminator" ), ), // src/form/components/fields/paypal.js:160
"It's recommended to charge in your customers' currency to drive more sales and avoid foreign exchange fee to your customers." => array( null, __("It's recommended to charge in your customers' currency to drive more sales and avoid foreign exchange fee to your customers.", "forminator" ), ), // src/form/components/fields/paypal.js:162
"Payment amount" => array( null, __("Payment amount", "forminator" ), ), // src/form/components/fields/paypal.js:178
"Fixed" => array( null, __("Fixed", "forminator" ), ), // src/form/components/fields/paypal.js:185
"Fixed amount" => array( null, __("Fixed amount", "forminator" ), ), // src/form/components/fields/paypal.js:195
"E.g. 20.00" => array( null, __("E.g. 20.00", "forminator" ), ), // src/form/components/fields/paypal.js:197
"Enter an amount or choose a form field." => array( null, __("Enter an amount or choose a form field.", "forminator" ), ), // src/form/components/fields/paypal.js:199
"Variable amount" => array( null, __("Variable amount", "forminator" ), ), // src/form/components/fields/paypal.js:218
"Select field" => array( null, __("Select field", "forminator" ), ), // src/form/components/fields/paypal.js:229
"A currency field can be used to take user-defined payments such as donations and calculation field can be used to charge a calculated value based on a formula." => array( null, __("A currency field can be used to take user-defined payments such as donations and calculation field can be used to charge a calculated value based on a formula.", "forminator" ), ), // src/form/components/fields/paypal.js:242
"Choose a label for your PayPal button. Note that PayPal checkout doesn't allow a custom label for the PayPal button. You can only choose from the pre-defined labels." => array( null, __("Choose a label for your PayPal button. Note that PayPal checkout doesn't allow a custom label for the PayPal button. You can only choose from the pre-defined labels.", "forminator" ), ), // src/form/components/fields/paypal.js:264
"PayPal recommends using the Gold button since it is widely known as their brand color. However, if that does not suit your theme, you can choose a different color." => array( null, __("PayPal recommends using the Gold button since it is widely known as their brand color. However, if that does not suit your theme, you can choose a different color.", "forminator" ), ), // src/form/components/fields/paypal.js:283
"Gold" => array( null, __("Gold", "forminator" ), ), // src/form/components/fields/paypal.js:289
"Blue" => array( null, __("Blue", "forminator" ), ), // src/form/components/fields/paypal.js:290
"Silver" => array( null, __("Silver", "forminator" ), ), // src/form/components/fields/paypal.js:291
"White" => array( null, __("White", "forminator" ), ), // src/form/components/fields/paypal.js:292
"Black" => array( null, __("Black", "forminator" ), ), // src/form/components/fields/paypal.js:293
"E.g. 250" => array( null, __("E.g. 250", "forminator" ), ), // src/form/components/fields/paypal.js:315
"px" => array( null, __("px", "forminator" ), ), // src/form/components/fields/paypal.js:321
"Choose the width of PayPal Smart Buttons. It can be anywhere between 150px to 750px. Leave this empty if you want the buttons to take the full width of the form up to the 750px limit." => array( null, __("Choose the width of PayPal Smart Buttons. It can be anywhere between 150px to 750px. Leave this empty if you want the buttons to take the full width of the form up to the 750px limit.", "forminator" ), ), // src/form/components/fields/paypal.js:324
"Choose the height of PayPal Smart Buttons. It can be anywhere between 25px to 55px" => array( null, __("Choose the height of PayPal Smart Buttons. It can be anywhere between 25px to 55px", "forminator" ), ), // src/form/components/fields/paypal.js:360
"Shape" => array( null, __("Shape", "forminator" ), ), // src/form/components/fields/paypal.js:371
"Choose your preferred shape from your PayPal Smart Buttons." => array( null, __("Choose your preferred shape from your PayPal Smart Buttons.", "forminator" ), ), // src/form/components/fields/paypal.js:374
"Rectangular" => array( null, __("Rectangular", "forminator" ), ), // src/form/components/fields/paypal.js:379
"Pill" => array( null, __("Pill", "forminator" ), ), // src/form/components/fields/paypal.js:380
"We recommend the vertical layout as it allows additional payment methods such as Credit Cards. You can read about the layout options {{link}}here{{/link}}." => array( null, __("We recommend the vertical layout as it allows additional payment methods such as Credit Cards. You can read about the layout options {{link}}here{{/link}}.", "forminator" ), ), // src/form/components/fields/paypal.js:390
"Tagline" => array( null, __("Tagline", "forminator" ), ), // src/form/components/fields/paypal.js:409
"Choose whether to show the default PayPal tagline {{strong}}\"The safer, easier way to pay\"{{/strong}} below your PayPal button." => array( null, __("Choose whether to show the default PayPal tagline {{strong}}\"The safer, easier way to pay\"{{/strong}} below your PayPal button.", "forminator" ), ), // src/form/components/fields/paypal.js:412
"Disable Funding Sources" => array( null, __("Disable Funding Sources", "forminator" ), ), // src/form/components/fields/paypal.js:434
"PayPal automatically adds additional funding sources to the PayPal checkout for visitors from supported countries. However, you can choose to disable funding sources which shouldn't be displayed to visitors." => array( null, __("PayPal automatically adds additional funding sources to the PayPal checkout for visitors from supported countries. However, you can choose to disable funding sources which shouldn't be displayed to visitors.", "forminator" ), ), // src/form/components/fields/paypal.js:441
"Credit or debit cards" => array( null, __("Credit or debit cards", "forminator" ), ), // src/form/components/fields/paypal.js:455
"PayPal Credit" => array( null, __("PayPal Credit", "forminator" ), ), // src/form/components/fields/paypal.js:462
"Bancontact" => array( null, __("Bancontact", "forminator" ), ), // src/form/components/fields/paypal.js:469
"BLIK" => array( null, __("BLIK", "forminator" ), ), // src/form/components/fields/paypal.js:476
"eps" => array( null, __("eps", "forminator" ), ), // src/form/components/fields/paypal.js:483
"giropay" => array( null, __("giropay", "forminator" ), ), // src/form/components/fields/paypal.js:490
"iDEAL" => array( null, __("iDEAL", "forminator" ), ), // src/form/components/fields/paypal.js:497
"Mercado Pago" => array( null, __("Mercado Pago", "forminator" ), ), // src/form/components/fields/paypal.js:506
"MyBank" => array( null, __("MyBank", "forminator" ), ), // src/form/components/fields/paypal.js:513
"Przelewy24" => array( null, __("Przelewy24", "forminator" ), ), // src/form/components/fields/paypal.js:520
"SEPA-Lastschrift" => array( null, __("SEPA-Lastschrift", "forminator" ), ), // src/form/components/fields/paypal.js:527
"Sofort" => array( null, __("Sofort", "forminator" ), ), // src/form/components/fields/paypal.js:534
"Venmo" => array( null, __("Venmo", "forminator" ), ), // src/form/components/fields/paypal.js:541
"Pre-fill Billing Details" => array( null, __("Pre-fill Billing Details", "forminator" ), ), // src/form/components/fields/paypal.js:551
"Pre-fill the payer's billing info collected on your form on the Debit or Credit Card checkout, so the payer doesn't have to enter those details again." => array( null, __("Pre-fill the payer's billing info collected on your form on the Debit or Credit Card checkout, so the payer doesn't have to enter those details again.", "forminator" ), ), // src/form/components/fields/paypal.js:558
"Customer name (optional)" => array( null, __("Customer name (optional)", "forminator" ), ), // src/form/components/fields/paypal.js:586
"Select a name field" => array( null, __("Select a name field", "forminator" ), ), // src/form/components/fields/paypal.js:595
"Customer email address (optional)" => array( null, __("Customer email address (optional)", "forminator" ), ), // src/form/components/fields/paypal.js:610
"Select an email field" => array( null, __("Select an email field", "forminator" ), ), // src/form/components/fields/paypal.js:619
"Billing address (optional)" => array( null, __("Billing address (optional)", "forminator" ), ), // src/form/components/fields/paypal.js:637
"Select an address field" => array( null, __("Select an address field", "forminator" ), ), // src/form/components/fields/paypal.js:646
"Ensure the Country option is enabled and required for {{strong}}%(fieldName)s{{/strong}} to process Paypal’s transaction successfully." => array( null, __("Ensure the Country option is enabled and required for {{strong}}%(fieldName)s{{/strong}} to process Paypal’s transaction successfully.", "forminator" ), ), // src/form/components/fields/paypal.js:675
"Shipping Address" => array( null, __("Shipping Address", "forminator" ), ), // src/form/components/fields/paypal.js:712
"If you are selling a product that doesn't need to be shipped, you can choose to disable and hide the shipping address fields from the PayPal payment page." => array( null, __("If you are selling a product that doesn't need to be shipped, you can choose to disable and hide the shipping address fields from the PayPal payment page.", "forminator" ), ), // src/form/components/fields/paypal.js:719
"By default, PayPal detects the language for the visitors based on their geolocation and browser preferences. It is recommended to pass this parameter only if you need the PayPal buttons to render in the same language as the rest of your site. {{link}}Supported locale codes.{{/link}}" => array( null, __("By default, PayPal detects the language for the visitors based on their geolocation and browser preferences. It is recommended to pass this parameter only if you need the PayPal buttons to render in the same language as the rest of your site. {{link}}Supported locale codes.{{/link}}", "forminator" ), ), // src/form/components/fields/paypal.js:749
"Eg. en_US" => array( null, __("Eg. en_US", "forminator" ), ), // src/form/components/fields/paypal.js:768
"Debug Mode" => array( null, __("Debug Mode", "forminator" ), ), // src/form/components/fields/paypal.js:778
"PayPal debug mode helps troubleshoot any issues. However, it's recommended to disable this in production as it causes a significant increase in the script size and performance decrease." => array( null, __("PayPal debug mode helps troubleshoot any issues. However, it's recommended to disable this in production as it causes a significant increase in the script size and performance decrease.", "forminator" ), ), // src/form/components/fields/paypal.js:785
"Hide or show input labels" => array( null, __("Hide or show input labels", "forminator" ), ), // src/form/components/fields/pdf/all-form-data.js:64
"Enter form fields to remove from PDF." => array( null, __("Enter form fields to remove from PDF.", "forminator" ), ), // src/form/components/fields/pdf/all-form-data.js:78
"Form field exclusion" => array( null, __("Form field exclusion", "forminator" ), ), // src/form/components/fields/pdf/all-form-data.js:80
"Use the input option to remove specific field(s) from your PDF file." => array( null, __("Use the input option to remove specific field(s) from your PDF file.", "forminator" ), ), // src/form/components/fields/pdf/all-form-data.js:81
"Hide label" => array( null, __("Hide label", "forminator" ), ), // src/form/components/fields/pdf/rich-text.js:36
"Make sure the users fill this field as per the selected validation and warn them when they haven't" => array( null, __("Make sure the users fill this field as per the selected validation and warn them when they haven't", "forminator" ), ), // src/form/components/fields/phone.js:43
"National" => array( null, __("National", "forminator" ), ), // src/form/components/fields/phone.js:62
"Select the country to validate phone number for" => array( null, __("Select the country to validate phone number for", "forminator" ), ), // src/form/components/fields/phone.js:69
"Validation message" => array( null, __("Validation message", "forminator" ), ), // src/form/components/fields/phone.js:80
"Enter validation message" => array( null, __("Enter validation message", "forminator" ), ), // src/form/components/fields/phone.js:82
"International" => array( null, __("International", "forminator" ), ), // src/form/components/fields/phone.js:88
"Default country" => array( null, __("Default country", "forminator" ), ), // src/form/components/fields/phone.js:95
"Character Limit" => array( null, __("Character Limit", "forminator" ), ), // src/form/components/fields/phone.js:115
"Limit field to" => array( null, __("Limit field to", "forminator" ), ), // src/form/components/fields/phone.js:122
"10" => array( null, __("10", "forminator" ), ), // src/form/components/fields/phone.js:124
"Characters" => array( null, __("Characters", "forminator" ), ), // src/form/components/fields/phone.js:126
"Title" => array( null, __("Title", "forminator" ), ), // src/form/components/fields/postdata.js:26
"Content" => array( null, __("Content", "forminator" ), ), // src/form/components/fields/postdata.js:31
"Excerpt" => array( null, __("Excerpt", "forminator" ), ), // src/form/components/fields/postdata.js:36
"Featured Image" => array( null, __("Featured Image", "forminator" ), ), // src/form/components/fields/postdata.js:41
"Custom Fields" => array( null, __("Custom Fields", "forminator" ), ), // src/form/components/fields/postdata.js:66
"Allow users to submit post data with this field. By default, this will create new posts, but you can assign it to any post type in the {{strong}}Settings{{/strong}} tab." => array( null, __("Allow users to submit post data with this field. By default, this will create new posts, but you can assign it to any post type in the {{strong}}Settings{{/strong}} tab.", "forminator" ), ), // src/form/components/fields/postdata.js:86
"Post type" => array( null, __("Post type", "forminator" ), ), // src/form/components/fields/postdata.js:248
"Choose the post type associated with this field." => array( null, __("Choose the post type associated with this field.", "forminator" ), ), // src/form/components/fields/postdata.js:251
"Assigned post type" => array( null, __("Assigned post type", "forminator" ), ), // src/form/components/fields/postdata.js:258
"post" => array( null, __("post", "forminator" ), ), // src/form/components/fields/postdata.js:259
"Default status" => array( null, __("Default status", "forminator" ), ), // src/form/components/fields/postdata.js:278
"When a user submits this form, choose what status this post data is." => array( null, __("When a user submits this form, choose what status this post data is.", "forminator" ), ), // src/form/components/fields/postdata.js:282
"pending" => array( null, __("pending", "forminator" ), ), // src/form/components/fields/postdata.js:292
"Draft" => array( null, __("Draft", "forminator" ), ), // src/form/components/fields/postdata.js:297
"Pending Review" => array( null, __("Pending Review", "forminator" ), ), // src/form/components/fields/postdata.js:300
"Published" => array( null, __("Published", "forminator" ), ), // src/form/components/fields/postdata.js:303
"Default author" => array( null, __("Default author", "forminator" ), ), // src/form/components/fields/postdata.js:312
"By default we'll assign posts to users if they're logged in, and fall back to the user specified below if you're allowing visitors to make posts. You can also override this to always assign posts to a specified user." => array( null, __("By default we'll assign posts to users if they're logged in, and fall back to the user specified below if you're allowing visitors to make posts. You can also override this to always assign posts to a specified user.", "forminator" ), ), // src/form/components/fields/postdata.js:315
"Always assign posts to this user" => array( null, __("Always assign posts to this user", "forminator" ), ), // src/form/components/fields/postdata.js:344
"Taxonomies limits" => array( null, __("Taxonomies limits", "forminator" ), ), // src/form/components/fields/postdata.js:357
"Choose whether to allow single or multiple categories or tags on this post." => array( null, __("Choose whether to allow single or multiple categories or tags on this post.", "forminator" ), ), // src/form/components/fields/postdata.js:360
"Enter title" => array( null, __("Enter title", "forminator" ), ), // src/form/components/fields/section.js:31
"Subtitle (optional)" => array( null, __("Subtitle (optional)", "forminator" ), ), // src/form/components/fields/section.js:39
"Enter subtitle" => array( null, __("Enter subtitle", "forminator" ), ), // src/form/components/fields/section.js:40
"Add a border to this section." => array( null, __("Add a border to this section.", "forminator" ), ), // src/form/components/fields/section.js:55
"Signature Filetype" => array( null, __("Signature Filetype", "forminator" ), ), // src/form/components/fields/signature.js:30
"Choose the filetype to save your users' signature in." => array( null, __("Choose the filetype to save your users' signature in.", "forminator" ), ), // src/form/components/fields/signature.js:32
"PNG" => array( null, __("PNG", "forminator" ), ), // src/form/components/fields/signature.js:46
"JPG" => array( null, __("JPG", "forminator" ), ), // src/form/components/fields/signature.js:47
"Choose the height of your signature field. The default value is 180px." => array( null, __("Choose the height of your signature field. The default value is 180px.", "forminator" ), ), // src/form/components/fields/signature.js:55
"Stroke Thickness" => array( null, __("Stroke Thickness", "forminator" ), ), // src/form/components/fields/signature.js:73
"Choose the thickness in pixels for signature strokes. The default value is 2px." => array( null, __("Choose the thickness in pixels for signature strokes. The default value is 2px.", "forminator" ), ), // src/form/components/fields/signature.js:75
"Note: Pass comma-separated values for this query parameter to pre-populate multiple options." => array( null, __("Note: Pass comma-separated values for this query parameter to pre-populate multiple options.", "forminator" ), ), // src/form/components/fields/singlevalue.js:32
"Search" => array( null, __("Search", "forminator" ), ), // src/form/components/fields/singlevalue.js:112
"Display the search box in a dropdown" => array( null, __("Display the search box in a dropdown", "forminator" ), ), // src/form/components/fields/singlevalue.js:120
"Limit Submission" => array( null, __("Limit Submission", "forminator" ), ), // src/form/components/fields/singlevalue.js:147
"You can limit submissions of each option to a certain number, and once an option reaches the submission limit, we'll hide that option from the dropdown list." => array( null, __("You can limit submissions of each option to a certain number, and once an option reaches the submission limit, we'll hide that option from the dropdown list.", "forminator" ), ), // src/form/components/fields/singlevalue.js:155
"You can set a limit for your options in the LABELS tab. Options for which limit field is left empty can have unlimited submissions." => array( null, __("You can set a limit for your options in the LABELS tab. Options for which limit field is left empty can have unlimited submissions.", "forminator" ), ), // src/form/components/fields/singlevalue.js:200
"Choose whether to allow this field to be used in calculations or not. The value used in calculations is the same as the input value of this field." => array( null, __("Choose whether to allow this field to be used in calculations or not. The value used in calculations is the same as the input value of this field.", "forminator" ), ), // src/form/components/fields/singlevalue.js:226
"Credit / Debit Card" => array( null, __("Credit / Debit Card", "forminator" ), ), // src/form/components/fields/stripe.js:174
"Choose your preferred language for the Stripe field. This will affect the placeholders language, and the card validation errors returned by the Stripe." => array( null, __("Choose your preferred language for the Stripe field. This will affect the placeholders language, and the card validation errors returned by the Stripe.", "forminator" ), ), // src/form/components/fields/stripe.js:199
"Auto" => array( null, __("Auto", "forminator" ), ), // src/form/components/fields/stripe.js:205
"English (en)" => array( null, __("English (en)", "forminator" ), ), // src/form/components/fields/stripe.js:206
"Simplified Chinese (zh)" => array( null, __("Simplified Chinese (zh)", "forminator" ), ), // src/form/components/fields/stripe.js:207
"Danish (da)" => array( null, __("Danish (da)", "forminator" ), ), // src/form/components/fields/stripe.js:208
"Dutch (nl)" => array( null, __("Dutch (nl)", "forminator" ), ), // src/form/components/fields/stripe.js:209
"Finnish (fi)" => array( null, __("Finnish (fi)", "forminator" ), ), // src/form/components/fields/stripe.js:210
"French (fr)" => array( null, __("French (fr)", "forminator" ), ), // src/form/components/fields/stripe.js:211
"German (de)" => array( null, __("German (de)", "forminator" ), ), // src/form/components/fields/stripe.js:212
"Italian (it)" => array( null, __("Italian (it)", "forminator" ), ), // src/form/components/fields/stripe.js:213
"Japanese (ja)" => array( null, __("Japanese (ja)", "forminator" ), ), // src/form/components/fields/stripe.js:214
"Norwegian (no)" => array( null, __("Norwegian (no)", "forminator" ), ), // src/form/components/fields/stripe.js:215
"Spanish (es)" => array( null, __("Spanish (es)", "forminator" ), ), // src/form/components/fields/stripe.js:216
"Swedish (sv)" => array( null, __("Swedish (sv)", "forminator" ), ), // src/form/components/fields/stripe.js:217
"Card icon" => array( null, __("Card icon", "forminator" ), ), // src/form/components/fields/stripe.js:228
"Choose whether you want to show the card icon on the Stripe field." => array( null, __("Choose whether you want to show the card icon on the Stripe field.", "forminator" ), ), // src/form/components/fields/stripe.js:229
"Postal code" => array( null, __("Postal code", "forminator" ), ), // src/form/components/fields/stripe.js:246
"Choose whether you want to collect the postal code on the Stripe field." => array( null, __("Choose whether you want to collect the postal code on the Stripe field.", "forminator" ), ), // src/form/components/fields/stripe.js:247
"Prefill (optional)" => array( null, __("Prefill (optional)", "forminator" ), ), // src/form/components/fields/stripe.js:267
"If you are already collecting ZIP code on your form, you can pre-fill it on the Stripe field." => array( null, __("If you are already collecting ZIP code on your form, you can pre-fill it on the Stripe field.", "forminator" ), ), // src/form/components/fields/stripe.js:289
"You have not connected your Stripe account with Forminator. Connect your Stripe account {{link}}here{{/link}} and then come back to configure this field." => array( null, __("You have not connected your Stripe account with Forminator. Connect your Stripe account {{link}}here{{/link}} and then come back to configure this field.", "forminator" ), ), // src/form/components/fields/stripe.js:326
"Payment Mode" => array( null, __("Payment Mode", "forminator" ), ), // src/form/components/fields/stripe.js:347
"We recommend using Test mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to Live payments mode. " => array( null, __("We recommend using Test mode to ensure the payments are working as expected and when you are ready to start collecting live payments, switch to Live payments mode. ", "forminator" ), ), // src/form/components/fields/stripe.js:355
"Test" => array( null, __("Test", "forminator" ), ), // src/form/components/fields/stripe.js:369
"Choose the currency your users will be charged in." => array( null, __("Choose the currency your users will be charged in.", "forminator" ), ), // src/form/components/fields/stripe.js:378
"Payment Plan" => array( null, __("Payment Plan", "forminator" ), ), // src/form/components/fields/stripe.js:393
"Payment plans let you set up options for accepting payments on your site. You can add multiple plans and conditionally process them based on your form data." => array( null, __("Payment plans let you set up options for accepting payments on your site. You can add multiple plans and conditionally process them based on your form data.", "forminator" ), ), // src/form/components/fields/stripe.js:401
"Note: You'll need to configure conditions on each plan to let Forminator know when to process each of the payment plans below." => array( null, __("Note: You'll need to configure conditions on each plan to let Forminator know when to process each of the payment plans below.", "forminator" ), ), // src/form/components/fields/stripe.js:423
"There is an error in one or more of your payment plans. Please review the error and try again." => array( null, __("There is an error in one or more of your payment plans. Please review the error and try again.", "forminator" ), ), // src/form/components/fields/stripe.js:450
"Payment Receipt" => array( null, __("Payment Receipt", "forminator" ), ), // src/form/components/fields/stripe.js:479
"Choose whether you want Stripe to email a receipt to your customers on successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}." => array( null, __("Choose whether you want Stripe to email a receipt to your customers on successful payment. Note that Stripe sends the email receipt only for live payments. {{link}}Customize email template{{/link}}.", "forminator" ), ), // src/form/components/fields/stripe.js:487
"Email address" => array( null, __("Email address", "forminator" ), ), // src/form/components/fields/stripe.js:516
"E.g. john@doe.com" => array( null, __("E.g. john@doe.com", "forminator" ), ), // src/form/components/fields/stripe.js:518
"Payment Details (optional)" => array( null, __("Payment Details (optional)", "forminator" ), ), // src/form/components/fields/stripe.js:545
"You can add a statement decipher and a description to help you and your customers recognise the transactions made on this form." => array( null, __("You can add a statement decipher and a description to help you and your customers recognise the transactions made on this form.", "forminator" ), ), // src/form/components/fields/stripe.js:553
"Statement decipher" => array( null, __("Statement decipher", "forminator" ), ), // src/form/components/fields/stripe.js:563
"E.g. Company Name" => array( null, __("E.g. Company Name", "forminator" ), ), // src/form/components/fields/stripe.js:566
"This is the business name your customers will see on their card statement." => array( null, __("This is the business name your customers will see on their card statement.", "forminator" ), ), // src/form/components/fields/stripe.js:569
"Up to 22 characters only" => array( null, __("Up to 22 characters only", "forminator" ), ), // src/form/components/fields/stripe.js:574
"Enter your payment description here" => array( null, __("Enter your payment description here", "forminator" ), ), // src/form/components/fields/stripe.js:582
"This appears on your Stripe account and on the payment receipt sent to your customers." => array( null, __("This appears on your Stripe account and on the payment receipt sent to your customers.", "forminator" ), ), // src/form/components/fields/stripe.js:585
"Payment description" => array( null, __("Payment description", "forminator" ), ), // src/form/components/fields/stripe.js:589
"Card Validation" => array( null, __("Card Validation", "forminator" ), ), // src/form/components/fields/stripe.js:607
"Note: Stripe field automatically validates the card as the user fills the card details regardless of the validation behavior set on the Behaviours tab." => array( null, __("Note: Stripe field automatically validates the card as the user fills the card details regardless of the validation behavior set on the Behaviours tab.", "forminator" ), ), // src/form/components/fields/stripe.js:625
"Billing Details" => array( null, __("Billing Details", "forminator" ), ), // src/form/components/fields/stripe.js:642
"If you are collecting billing details on your forms, you can send that data to Stripe. The billing details will appear on your Stripe dashboard for each payment." => array( null, __("If you are collecting billing details on your forms, you can send that data to Stripe. The billing details will appear on your Stripe dashboard for each payment.", "forminator" ), ), // src/form/components/fields/stripe.js:650
"Meta Data" => array( null, __("Meta Data", "forminator" ), ), // src/form/components/fields/stripe.js:734
"You can send custom meta data to Stripe. This would appear under the MetaData section of every payment. A maximum of 20 meta keys can be sent. The key name must be 20 characters or less, and the mapped data will be truncated to 500 characters as Stripe's requirements." => array( null, __("You can send custom meta data to Stripe. This would appear under the MetaData section of every payment. A maximum of 20 meta keys can be sent. The key name must be 20 characters or less, and the mapped data will be truncated to 500 characters as Stripe's requirements.", "forminator" ), ), // src/form/components/fields/stripe.js:742
"MetaData" => array( null, __("MetaData", "forminator" ), ), // src/form/components/fields/stripe.js:785
"Additional CSS Classes" => array( null, __("Additional CSS Classes", "forminator" ), ), // src/form/components/fields/stripe.js:802
"Stripe automatically adds classes to the container DOM element based on the field state. However, you can customize them here. {{link}}Read more{{/link}}" => array( null, __("Stripe automatically adds classes to the container DOM element based on the field state. However, you can customize them here. {{link}}Read more{{/link}}", "forminator" ), ), // src/form/components/fields/stripe.js:805
"Base class" => array( null, __("Base class", "forminator" ), ), // src/form/components/fields/stripe.js:821
"Complete" => array( null, __("Complete", "forminator" ), ), // src/form/components/fields/stripe.js:829
"Empty" => array( null, __("Empty", "forminator" ), ), // src/form/components/fields/stripe.js:837
"Focused" => array( null, __("Focused", "forminator" ), ), // src/form/components/fields/stripe.js:845
"Invalid" => array( null, __("Invalid", "forminator" ), ), // src/form/components/fields/stripe.js:853
"Autofilled (Chrome and Safari only)" => array( null, __("Autofilled (Chrome and Safari only)", "forminator" ), ), // src/form/components/fields/stripe.js:861
"One Time" => array( null, __("One Time", "forminator" ), ), // src/form/components/fields/stripe/payment-plan.js:54
"Subscription" => array( null, __("Subscription", "forminator" ), ), // src/form/components/fields/stripe/payment-plan.js:58
"Remove This Plan" => array( null, __("Remove This Plan", "forminator" ), ), // src/form/components/fields/stripe/payment-plan.js:143
"Open Plan Settings" => array( null, __("Open Plan Settings", "forminator" ), ), // src/form/components/fields/stripe/payment-plan.js:156
"Plan setup" => array( null, __("Plan setup", "forminator" ), ), // src/form/components/fields/stripe/payment-plan.js:189
"Plan" => array( null, __("Plan", "forminator" ), ), // src/form/components/fields/stripe/payment-plans.js:67
"Add Another Plan" => array( null, __("Add Another Plan", "forminator" ), ), // src/form/components/fields/stripe/payment-plans.js:120
"The Stripe Subscription Add-ons is required to use this feature. Install it from the Add-ons page." => array( null, __("The Stripe Subscription Add-ons is required to use this feature. Install it from the Add-ons page.", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:31
"The Stripe Subscription Add-on is required to use this feature. Upgrade to Pro to install the add-on." => array( null, __("The Stripe Subscription Add-on is required to use this feature. Upgrade to Pro to install the add-on.", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:34
"Subscription {{span}}Pro{{/span}}" => array( null, __("Subscription {{span}}Pro{{/span}}", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:40
"Plan name" => array( null, __("Plan name", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:56
"This will be displayed on the submissions as well as the Stripe dashboard." => array( null, __("This will be displayed on the submissions as well as the Stripe dashboard.", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:58
"Plan Name is required." => array( null, __("Plan Name is required.", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:64
"Payment type" => array( null, __("Payment type", "forminator" ), ), // src/form/components/fields/stripe/plan-setup.js:76
"Plan amount" => array( null, __("Plan amount", "forminator" ), ), // src/form/components/fields/stripe/single-payment.js:68
"Enter an amount or select a value from a form field in the Variable tab." => array( null, __("Enter an amount or select a value from a form field in the Variable tab.", "forminator" ), ), // src/form/components/fields/stripe/single-payment.js:69
"E.g., 20.00" => array( null, __("E.g., 20.00", "forminator" ), ), // src/form/components/fields/stripe/single-payment.js:90
"Amount" => array( null, __("Amount", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:100
"Quantity" => array( null, __("Quantity", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:141
"Enter the quantity or let your users set the quantity in a form field." => array( null, __("Enter the quantity or let your users set the quantity in a form field.", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:142
"E.g., 1" => array( null, __("E.g., 1", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:162
"Please enter a quantity or select a form field." => array( null, __("Please enter a quantity or select a form field.", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:166
"Bill every" => array( null, __("Bill every", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:203
"Duration cannot be empty." => array( null, __("Duration cannot be empty.", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:219
"Day(s)" => array( null, __("Day(s)", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:232
"Week(s)" => array( null, __("Week(s)", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:233
"Month(s)" => array( null, __("Month(s)", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:234
"Year(s)" => array( null, __("Year(s)", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:235
"Allow Trial Period" => array( null, __("Allow Trial Period", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:251
"Check this option to offer a limited-time free trial for this plan" => array( null, __("Check this option to offer a limited-time free trial for this plan", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:252
"Trial Duration" => array( null, __("Trial Duration", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:267
"Enter the number of days that users will try your product for free before they start paying." => array( null, __("Enter the number of days that users will try your product for free before they start paying.", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:268
"E.g., 14" => array( null, __("E.g., 14", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:274
"Days" => array( null, __("Days", "forminator" ), ), // src/form/components/fields/stripe/subscription.js:275
"Max characters" => array( null, __("Max characters", "forminator" ), ), // src/form/components/fields/text.js:81
"By default the user can enter as many characters as they want. Use this setting to limit the number of characters the user can enter. Leave field blank to allow unlimited characters." => array( null, __("By default the user can enter as many characters as they want. Use this setting to limit the number of characters the user can enter. Leave field blank to allow unlimited characters.", "forminator" ), ), // src/form/components/fields/text.js:82
"Character limit" => array( null, __("Character limit", "forminator" ), ), // src/form/components/fields/text.js:90
"E.g. 100" => array( null, __("E.g. 100", "forminator" ), ), // src/form/components/fields/text.js:97
"Words" => array( null, __("Words", "forminator" ), ), // src/form/components/fields/text.js:108
"You can add new line" => array( null, __("You can add new line", "forminator" ), ), // src/form/components/fields/textarea.js:49
"Rich-Text editor" => array( null, __("Rich-Text editor", "forminator" ), ), // src/form/components/fields/textarea.js:77
"Enable TinyMCE editor to allow the formatted text." => array( null, __("Enable TinyMCE editor to allow the formatted text.", "forminator" ), ), // src/form/components/fields/textarea.js:78
"Default height" => array( null, __("Default height", "forminator" ), ), // src/form/components/fields/textarea.js:142
"Choose the default minimum height of your textarea field." => array( null, __("Choose the default minimum height of your textarea field.", "forminator" ), ), // src/form/components/fields/textarea.js:146
"{{strong}}Note:{{/strong}} The query parameter's value passed in URL should match with the selected time format." => array( null, __("{{strong}}Note:{{/strong}} The query parameter's value passed in URL should match with the selected time format.", "forminator" ), ), // src/form/components/fields/time.js:194
"Number inputs" => array( null, __("Number inputs", "forminator" ), ), // src/form/components/fields/time.js:232
"Format" => array( null, __("Format", "forminator" ), ), // src/form/components/fields/time.js:240
"12 hour" => array( null, __("12 hour", "forminator" ), ), // src/form/components/fields/time.js:243
"24 hour" => array( null, __("24 hour", "forminator" ), ), // src/form/components/fields/time.js:244
"We have mapped the time limit you have set to match the new time format you have chosen. falseYou can adjust this limit under the Settings tab." => array( null, __("We have mapped the time limit you have set to match the new time format you have chosen. falseYou can adjust this limit under the Settings tab.", "forminator" ), ), // src/form/components/fields/time.js:267
"Hours" => array( null, __("Hours", "forminator" ), ), // src/form/components/fields/time.js:305
"Minutes" => array( null, __("Minutes", "forminator" ), ), // src/form/components/fields/time.js:331
"Increments" => array( null, __("Increments", "forminator" ), ), // src/form/components/fields/time.js:367
"Choose what time increments you want to use for the hour and minute timepickers." => array( null, __("Choose what time increments you want to use for the hour and minute timepickers.", "forminator" ), ), // src/form/components/fields/time.js:369
"Hour" => array( null, __("Hour", "forminator" ), ), // src/form/components/fields/time.js:380
"Minute" => array( null, __("Minute", "forminator" ), ), // src/form/components/fields/time.js:392
"Choose a time limit for the time picker field to restrict the time selection between specific hours." => array( null, __("Choose a time limit for the time picker field to restrict the time selection between specific hours.", "forminator" ), ), // src/form/components/fields/time.js:406
"Specific Hours" => array( null, __("Specific Hours", "forminator" ), ), // src/form/components/fields/time.js:425
"Start Time" => array( null, __("Start Time", "forminator" ), ), // src/form/components/fields/time.js:428
"AM" => array( null, __("AM", "forminator" ), ), // src/form/components/fields/time.js:463
"PM" => array( null, __("PM", "forminator" ), ), // src/form/components/fields/time.js:464
"End Time" => array( null, __("End Time", "forminator" ), ), // src/form/components/fields/time.js:470
"This error message will be used when time entered is out of the set limits." => array( null, __("This error message will be used when time entered is out of the set limits.", "forminator" ), ), // src/form/components/fields/time.js:519
"Default Time" => array( null, __("Default Time", "forminator" ), ), // src/form/components/fields/time.js:533
"Use this feature to specify a default selected time." => array( null, __("Use this feature to specify a default selected time.", "forminator" ), ), // src/form/components/fields/time.js:535
"Default time can't be outside the allowed time limit." => array( null, __("Default time can't be outside the allowed time limit.", "forminator" ), ), // src/form/components/fields/time.js:600
"Limit number of files" => array( null, __("Limit number of files", "forminator" ), ), // src/form/components/fields/upload.js:88
"Choose the maximum number of files that can be uploaded using this field." => array( null, __("Choose the maximum number of files that can be uploaded using this field.", "forminator" ), ), // src/form/components/fields/upload.js:92
"Unlimited" => array( null, __("Unlimited", "forminator" ), ), // src/form/components/fields/upload.js:106
"File upload limit" => array( null, __("File upload limit", "forminator" ), ), // src/form/components/fields/upload.js:122
"Filesize limit per file" => array( null, __("Filesize limit per file", "forminator" ), ), // src/form/components/fields/upload.js:137
"Filesize limit" => array( null, __("Filesize limit", "forminator" ), ), // src/form/components/fields/upload.js:138
"We've detected your server will allow uploads up to %(maxUpload)sMB in size currently. You can set a lower limit than this using the input below, however if you want uploads of more than %(maxUpload)sMB you'll need to adjust this in your server's PHP.ini settings." => array( null, __("We've detected your server will allow uploads up to %(maxUpload)sMB in size currently. You can set a lower limit than this using the input below, however if you want uploads of more than %(maxUpload)sMB you'll need to adjust this in your server's PHP.ini settings.", "forminator" ), ), // src/form/components/fields/upload.js:143
"Upload limit per file" => array( null, __("Upload limit per file", "forminator" ), ), // src/form/components/fields/upload.js:160
"MB" => array( null, __("MB", "forminator" ), ), // src/form/components/fields/upload.js:189
"KB" => array( null, __("KB", "forminator" ), ), // src/form/components/fields/upload.js:190
"B" => array( null, __("B", "forminator" ), ), // src/form/components/fields/upload.js:191
"The file size you have entered exceeds what your current hosting settings are capped to. You need to increase your max filesize limit at the server level first." => array( null, __("The file size you have entered exceeds what your current hosting settings are capped to. You need to increase your max filesize limit at the server level first.", "forminator" ), ), // src/form/components/fields/upload.js:217
"Upload method" => array( null, __("Upload method", "forminator" ), ), // src/form/components/fields/upload.js:237
"Choose whether you want to use AJAX to upload individual files as they are selected or use the traditional method of uploading all files together on form submission. We recommend using the AJAX method to avoid server timeouts." => array( null, __("Choose whether you want to use AJAX to upload individual files as they are selected or use the traditional method of uploading all files together on form submission. We recommend using the AJAX method to avoid server timeouts.", "forminator" ), ), // src/form/components/fields/upload.js:241
"AJAX" => array( null, __("AJAX", "forminator" ), ), // src/form/components/fields/upload.js:256
"On form submission" => array( null, __("On form submission", "forminator" ), ), // src/form/components/fields/upload.js:257
"Show files in media library" => array( null, __("Show files in media library", "forminator" ), ), // src/form/components/fields/upload.js:267
"Choose whether you want to show the files uploaded by your visitors using this field in your media library." => array( null, __("Choose whether you want to show the files uploaded by your visitors using this field in your media library.", "forminator" ), ), // src/form/components/fields/upload.js:271
"Edit PDF" => array( null, __("Edit PDF", "forminator" ), ), // src/form/components/header.js:9
"Edit Form" => array( null, __("Edit Form", "forminator" ), ), // src/form/components/header.js:10
"View Documentation" => array( null, __("View Documentation", "forminator" ), ), // src/form/components/header/documentation.js:14
"Name your form" => array( null, __("Name your form", "forminator" ), ), // src/form/components/header/title.js:38
"Give your form a name" => array( null, __("Give your form a name", "forminator" ), ), // src/form/components/header/title.js:43
"Please, enter a valid name." => array( null, __("Please, enter a valid name.", "forminator" ), ), // src/form/components/header/title.js:70
"Send" => array( null, __("Send", "forminator" ), ), // src/form/components/integrations.js:115
"Don't send" => array( null, __("Don't send", "forminator" ), ), // src/form/components/integrations.js:115
"data if" => array( null, __("data if", "forminator" ), ), // src/form/components/integrations.js:125
"Fetching integration list…" => array( null, __("Fetching integration list…", "forminator" ), ), // src/form/components/integrations.js:223
"You need to save this form before using integrations." => array( null, __("You need to save this form before using integrations.", "forminator" ), ), // src/form/components/integrations.js:247
"Try Again" => array( null, __("Try Again", "forminator" ), ), // src/form/components/integrations.js:257
"Integrations" => array( null, __("Integrations", "forminator" ), ), // src/form/components/integrations.js:279
"Applications" => array( null, __("Applications", "forminator" ), ), // src/form/components/integrations.js:285
"You can send this form's data to any of the connected third party apps. Connect to more apps on the {{link}}Integrations{{/link}} page." => array( null, __("You can send this form's data to any of the connected third party apps. Connect to more apps on the {{link}}Integrations{{/link}} page.", "forminator" ), ), // src/form/components/integrations.js:286
"Email Notifications" => array( null, __("Email Notifications", "forminator" ), ), // src/form/components/integrations.js:304
"Don't Send" => array( null, __("Don't Send", "forminator" ), ), // src/form/components/integrations/conditions.js:136
"of the conditions below are met." => array( null, __("of the conditions below are met.", "forminator" ), ), // src/form/components/integrations/conditions.js:155
"Use conditional logic to send data to this app based on submitted form data." => array( null, __("Use conditional logic to send data to this app based on submitted form data.", "forminator" ), ), // src/form/components/integrations/conditions.js:171
"Add conditions under which data should be sent to this app." => array( null, __("Add conditions under which data should be sent to this app.", "forminator" ), ), // src/form/components/integrations/conditions.js:194
"Login User" => array( null, __("Login User", "forminator" ), ), // src/form/components/login.js:31
"Additional Settings" => array( null, __("Additional Settings", "forminator" ), ), // src/form/components/login/additional-settings.js:20
"These settings will add some extra control on your login process." => array( null, __("These settings will add some extra control on your login process.", "forminator" ), ), // src/form/components/login/additional-settings.js:23
"Hide the form if a user is already logged in" => array( null, __("Hide the form if a user is already logged in", "forminator" ), ), // src/form/components/login/additional-settings.js:34
"Enabling this will hide the form from logged-in users." => array( null, __("Enabling this will hide the form from logged-in users.", "forminator" ), ), // src/form/components/login/additional-settings.js:35
"Message (optional)" => array( null, __("Message (optional)", "forminator" ), ), // src/form/components/login/additional-settings.js:45
"Type a message for logged in users here..." => array( null, __("Type a message for logged in users here...", "forminator" ), ), // src/form/components/login/additional-settings.js:48
"You can optionally add a message for logged in users, which appears when the form is hidden." => array( null, __("You can optionally add a message for logged in users, which appears when the form is hidden.", "forminator" ), ), // src/form/components/login/additional-settings.js:49
"Login Fields" => array( null, __("Login Fields", "forminator" ), ), // src/form/components/login/meta-mapping.js:38
"Map your form fields to the meta keys and have additional control over the login form fields." => array( null, __("Map your form fields to the meta keys and have additional control over the login form fields.", "forminator" ), ), // src/form/components/login/meta-mapping.js:41
"Form Fields Mapping" => array( null, __("Form Fields Mapping", "forminator" ), ), // src/form/components/login/meta-mapping.js:51
"Assign your form fields to the meta keys required to login a user." => array( null, __("Assign your form fields to the meta keys required to login a user.", "forminator" ), ), // src/form/components/login/meta-mapping.js:54
"Username" => array( null, __("Username", "forminator" ), ), // src/form/components/login/meta-mapping.js:65
"Password" => array( null, __("Password", "forminator" ), ), // src/form/components/login/meta-mapping.js:79
"Remember Me Field" => array( null, __("Remember Me Field", "forminator" ), ), // src/form/components/login/meta-mapping.js:95
"Choose whether to show the {{strong}}Remember Me{{/strong}} field in your form. This option will add a Remember Me checkbox before the submit button." => array( null, __("Choose whether to show the {{strong}}Remember Me{{/strong}} field in your form. This option will add a Remember Me checkbox before the submit button.", "forminator" ), ), // src/form/components/login/meta-mapping.js:97
"Remember me" => array( null, __("Remember me", "forminator" ), ), // src/form/components/login/meta-mapping.js:116
"Cookie Expiration" => array( null, __("Cookie Expiration", "forminator" ), ), // src/form/components/login/meta-mapping.js:129
"day(s)" => array( null, __("day(s)", "forminator" ), ), // src/form/components/login/meta-mapping.js:140
"week(s)" => array( null, __("week(s)", "forminator" ), ), // src/form/components/login/meta-mapping.js:143
"month(s)" => array( null, __("month(s)", "forminator" ), ), // src/form/components/login/meta-mapping.js:146
"year(s)" => array( null, __("year(s)", "forminator" ), ), // src/form/components/login/meta-mapping.js:149
"Users will have to provide login details again after the selected period." => array( null, __("Users will have to provide login details again after the selected period.", "forminator" ), ), // src/form/components/login/meta-mapping.js:155
"Something went wrong while saving your form. Please try again." => array( null, __("Something went wrong while saving your form. Please try again.", "forminator" ), ), // src/form/components/meta.js:139
"Unpublish" => array( null, __("Unpublish", "forminator" ), ), // src/form/components/meta/buttons.js:78
"Save Draft" => array( null, __("Save Draft", "forminator" ), ), // src/form/components/meta/buttons.js:84
"Update" => array( null, __("Update", "forminator" ), ), // src/form/components/meta/buttons.js:106
"Save changes" => array( null, __("Save changes", "forminator" ), ), // src/form/components/meta/buttons.js:108
"Publish" => array( null, __("Publish", "forminator" ), ), // src/form/components/meta/buttons.js:110
"Back to form" => array( null, __("Back to form", "forminator" ), ), // src/form/components/meta/status.js:37
"Saving..." => array( null, __("Saving...", "forminator" ), ), // src/form/components/meta/status.js:62
"Unsaved changes" => array( null, __("Unsaved changes", "forminator" ), ), // src/form/components/meta/status.js:69
"Saved" => array( null, __("Saved", "forminator" ), ), // src/form/components/meta/status.js:76
"Access PDF Generator Add-on" => array( null, __("Access PDF Generator Add-on", "forminator" ), ), // src/form/components/modals/access-pdf-addon.js:45
"Create an account with WPMU DEV (the developers of Forminator) to get instant access to PDF Add-on, plus a host of bonus site management tools that come included. It’s fast, easy, and free!" => array( null, __("Create an account with WPMU DEV (the developers of Forminator) to get instant access to PDF Add-on, plus a host of bonus site management tools that come included. It’s fast, easy, and free!", "forminator" ), ), // src/form/components/modals/access-pdf-addon.js:50
"Connect to WPMU DEV" => array( null, __("Connect to WPMU DEV", "forminator" ), ), // src/form/components/modals/access-pdf-addon.js:70
"Already a member? {{link}}Connect site{{/link}}" => array( null, __("Already a member? {{link}}Connect site{{/link}}", "forminator" ), ), // src/form/components/modals/access-pdf-addon.js:82
"Appearance preset successfully applied." => array( null, __("Appearance preset successfully applied.", "forminator" ), ), // src/form/components/modals/apply-preset.js:45
"Something went wrong. Please try again." => array( null, __("Something went wrong. Please try again.", "forminator" ), ), // src/form/components/modals/apply-preset.js:63
"Close this dialog window" => array( null, __("Close this dialog window", "forminator" ), ), // src/form/components/modals/apply-preset.js:82
"Select an appearance preset from the list below to apply the appearance to your form. You can edit or create new presets in {{link}}Settings > Appearance Preset{{/link}}" => array( null, __("Select an appearance preset from the list below to apply the appearance to your form. You can edit or create new presets in {{link}}Settings > Appearance Preset{{/link}}", "forminator" ), ), // src/form/components/modals/apply-preset.js:88
"Your form's current appearance configurations will be overwritten." => array( null, __("Your form's current appearance configurations will be overwritten.", "forminator" ), ), // src/form/components/modals/apply-preset.js:118
"Applying preset..." => array( null, __("Applying preset...", "forminator" ), ), // src/form/components/modals/apply-preset.js:131
"After Submission" => array( null, __("After Submission", "forminator" ), ), // src/form/components/modals/behavior.js:109
"Only used to identify this behavior, and not displayed to users." => array( null, __("Only used to identify this behavior, and not displayed to users.", "forminator" ), ), // src/form/components/modals/behavior.js:172
"E.g., Inline Message" => array( null, __("E.g., Inline Message", "forminator" ), ), // src/form/components/modals/behavior.js:175
"Display an inline success message to the user after the form is submitted." => array( null, __("Display an inline success message to the user after the form is submitted.", "forminator" ), ), // src/form/components/modals/behavior.js:203
"Auto-close success message after" => array( null, __("Auto-close success message after", "forminator" ), ), // src/form/components/modals/behavior.js:230
"E.g. 5" => array( null, __("E.g. 5", "forminator" ), ), // src/form/components/modals/behavior.js:238
"seconds." => array( null, __("seconds.", "forminator" ), ), // src/form/components/modals/behavior.js:247
"https://www.mywebsite.com" => array( null, __("https://www.mywebsite.com", "forminator" ), ), // src/form/components/modals/behavior.js:263
"Redirect URL" => array( null, __("Redirect URL", "forminator" ), ), // src/form/components/modals/behavior.js:267
"Provide the absolute URL of the page you want to redirect users to after submitting the login form. For example, to redirect users to the WordPress admin, use the URL  {{strong}}http://www.website.com/wp-admin/{{/strong}}." => array( null, __("Provide the absolute URL of the page you want to redirect users to after submitting the login form. For example, to redirect users to the WordPress admin, use the URL  {{strong}}http://www.website.com/wp-admin/{{/strong}}.", "forminator" ), ), // src/form/components/modals/behavior.js:270
"Redirection Option" => array( null, __("Redirection Option", "forminator" ), ), // src/form/components/modals/behavior.js:299
"Redirect on the same tab" => array( null, __("Redirect on the same tab", "forminator" ), ), // src/form/components/modals/behavior.js:302
"Redirect on new tab and show thank you message on form page" => array( null, __("Redirect on new tab and show thank you message on form page", "forminator" ), ), // src/form/components/modals/behavior.js:303
"Redirect on new tab and hide form on the form page" => array( null, __("Redirect on new tab and hide form on the form page", "forminator" ), ), // src/form/components/modals/behavior.js:304
"Hide the form after submission, and display a success message to the user." => array( null, __("Hide the form after submission, and display a success message to the user.", "forminator" ), ), // src/form/components/modals/behavior.js:322
"Submit Message" => array( null, __("Submit Message", "forminator" ), ), // src/form/components/modals/behavior.js:326
"Cancel" => array( null, __("Cancel", "forminator" ), ), // src/form/components/modals/behavior.js:399
"Add" => array( null, __("Add", "forminator" ), ), // src/form/components/modals/behavior.js:427
"Delete Notification" => array( null, __("Delete Notification", "forminator" ), ), // src/form/components/modals/delete-notification.js:39
"Are you sure you wish to delete this Notification?" => array( null, __("Are you sure you wish to delete this Notification?", "forminator" ), ), // src/form/components/modals/delete-notification.js:47
"PDF file successfully deleted." => array( null, __("PDF file successfully deleted.", "forminator" ), ), // src/form/components/modals/delete-pdf.js:36
"Something went wrong while creating your PDF. Please try again." => array( null, __("Something went wrong while creating your PDF. Please try again.", "forminator" ), ), // src/form/components/modals/delete-pdf.js:53
"Delete PDF File" => array( null, __("Delete PDF File", "forminator" ), ), // src/form/components/modals/delete-pdf.js:95
"Are you sure you wish to delete" => array( null, __("Are you sure you wish to delete", "forminator" ), ), // src/form/components/modals/delete-pdf.js:100
"Delete Field Group" => array( null, __("Delete Field Group", "forminator" ), ), // src/form/components/modals/delete.js:122
"Delete Field" => array( null, __("Delete Field", "forminator" ), ), // src/form/components/modals/delete.js:122
"Are you sure you want to delete this group and all the fields it contains?" => array( null, __("Are you sure you want to delete this group and all the fields it contains?", "forminator" ), ), // src/form/components/modals/delete.js:124
"Deleting this field {%(name)s} will also remove associated values from existing submissions." => array( null, __("Deleting this field {%(name)s} will also remove associated values from existing submissions.", "forminator" ), ), // src/form/components/modals/delete.js:125
"Note that this field is mapped in {{link}}Default Meta Keys{{/link}}. If deleted, you will need to remap meta keys {{link}}here{{/link}}." => array( null, __("Note that this field is mapped in {{link}}Default Meta Keys{{/link}}. If deleted, you will need to remap meta keys {{link}}here{{/link}}.", "forminator" ), ), // src/form/components/modals/delete.js:161
"Please remove the references to this field from the following form fields first." => array( null, __("Please remove the references to this field from the following form fields first.", "forminator" ), ), // src/form/components/modals/delete.js:250
"Form Fields" => array( null, __("Form Fields", "forminator" ), ), // src/form/components/modals/delete.js:262
"Got It" => array( null, __("Got It", "forminator" ), ), // src/form/components/modals/delete.js:276
"Collect payments like a pro" => array( null, __("Collect payments like a pro", "forminator" ), ), // src/form/components/modals/fields.js:178
"You have added both Stripe and PayPal fields to your form. We recommend that you use the visibility conditions, so only one of them is visible at a time. For example:" => array( null, __("You have added both Stripe and PayPal fields to your form. We recommend that you use the visibility conditions, so only one of them is visible at a time. For example:", "forminator" ), ), // src/form/components/modals/fields.js:179
"Add an option to your form using a Radio (or Select) field that allows visitors to choose the payment method." => array( null, __("Add an option to your form using a Radio (or Select) field that allows visitors to choose the payment method.", "forminator" ), ), // src/form/components/modals/fields.js:184
"Apply visibility conditions to both Stripe and PayPal fields so only one is visible based on the visitor's selection in the Radio (or Select) field." => array( null, __("Apply visibility conditions to both Stripe and PayPal fields so only one is visible based on the visitor's selection in the Radio (or Select) field.", "forminator" ), ), // src/form/components/modals/fields.js:188
"PDF file" => array( null, __("PDF file", "forminator" ), ), // src/form/components/modals/fields.js:249
"form" => array( null, __("form", "forminator" ), ), // src/form/components/modals/fields.js:252
"You can have only one Stripe field in your form for Stripe to work accurately. Please delete the existing Stripe field to add a new one." => array( null, __("You can have only one Stripe field in your form for Stripe to work accurately. Please delete the existing Stripe field to add a new one.", "forminator" ), ), // src/form/components/modals/fields.js:298
"You can have only one PayPal field in your form for PayPal to work accurately. Please delete the existing PayPal field to add a new one." => array( null, __("You can have only one PayPal field in your form for PayPal to work accurately. Please delete the existing PayPal field to add a new one.", "forminator" ), ), // src/form/components/modals/fields.js:309
"You can have only one payment field in your form. Please delete the existing payment field to add another one." => array( null, __("You can have only one payment field in your form. Please delete the existing payment field to add another one.", "forminator" ), ), // src/form/components/modals/fields.js:320
"You can have only one captcha field in your form for captcha to work accurately. Please delete the existing captcha field to add a new one." => array( null, __("You can have only one captcha field in your form for captcha to work accurately. Please delete the existing captcha field to add a new one.", "forminator" ), ), // src/form/components/modals/fields.js:330
"{{b}}Note{{/b}}: You can use the {{b}}Rich Text{{/b}} field to add form fields and custom text to your PDF." => array( null, __("{{b}}Note{{/b}}: You can use the {{b}}Rich Text{{/b}} field to add form fields and custom text to your PDF.", "forminator" ), ), // src/form/components/modals/fields.js:341
"Coming soon" => array( null, __("Coming soon", "forminator" ), ), // src/form/components/modals/fields.js:434
"Payment" => array( null, __("Payment", "forminator" ), ), // src/form/components/modals/fields.js:445
"Quotation" => array( null, __("Quotation", "forminator" ), ), // src/form/components/modals/fields.js:461
"Need access to pro form fields? {{link}}Upgrade to Pro{{/link}}" => array( null, __("Need access to pro form fields? {{link}}Upgrade to Pro{{/link}}", "forminator" ), ), // src/form/components/modals/fields.js:490
"Dismiss" => array( null, __("Dismiss", "forminator" ), ), // src/form/components/modals/fields.js:512
"Searching" => array( null, __("Searching", "forminator" ), ), // src/form/components/modals/notification.js:128
"No Result Found" => array( null, __("No Result Found", "forminator" ), ), // src/form/components/modals/notification.js:131
"Recipient(s)" => array( null, __("Recipient(s)", "forminator" ), ), // src/form/components/modals/notification.js:134
"Please enter recipients" => array( null, __("Please enter recipients", "forminator" ), ), // src/form/components/modals/notification.js:224
"Please select rule" => array( null, __("Please select rule", "forminator" ), ), // src/form/components/modals/notification.js:237
"Please add email routing" => array( null, __("Please add email routing", "forminator" ), ), // src/form/components/modals/notification.js:242
"Please fix the error(s) in the EMAIL tab." => array( null, __("Please fix the error(s) in the EMAIL tab.", "forminator" ), ), // src/form/components/modals/notification.js:278
"Add Email Notification" => array( null, __("Add Email Notification", "forminator" ), ), // src/form/components/modals/notification.js:306
"Email" => array( null, __("Email", "forminator" ), ), // src/form/components/modals/notification.js:323
"Recipients" => array( null, __("Recipients", "forminator" ), ), // src/form/components/modals/notification.js:333
"Advanced" => array( null, __("Advanced", "forminator" ), ), // src/form/components/modals/notification.js:343
"The label is to help you identify this email and won't appear anywhere in the email." => array( null, __("The label is to help you identify this email and won't appear anywhere in the email.", "forminator" ), ), // src/form/components/modals/notification.js:381
"E.g. Sales Team Notification" => array( null, __("E.g. Sales Team Notification", "forminator" ), ), // src/form/components/modals/notification.js:386
"E.g. New Form Submission" => array( null, __("E.g. New Form Submission", "forminator" ), ), // src/form/components/modals/notification.js:400
"Subject" => array( null, __("Subject", "forminator" ), ), // src/form/components/modals/notification.js:403
"Email subject can't be empty" => array( null, __("Email subject can't be empty", "forminator" ), ), // src/form/components/modals/notification.js:406
"Body" => array( null, __("Body", "forminator" ), ), // src/form/components/modals/notification.js:437
"Email body can't be empty" => array( null, __("Email body can't be empty", "forminator" ), ), // src/form/components/modals/notification.js:439
"Attachments" => array( null, __("Attachments", "forminator" ), ), // src/form/components/modals/notification.js:451
"Choose whether you want to attach the files uploaded via the File Upload fields to this email." => array( null, __("Choose whether you want to attach the files uploaded via the File Upload fields to this email.", "forminator" ), ), // src/form/components/modals/notification.js:452
"Uploaded files" => array( null, __("Uploaded files", "forminator" ), ), // src/form/components/modals/notification.js:459
"The default behavior is to send the email to the same recipients. If you want to send this email to different recipients conditionally, you can enable the email routing and change the recipients of this email based on the user input." => array( null, __("The default behavior is to send the email to the same recipients. If you want to send this email to different recipients conditionally, you can enable the email routing and change the recipients of this email based on the user input.", "forminator" ), ), // src/form/components/modals/notification.js:487
"E.g. sales@website.com" => array( null, __("E.g. sales@website.com", "forminator" ), ), // src/form/components/modals/notification.js:521
"(Separate multiple emails with a comma)" => array( null, __("(Separate multiple emails with a comma)", "forminator" ), ), // src/form/components/modals/notification.js:528
"Email Routing" => array( null, __("Email Routing", "forminator" ), ), // src/form/components/modals/notification.js:549
"Enter from name here" => array( null, __("Enter from name here", "forminator" ), ), // src/form/components/modals/notification.js:576
"From Name" => array( null, __("From Name", "forminator" ), ), // src/form/components/modals/notification.js:577
"Enter from email here" => array( null, __("Enter from email here", "forminator" ), ), // src/form/components/modals/notification.js:597
"From Email" => array( null, __("From Email", "forminator" ), ), // src/form/components/modals/notification.js:598
"Some hosts do not allow \"from email\" to be overridden or replaced due to spam issues." => array( null, __("Some hosts do not allow \"from email\" to be overridden or replaced due to spam issues.", "forminator" ), ), // src/form/components/modals/notification.js:629
"Enter reply-to email here" => array( null, __("Enter reply-to email here", "forminator" ), ), // src/form/components/modals/notification.js:647
"Reply-to Email" => array( null, __("Reply-to Email", "forminator" ), ), // src/form/components/modals/notification.js:648
"Enter CC email here" => array( null, __("Enter CC email here", "forminator" ), ), // src/form/components/modals/notification.js:669
"CC Emails" => array( null, __("CC Emails", "forminator" ), ), // src/form/components/modals/notification.js:670
"Enter BCC email here" => array( null, __("Enter BCC email here", "forminator" ), ), // src/form/components/modals/notification.js:691
"BCC Emails" => array( null, __("BCC Emails", "forminator" ), ), // src/form/components/modals/notification.js:692
"Discard Changes" => array( null, __("Discard Changes", "forminator" ), ), // src/form/components/modals/notification.js:736
"Footer" => array( null, __("Footer", "forminator" ), ), // src/form/components/modals/page-footer.js:87
"Styling" => array( null, __("Styling", "forminator" ), ), // src/form/components/modals/page-footer.js:103
"Show page number" => array( null, __("Show page number", "forminator" ), ), // src/form/components/modals/page-footer.js:148
"Optional Fields" => array( null, __("Optional Fields", "forminator" ), ), // src/form/components/modals/page-header.js:96
"Misc Data" => array( null, __("Misc Data", "forminator" ), ), // src/form/components/modals/page-header.js:107
"Header" => array( null, __("Header", "forminator" ), ), // src/form/components/modals/page-header.js:131
"Labels" => array( null, __("Labels", "forminator" ), ), // src/form/components/modals/pagination.js:78
"Your form is divided into multiple pages by Page Break field(s), and you can customize the label of each page here. Page names appear on your form header along with the progress indicator." => array( null, __("Your form is divided into multiple pages by Page Break field(s), and you can customize the label of each page here. Page names appear on your form header along with the progress indicator.", "forminator" ), ), // src/form/components/modals/pagination.js:106
"Finish" => array( null, __("Finish", "forminator" ), ), // src/form/components/modals/pagination.js:133
"Choose whether to show a progress indicator on top of your form, so your users know how far they are through your form." => array( null, __("Choose whether to show a progress indicator on top of your form, so your users know how far they are through your form.", "forminator" ), ), // src/form/components/modals/pagination.js:153
"Close this dialog" => array( null, __("Close this dialog", "forminator" ), ), // src/form/components/modals/partials/close.js:13
"Forminator image" => array( null, __("Forminator image", "forminator" ), ), // src/form/components/modals/partials/image.js:13
"No PDF file available for this form yet. Go to the {{link}}PDF tab{{/link}} to create one." => array( null, __("No PDF file available for this form yet. Go to the {{link}}PDF tab{{/link}} to create one.", "forminator" ), ), // src/form/components/modals/partials/pdf-attachment-none.js:36
"The {{strong}}Forminator PDF Generator Add-on{{/strong}} is required to use the PDF generator feature. Install it from the Add-ons page." => array( null, __("The {{strong}}Forminator PDF Generator Add-on{{/strong}} is required to use the PDF generator feature. Install it from the Add-ons page.", "forminator" ), ), // src/form/components/modals/partials/pdf-attachment.js:38
"PDF Attachments" => array( null, __("PDF Attachments", "forminator" ), ), // src/form/components/modals/partials/pdf-attachment.js:85
"Pro" => array( null, __("Pro", "forminator" ), ), // src/form/components/modals/partials/pdf-attachment.js:88
"Select PDF file(s) to attach to this email notification." => array( null, __("Select PDF file(s) to attach to this email notification.", "forminator" ), ), // src/form/components/modals/partials/pdf-attachment.js:93
"Preview" => array( null, __("Preview", "forminator" ), ), // src/form/components/modals/preview.js:68
"Loading preview…" => array( null, __("Loading preview…", "forminator" ), ), // src/form/components/modals/preview.js:91
"Publishing form…" => array( null, __("Publishing form…", "forminator" ), ), // src/form/components/modals/publish.js:29
"Great work! Please hold tight a few moments while we publish your form to the world." => array( null, __("Great work! Please hold tight a few moments while we publish your form to the world.", "forminator" ), ), // src/form/components/modals/publish.js:33
"Please fill required fields" => array( null, __("Please fill required fields", "forminator" ), ), // src/form/components/modals/settings.js:152
"Calculation values are required!" => array( null, __("Calculation values are required!", "forminator" ), ), // src/form/components/modals/settings.js:170
"Option labels are required!" => array( null, __("Option labels are required!", "forminator" ), ), // src/form/components/modals/settings.js:179
"Please add a placeholder or select a default option." => array( null, __("Please add a placeholder or select a default option.", "forminator" ), ), // src/form/components/modals/settings.js:192
"Please select a default option." => array( null, __("Please select a default option.", "forminator" ), ), // src/form/components/modals/settings.js:197
"At least one of Title, Content, or Excerpt must be enabled for post data to be submitted." => array( null, __("At least one of Title, Content, or Excerpt must be enabled for post data to be submitted.", "forminator" ), ), // src/form/components/modals/settings.js:208
"Please, connect your Stripe account first!" => array( null, __("Please, connect your Stripe account first!", "forminator" ), ), // src/form/components/modals/settings.js:216
"You need at least one payment!" => array( null, __("You need at least one payment!", "forminator" ), ), // src/form/components/modals/settings.js:221
"Please select an email address for payment receipt." => array( null, __("Please select an email address for payment receipt.", "forminator" ), ), // src/form/components/modals/settings.js:226
"Empty labels are not allowed for meta values!" => array( null, __("Empty labels are not allowed for meta values!", "forminator" ), ), // src/form/components/modals/settings.js:237
"Please connect your PayPal account first!" => array( null, __("Please connect your PayPal account first!", "forminator" ), ), // src/form/components/modals/settings.js:250
"Please enter PayPal payment amount!" => array( null, __("Please enter PayPal payment amount!", "forminator" ), ), // src/form/components/modals/settings.js:255
"Please select PayPal payment variable field!" => array( null, __("Please select PayPal payment variable field!", "forminator" ), ), // src/form/components/modals/settings.js:260
"Calculation formula is required!" => array( null, __("Calculation formula is required!", "forminator" ), ), // src/form/components/modals/settings.js:270
"Limit Min value should be less than Max value." => array( null, __("Limit Min value should be less than Max value.", "forminator" ), ), // src/form/components/modals/settings.js:278
"Please enter API keys." => array( null, __("Please enter API keys.", "forminator" ), ), // src/form/components/modals/settings.js:301
"Please select a valid end time limit." => array( null, __("Please select a valid end time limit.", "forminator" ), ), // src/form/components/modals/settings.js:393
"Please fix the Default time error." => array( null, __("Please fix the Default time error.", "forminator" ), ), // src/form/components/modals/settings.js:399
"Please fix the Start or End time." => array( null, __("Please fix the Start or End time.", "forminator" ), ), // src/form/components/modals/settings.js:413
"Please fix the limit Start or End date." => array( null, __("Please fix the limit Start or End date.", "forminator" ), ), // src/form/components/modals/settings.js:551
"Geolocation" => array( null, __("Geolocation", "forminator" ), ), // src/form/components/modals/settings.js:661
"Geolocation {{span}}Pro{{/span}}" => array( null, __("Geolocation {{span}}Pro{{/span}}", "forminator" ), ), // src/form/components/modals/settings.js:662
"Repeater" => array( null, __("Repeater", "forminator" ), ), // src/form/components/modals/settings.js:679
"Calculations" => array( null, __("Calculations", "forminator" ), ), // src/form/components/modals/settings.js:699
"Customize" => array( null, __("Customize", "forminator" ), ), // src/form/components/modals/settings.js:729
"Visibility" => array( null, __("Visibility", "forminator" ), ), // src/form/components/modals/settings.js:739
"Shortcode has been copied successfully." => array( null, __("Shortcode has been copied successfully.", "forminator" ), ), // src/form/components/modals/shortcode.js:22
"Ready to go!" => array( null, __("Ready to go!", "forminator" ), ), // src/form/components/modals/shortcode.js:46
"Your form is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your form is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator" ), ), // src/form/components/modals/shortcode.js:50
"Shortcode" => array( null, __("Shortcode", "forminator" ), ), // src/form/components/modals/shortcode.js:74
"Copy shortcode" => array( null, __("Copy shortcode", "forminator" ), ), // src/form/components/modals/shortcode.js:89
"Button text" => array( null, __("Button text", "forminator" ), ), // src/form/components/modals/submit.js:101
"Enter message" => array( null, __("Enter message", "forminator" ), ), // src/form/components/modals/submit.js:114
"New" => array( null, __("New", "forminator" ), ), // src/form/components/navigation/menu.js:25
"You can configure email notifications on the parent quiz as it is shared between this form and the parent quiz." => array( null, __("You can configure email notifications on the parent quiz as it is shared between this form and the parent quiz.", "forminator" ), ), // src/form/components/navigation/menu.js:103
"You can configure integrations on the parent quiz as it is shared between this form and the parent quiz." => array( null, __("You can configure integrations on the parent quiz as it is shared between this form and the parent quiz.", "forminator" ), ), // src/form/components/navigation/menu.js:124
"More settings options are coming soon" => array( null, __("More settings options are coming soon", "forminator" ), ), // src/form/components/navigation/menu.js:139
"Navigate" => array( null, __("Navigate", "forminator" ), ), // src/form/components/navigation/mobile-select.js:33
"You can send customized email notifications to your site admins and visitors on successful form submission. Advanced features like email routing and conditional emails provide granular control over the email notifications." => array( null, __("You can send customized email notifications to your site admins and visitors on successful form submission. Advanced features like email routing and conditional emails provide granular control over the email notifications.", "forminator" ), ), // src/form/components/notifications.js:36
"Admin Email" => array( null, __("Admin Email", "forminator" ), ), // src/form/components/notifications/admin-email.js:299
"By default we’ll send an email to the nominated email account. You customise this email or turn it off all together." => array( null, __("By default we’ll send an email to the nominated email account. You customise this email or turn it off all together.", "forminator" ), ), // src/form/components/notifications/admin-email.js:302
"Send an email to admin users" => array( null, __("Send an email to admin users", "forminator" ), ), // src/form/components/notifications/admin-email.js:313
"From Address" => array( null, __("From Address", "forminator" ), ), // src/form/components/notifications/admin-email.js:339
"Reply To Address" => array( null, __("Reply To Address", "forminator" ), ), // src/form/components/notifications/admin-email.js:361
"CC Addresses" => array( null, __("CC Addresses", "forminator" ), ), // src/form/components/notifications/admin-email.js:375
"BCC Addresses" => array( null, __("BCC Addresses", "forminator" ), ), // src/form/components/notifications/admin-email.js:383
"Enter subject" => array( null, __("Enter subject", "forminator" ), ), // src/form/components/notifications/admin-email.js:391
"this email if" => array( null, __("this email if", "forminator" ), ), // src/form/components/notifications/conditions.js:139
"of the following rules match:" => array( null, __("of the following rules match:", "forminator" ), ), // src/form/components/notifications/conditions.js:155
"By default, this email is always sent on form submission. You can add conditions to send this email conditionally based on user input." => array( null, __("By default, this email is always sent on form submission. You can add conditions to send this email conditionally based on user input.", "forminator" ), ), // src/form/components/notifications/conditions.js:182
"Add Rule" => array( null, __("Add Rule", "forminator" ), ), // src/form/components/notifications/conditions.js:240
"Confirmation Email" => array( null, __("Confirmation Email", "forminator" ), ), // src/form/components/notifications/confirmation-email.js:298
"In addition to notifying people of new submissions, you can also send a confirmation email to the user who submitted the form." => array( null, __("In addition to notifying people of new submissions, you can also send a confirmation email to the user who submitted the form.", "forminator" ), ), // src/form/components/notifications/confirmation-email.js:301
"Send a confirmation email to the user" => array( null, __("Send a confirmation email to the user", "forminator" ), ), // src/form/components/notifications/confirmation-email.js:313
"If you leave it blank, we will automatically find first email field in the form as recipient. If there is no email field and user is logged in we will use their email." => array( null, __("If you leave it blank, we will automatically find first email field in the form as recipient. If there is no email field and user is logged in we will use their email.", "forminator" ), ), // src/form/components/notifications/confirmation-email.js:358
"Send to {{strong}}\"%(label)s\"{{/strong}} if {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}" => array( null, __("Send to {{strong}}\"%(label)s\"{{/strong}} if {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}", "forminator" ), ), // src/form/components/notifications/email-routing-rule.js:171
"Separate multiple emails with a comma" => array( null, __("Separate multiple emails with a comma", "forminator" ), ), // src/form/components/notifications/email-routing-rule.js:213
"Routing Condition" => array( null, __("Routing Condition", "forminator" ), ), // src/form/components/notifications/email-routing-rule.js:237
"Enter value" => array( null, __("Enter value", "forminator" ), ), // src/form/components/notifications/email-routing-rule.js:370
"You haven't defined any email routing rules yet. Click on the \"+ Add Rule\" button to add the recipients along with the routing rules." => array( null, __("You haven't defined any email routing rules yet. Click on the \"+ Add Rule\" button to add the recipients along with the routing rules.", "forminator" ), ), // src/form/components/notifications/email-routing.js:148
"Email routing is enabled" => array( null, __("Email routing is enabled", "forminator" ), ), // src/form/components/notifications/notification.js:161
"more recipient(s)" => array( null, __("more recipient(s)", "forminator" ), ), // src/form/components/notifications/notification.js:169
"Open field settings" => array( null, __("Open field settings", "forminator" ), ), // src/form/components/notifications/notification.js:213
"Edit" => array( null, __("Edit", "forminator" ), ), // src/form/components/notifications/notification.js:220
"Create New PDF" => array( null, __("Create New PDF", "forminator" ), ), // src/form/components/pdf/create-pdf.js:120
"Install The PDF Generator Add-on to easily generate and send PDF files (e.g., form entries, receipts, invoices, quotations) to users after form submission. A WPMU DEV Pro membership is required to install this add-on." => array( null, __("Install The PDF Generator Add-on to easily generate and send PDF files (e.g., form entries, receipts, invoices, quotations) to users after form submission. A WPMU DEV Pro membership is required to install this add-on.", "forminator" ), ), // src/form/components/pdf/disconnected.js:57
"Get the Add-On" => array( null, __("Get the Add-On", "forminator" ), ), // src/form/components/pdf/disconnected.js:68
"Manage PDF files" => array( null, __("Manage PDF files", "forminator" ), ), // src/form/components/pdf/manage-pdfs.js:32
"Create one or more PDF file templates that will be generated and populated with user data on form submissions. " => array( null, __("Create one or more PDF file templates that will be generated and populated with user data on form submissions. ", "forminator" ), ), // src/form/components/pdf/manage-pdfs.js:34
"Available PDF files" => array( null, __("Available PDF files", "forminator" ), ), // src/form/components/pdf/manage-pdfs.js:44
"{{b}}Forminator PDF Generator Add-on{{/b}} requires the following modules ({{b}}mbstring{{/b}} and {{b}}gd{{/b}}). Please contact your hosting provider to enable the extensions." => array( null, __("{{b}}Forminator PDF Generator Add-on{{/b}} requires the following modules ({{b}}mbstring{{/b}} and {{b}}gd{{/b}}). Please contact your hosting provider to enable the extensions.", "forminator" ), ), // src/form/components/pdf/manage-pdfs.js:65
"You haven't created any PDF files yet. When you do, you'll be able to view them all here." => array( null, __("You haven't created any PDF files yet. When you do, you'll be able to view them all here.", "forminator" ), ), // src/form/components/pdf/no-pdf.js:26
"Preview this PDF" => array( null, __("Preview this PDF", "forminator" ), ), // src/form/components/pdf/pdf-table.js:60
"Edit PDF File" => array( null, __("Edit PDF File", "forminator" ), ), // src/form/components/pdf/pdf-table.js:69
"Choose a template" => array( null, __("Choose a template", "forminator" ), ), // src/form/components/pdf/slides/choose-template.js:64
"Select a template below to get started." => array( null, __("Select a template below to get started.", "forminator" ), ), // src/form/components/pdf/slides/choose-template.js:67
"Coming Soon" => array( null, __("Coming Soon", "forminator" ), ), // src/form/components/pdf/slides/choose-template.js:98
"Back" => array( null, __("Back", "forminator" ), ), // src/form/components/pdf/slides/choose-template.js:120
"Continue" => array( null, __("Continue", "forminator" ), ), // src/form/components/pdf/slides/choose-template.js:128
"PDF File Created!" => array( null, __("PDF File Created!", "forminator" ), ), // src/form/components/pdf/slides/file-created.js:64
"The PDF file has been created. Click “Edit PDF” to customize the created PDF or “Continue” to continue building your form." => array( null, __("The PDF file has been created. Click “Edit PDF” to customize the created PDF or “Continue” to continue building your form.", "forminator" ), ), // src/form/components/pdf/slides/file-created.js:67
"Enter PDF filename" => array( null, __("Enter PDF filename", "forminator" ), ), // src/form/components/pdf/slides/filename.js:76
"Give your file a name so you can identify it later." => array( null, __("Give your file a name so you can identify it later.", "forminator" ), ), // src/form/components/pdf/slides/filename.js:79
"Create" => array( null, __("Create", "forminator" ), ), // src/form/components/pdf/slides/filename.js:102
"Hold tight a few moments while we create your PDF file." => array( null, __("Hold tight a few moments while we create your PDF file.", "forminator" ), ), // src/form/components/pdf/slides/loading.js:87
"Preload PDF Content" => array( null, __("Preload PDF Content", "forminator" ), ), // src/form/components/pdf/slides/preload-content.js:58
"Choose if you want to load form data into your PDF file or start with a blank PDF file." => array( null, __("Choose if you want to load form data into your PDF file or start with a blank PDF file.", "forminator" ), ), // src/form/components/pdf/slides/preload-content.js:61
"You have unsaved changes" => array( null, __("You have unsaved changes", "forminator" ), ), // src/form/components/pdf/slides/unsaved-changes.js:136
"Your form contains unsaved changes. Please save your form before proceeding." => array( null, __("Your form contains unsaved changes. Please save your form before proceeding.", "forminator" ), ), // src/form/components/pdf/slides/unsaved-changes.js:139
"The {{b}}Forminator PDF Generator Add-on{{/b}} is required to use the PDF generator feature. Install it from the Add-ons page." => array( null, __("The {{b}}Forminator PDF Generator Add-on{{/b}} is required to use the PDF generator feature. Install it from the Add-ons page.", "forminator" ), ), // src/form/components/pdf/view-addons.js:21
"User Account Activation" => array( null, __("User Account Activation", "forminator" ), ), // src/form/components/registration/account-activation.js:23
"Choose the activation method and other settings for the user accounts." => array( null, __("Choose the activation method and other settings for the user accounts.", "forminator" ), ), // src/form/components/registration/account-activation.js:26
"Activation Method" => array( null, __("Activation Method", "forminator" ), ), // src/form/components/registration/account-activation.js:36
"By default, the user account is activated upon form submission. However, you can choose between {{strong}}Email Activation{{/strong}}, which requires the user to click on an activation email, or {{strong}}Manual Approval{{/strong}} which requires site admin to approve an account." => array( null, __("By default, the user account is activated upon form submission. However, you can choose between {{strong}}Email Activation{{/strong}}, which requires the user to click on an activation email, or {{strong}}Manual Approval{{/strong}} which requires site admin to approve an account.", "forminator" ), ), // src/form/components/registration/account-activation.js:38
"Email Activation" => array( null, __("Email Activation", "forminator" ), ), // src/form/components/registration/account-activation.js:55
"Confirmation Page" => array( null, __("Confirmation Page", "forminator" ), ), // src/form/components/registration/account-activation.js:61
"Choose the page to redirect users to when they click on the confirmation link." => array( null, __("Choose the page to redirect users to when they click on the confirmation link.", "forminator" ), ), // src/form/components/registration/account-activation.js:64
"page ID: " => array( null, __("page ID: ", "forminator" ), ), // src/form/components/registration/account-activation.js:69
"Manual Approval" => array( null, __("Manual Approval", "forminator" ), ), // src/form/components/registration/account-activation.js:74
"A site admin will have to manually approve each entry from the submissions page to activate the user accounts." => array( null, __("A site admin will have to manually approve each entry from the submissions page to activate the user accounts.", "forminator" ), ), // src/form/components/registration/account-activation.js:89
"Activation Email" => array( null, __("Activation Email", "forminator" ), ), // src/form/components/registration/account-activation.js:107
"By default, WordPress sends an activation email containing user account information after the account activation. However, you can choose not to send this email." => array( null, __("By default, WordPress sends an activation email containing user account information after the account activation. However, you can choose not to send this email.", "forminator" ), ), // src/form/components/registration/account-activation.js:109
"Since the {{strong}}Password{{/strong}} user meta key is mapped to {{strong}}Auto Generate Password{{/strong}}, it's recommended to keep this option to {{strong}}Default{{/strong}} so the auto-generated password can be sent to the users." => array( null, __("Since the {{strong}}Password{{/strong}} user meta key is mapped to {{strong}}Auto Generate Password{{/strong}}, it's recommended to keep this option to {{strong}}Default{{/strong}} so the auto-generated password can be sent to the users.", "forminator" ), ), // src/form/components/registration/account-activation.js:132
"Since the activation requires manual approval from site admin, it's recommended to keep this option to {{strong}}Default{{/strong}} to let users know when their account is activated." => array( null, __("Since the activation requires manual approval from site admin, it's recommended to keep this option to {{strong}}Default{{/strong}} to let users know when their account is activated.", "forminator" ), ), // src/form/components/registration/account-activation.js:162
"These settings will add some extra control on your registration process." => array( null, __("These settings will add some extra control on your registration process.", "forminator" ), ), // src/form/components/registration/additional-settings.js:23
"Automatically log in newly activated users" => array( null, __("Automatically log in newly activated users", "forminator" ), ), // src/form/components/registration/additional-settings.js:34
"This will automatically log in a user upon successful activation of their account." => array( null, __("This will automatically log in a user upon successful activation of their account.", "forminator" ), ), // src/form/components/registration/additional-settings.js:35
"Network's Main Site Role" => array( null, __("Network's Main Site Role", "forminator" ), ), // src/form/components/registration/meta-mapping.js:40
"If you don't want to create a user in the network's main site, set this meta key to {{strong}}Don't create a user in the network's main site{{/strong}}." => array( null, __("If you don't want to create a user in the network's main site, set this meta key to {{strong}}Don't create a user in the network's main site{{/strong}}.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:41
"User Role" => array( null, __("User Role", "forminator" ), ), // src/form/components/registration/meta-mapping.js:57
"User Meta Mapping" => array( null, __("User Meta Mapping", "forminator" ), ), // src/form/components/registration/meta-mapping.js:63
"Assign your form fields to the user meta keys to use the data collected from the visitor to create a user profile." => array( null, __("Assign your form fields to the user meta keys to use the data collected from the visitor to create a user profile.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:64
"Default Meta Keys" => array( null, __("Default Meta Keys", "forminator" ), ), // src/form/components/registration/meta-mapping.js:74
"Assign form fields to the default WordPress user meta keys (used in Profiles) below. You can assign a form field to multiple meta keys. If you assign a non-required form field to a required user meta, that form field will automatically become required in your form." => array( null, __("Assign form fields to the default WordPress user meta keys (used in Profiles) below. You can assign a form field to multiple meta keys. If you assign a non-required form field to a required user meta, that form field will automatically become required in your form.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:79
"Select a field" => array( null, __("Select a field", "forminator" ), ), // src/form/components/registration/meta-mapping.js:97
"Website" => array( null, __("Website", "forminator" ), ), // src/form/components/registration/meta-mapping.js:152
"Auto Generated Password" => array( null, __("Auto Generated Password", "forminator" ), ), // src/form/components/registration/meta-mapping.js:177
"This form includes a {{strong}}Password field{{/strong}}. Since user passwords will be {{strong}}automatically generated{{/strong}}, the {{strong}}Password field{{/strong}} should be deleted." => array( null, __("This form includes a {{strong}}Password field{{/strong}}. Since user passwords will be {{strong}}automatically generated{{/strong}}, the {{strong}}Password field{{/strong}} should be deleted.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:195
"This form is set to {{strong}}automatically generate{{/strong}} user passwords. To allow users to set their own passwords, insert a {{strong}}Password field{{/strong}} into {{link}}this form{{/link}}." => array( null, __("This form is set to {{strong}}automatically generate{{/strong}} user passwords. To allow users to set their own passwords, insert a {{strong}}Password field{{/strong}} into {{link}}this form{{/link}}.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:227
"Choose which user role you want to assign to the visitors signing up. You can either assign a fixed user role to all of them or assign a user role conditionally, based on their response to the form fields." => array( null, __("Choose which user role you want to assign to the visitors signing up. You can either assign a fixed user role to all of them or assign a user role conditionally, based on their response to the form fields.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:264
"Fixed Role to All" => array( null, __("Fixed Role to All", "forminator" ), ), // src/form/components/registration/meta-mapping.js:275
"Assign Role Conditionally" => array( null, __("Assign Role Conditionally", "forminator" ), ), // src/form/components/registration/meta-mapping.js:296
"No custom user meta created yet. Click on \"+ Add Custom User Meta\" to create custom user meta and map form fields to it." => array( null, __("No custom user meta created yet. Click on \"+ Add Custom User Meta\" to create custom user meta and map form fields to it.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:303
"Custom User Meta" => array( null, __("Custom User Meta", "forminator" ), ), // src/form/components/registration/meta-mapping.js:316
"Create custom user meta keys and assign your form fields to them to set additional user meta keys upon successful user registration." => array( null, __("Create custom user meta keys and assign your form fields to them to set additional user meta keys upon successful user registration.", "forminator" ), ), // src/form/components/registration/meta-mapping.js:318
"Add Custom User Meta" => array( null, __("Add Custom User Meta", "forminator" ), ), // src/form/components/registration/meta-mapping.js:332
"Site Registration" => array( null, __("Site Registration", "forminator" ), ), // src/form/components/registration/site-registration.js:23
"Choose whether to allow site registrations on your multisite network and different related settings." => array( null, __("Choose whether to allow site registrations on your multisite network and different related settings.", "forminator" ), ), // src/form/components/registration/site-registration.js:26
"Assign form fields to the default WordPress site meta keys below." => array( null, __("Assign form fields to the default WordPress site meta keys below.", "forminator" ), ), // src/form/components/registration/site-registration.js:51
"Site Name" => array( null, __("Site Name", "forminator" ), ), // src/form/components/registration/site-registration.js:58
"Site address meta key will be automatically set based on this field as {{strong}}false{{/strong}}" => array( null, __("Site address meta key will be automatically set based on this field as {{strong}}false{{/strong}}", "forminator" ), ), // src/form/components/registration/site-registration.js:62
"Site Title" => array( null, __("Site Title", "forminator" ), ), // src/form/components/registration/site-registration.js:79
"Site Role" => array( null, __("Site Role", "forminator" ), ), // src/form/components/registration/site-registration.js:94
"forever" => array( null, __("forever", "forminator" ), ), // src/form/components/settings.js:40
"remove" => array( null, __("remove", "forminator" ), ), // src/form/components/settings.js:51
"retain" => array( null, __("retain", "forminator" ), ), // src/form/components/settings.js:51
"Data Storage" => array( null, __("Data Storage", "forminator" ), ), // src/form/components/settings.js:62
"By default we will store all submissions in your database." => array( null, __("By default we will store all submissions in your database.", "forminator" ), ), // src/form/components/settings.js:64
"Store Submissions in Database" => array( null, __("Store Submissions in Database", "forminator" ), ), // src/form/components/settings.js:72
"Disable this feature to prevent submissions from being stored in your database. Note that any submissions previously stored in the database will be retained and automatically deleted according to the retention schedule configured in the Privacy settings below." => array( null, __("Disable this feature to prevent submissions from being stored in your database. Note that any submissions previously stored in the database will be retained and automatically deleted according to the retention schedule configured in the Privacy settings below.", "forminator" ), ), // src/form/components/settings.js:74
"User’s Geolocation" => array( null, __("User’s Geolocation", "forminator" ), ), // src/form/components/settings.js:86
"Enabling this option will attempt to collect and store users' location information when this form is submitted." => array( null, __("Enabling this option will attempt to collect and store users' location information when this form is submitted.", "forminator" ), ), // src/form/components/settings.js:88
"Enable current user’s Geolocation" => array( null, __("Enable current user’s Geolocation", "forminator" ), ), // src/form/components/settings.js:96
"Enable the checkbox to make it mandatory for users to grant access to the location permission to submit this form." => array( null, __("Enable the checkbox to make it mandatory for users to grant access to the location permission to submit this form.", "forminator" ), ), // src/form/components/settings.js:101
"Require access to users' location" => array( null, __("Require access to users' location", "forminator" ), ), // src/form/components/settings.js:105
"Multiple Option Value" => array( null, __("Multiple Option Value", "forminator" ), ), // src/form/components/settings.js:122
"Choose how you want to handle multiple option values in form submissions and email notifications." => array( null, __("Choose how you want to handle multiple option values in form submissions and email notifications.", "forminator" ), ), // src/form/components/settings.js:125
"Default Stored Value" => array( null, __("Default Stored Value", "forminator" ), ), // src/form/components/settings.js:134
"By default, we store option labels of multiple option fields ({{strong}}e.g., Radio, Checkbox, and Select{{/strong}}) in submissions, and use the same in email notifications. You can choose to use option values instead." => array( null, __("By default, we store option labels of multiple option fields ({{strong}}e.g., Radio, Checkbox, and Select{{/strong}}) in submissions, and use the same in email notifications. You can choose to use option values instead.", "forminator" ), ), // src/form/components/settings.js:137
"Option labels" => array( null, __("Option labels", "forminator" ), ), // src/form/components/settings.js:153
"Option values" => array( null, __("Option values", "forminator" ), ), // src/form/components/settings.js:155
"Privacy" => array( null, __("Privacy", "forminator" ), ), // src/form/components/settings.js:164
"Choose how you want to handle this form's data storage." => array( null, __("Choose how you want to handle this form's data storage.", "forminator" ), ), // src/form/components/settings.js:167
"By default we will use the configuration you have set in your" => array( null, __("By default we will use the configuration you have set in your", "forminator" ), ), // src/form/components/settings.js:172
"global privacy settings." => array( null, __("global privacy settings.", "forminator" ), ), // src/form/components/settings.js:178
"How long do you want to retain this form's submissions for?" => array( null, __("How long do you want to retain this form's submissions for?", "forminator" ), ), // src/form/components/settings.js:189
"Use default" => array( null, __("Use default", "forminator" ), ), // src/form/components/settings.js:199
"Your default setting value is to keep the submissions" => array( null, __("Your default setting value is to keep the submissions", "forminator" ), ), // src/form/components/settings.js:217
"Weeks" => array( null, __("Weeks", "forminator" ), ), // src/form/components/settings.js:255
"Months" => array( null, __("Months", "forminator" ), ), // src/form/components/settings.js:258
"Years" => array( null, __("Years", "forminator" ), ), // src/form/components/settings.js:261
"Leave the field blank to retain submissions forever." => array( null, __("Leave the field blank to retain submissions forever.", "forminator" ), ), // src/form/components/settings.js:267
"Account Erasure Requests" => array( null, __("Account Erasure Requests", "forminator" ), ), // src/form/components/settings.js:277
"When handling an account erasure request that contains an email associated with a submission, what do you want to do?" => array( null, __("When handling an account erasure request that contains an email associated with a submission, what do you want to do?", "forminator" ), ), // src/form/components/settings.js:280
"Your default setting value is to " => array( null, __("Your default setting value is to ", "forminator" ), ), // src/form/components/settings.js:310
" the submission." => array( null, __(" the submission.", "forminator" ), ), // src/form/components/settings.js:313
"Retain Submissions" => array( null, __("Retain Submissions", "forminator" ), ), // src/form/components/settings.js:334
"Remove Submissions" => array( null, __("Remove Submissions", "forminator" ), ), // src/form/components/settings.js:337
"Submission Files" => array( null, __("Submission Files", "forminator" ), ), // src/form/components/settings.js:345
"If your form has file upload field(s), choose whether to delete the file(s) related to a submission when that submission gets deleted." => array( null, __("If your form has file upload field(s), choose whether to delete the file(s) related to a submission when that submission gets deleted.", "forminator" ), ), // src/form/components/settings.js:348
"Keep" => array( null, __("Keep", "forminator" ), ), // src/form/components/settings.js:359
"Unknown setting" => array( null, __("Unknown setting", "forminator" ), ), // src/form/components/settings/advanced.js:109
"When this field is hidden, should its value be null (zero), or should the field be ignored in calculations?" => array( null, __("When this field is hidden, should its value be null (zero), or should the field be ignored in calculations?", "forminator" ), ), // src/form/components/settings/calculations/hidden-behavior.js:19
"Null (zero)" => array( null, __("Null (zero)", "forminator" ), ), // src/form/components/settings/calculations/hidden-behavior.js:22
"Ignore this field" => array( null, __("Ignore this field", "forminator" ), ), // src/form/components/settings/calculations/hidden-behavior.js:23
"Assign a calculation value to each option. These values will not be shown on the form. You can assign only a numeric value." => array( null, __("Assign a calculation value to each option. These values will not be shown on the form. You can assign only a numeric value.", "forminator" ), ), // src/form/components/settings/calculations/options.js:41
"Calculation value" => array( null, __("Calculation value", "forminator" ), ), // src/form/components/settings/calculations/options.js:60
"Calculation value is required!" => array( null, __("Calculation value is required!", "forminator" ), ), // src/form/components/settings/calculations/options.js:68
"Pick custom date(s) to restrict" => array( null, __("Pick custom date(s) to restrict", "forminator" ), ), // src/form/components/settings/date-multiple.js:65
"Pick a date" => array( null, __("Pick a date", "forminator" ), ), // src/form/components/settings/date-multiple.js:74
"Add selected date" => array( null, __("Add selected date", "forminator" ), ), // src/form/components/settings/date-multiple.js:81
"Restricted dates" => array( null, __("Restricted dates", "forminator" ), ), // src/form/components/settings/date-multiple.js:92
"Allowed filetypes" => array( null, __("Allowed filetypes", "forminator" ), ), // src/form/components/settings/filetypes.js:118
"We use WordPress' {{a}}default allowed mime types{{/a}} to determine which file types can be uploaded. If you want to allow or restrict specific file types from being upload, you can do so by choosing the Specific filetypes option below." => array( null, __("We use WordPress' {{a}}default allowed mime types{{/a}} to determine which file types can be uploaded. If you want to allow or restrict specific file types from being upload, you can do so by choosing the Specific filetypes option below.", "forminator" ), ), // src/form/components/settings/filetypes.js:120
"Specific filetypes" => array( null, __("Specific filetypes", "forminator" ), ), // src/form/components/settings/filetypes.js:149
"Images" => array( null, __("Images", "forminator" ), ), // src/form/components/settings/filetypes.js:158
"Documents" => array( null, __("Documents", "forminator" ), ), // src/form/components/settings/filetypes.js:168
"Audio" => array( null, __("Audio", "forminator" ), ), // src/form/components/settings/filetypes.js:178
"Video" => array( null, __("Video", "forminator" ), ), // src/form/components/settings/filetypes.js:188
"Archive" => array( null, __("Archive", "forminator" ), ), // src/form/components/settings/filetypes.js:200
"Spreadsheet" => array( null, __("Spreadsheet", "forminator" ), ), // src/form/components/settings/filetypes.js:220
"Interactive" => array( null, __("Interactive", "forminator" ), ), // src/form/components/settings/filetypes.js:230
"Additional filetypes" => array( null, __("Additional filetypes", "forminator" ), ), // src/form/components/settings/filetypes.js:243
"E.g. .ai, .sketch, .studio" => array( null, __("E.g. .ai, .sketch, .studio", "forminator" ), ), // src/form/components/settings/filetypes.js:244
"Add a comma-separated list of filetypes you want to allow in addition to the ones enabled above." => array( null, __("Add a comma-separated list of filetypes you want to allow in addition to the ones enabled above.", "forminator" ), ), // src/form/components/settings/filetypes.js:246
"Note that if you're having trouble uploading one of the enabled filetypes, that filetype may be restricted by your hosting provider." => array( null, __("Note that if you're having trouble uploading one of the enabled filetypes, that filetype may be restricted by your hosting provider.", "forminator" ), ), // src/form/components/settings/filetypes.js:264
"For security reasons, the following file types are disabled by default: .htm, .html, .shtml, .phtml, .jse, .jar, .xml, .css, .asp, .aspx, .jsp, .sql, .hta, .dll, .bat, .com, .sh, .bash, .py, .pl, .js, .php, .svg, .swf, .dfxp and .exe. The above file types could potentially allow malicious files to be uploaded, which could be used to gain access to your site." => array( null, __("For security reasons, the following file types are disabled by default: .htm, .html, .shtml, .phtml, .jse, .jar, .xml, .css, .asp, .aspx, .jsp, .sql, .hta, .dll, .bat, .com, .sh, .bash, .py, .pl, .js, .php, .svg, .swf, .dfxp and .exe. The above file types could potentially allow malicious files to be uploaded, which could be used to gain access to your site.", "forminator" ), ), // src/form/components/settings/filetypes.js:292
"Font Family" => array( null, __("Font Family", "forminator" ), ), // src/form/components/settings/fonts.js:59
"Roboto" => array( null, __("Roboto", "forminator" ), ), // src/form/components/settings/fonts.js:60
"inherit" => array( null, __("inherit", "forminator" ), ), // src/form/components/settings/fonts.js:76
"Custom user font" => array( null, __("Custom user font", "forminator" ), ), // src/form/components/settings/fonts.js:82
"E.g., Arial, sans-serif" => array( null, __("E.g., Arial, sans-serif", "forminator" ), ), // src/form/components/settings/fonts.js:91
"Custom font family" => array( null, __("Custom font family", "forminator" ), ), // src/form/components/settings/fonts.js:92
"E.g., 16" => array( null, __("E.g., 16", "forminator" ), ), // src/form/components/settings/fonts.js:107
"Font Size" => array( null, __("Font Size", "forminator" ), ), // src/form/components/settings/fonts.js:108
"Font Weight" => array( null, __("Font Weight", "forminator" ), ), // src/form/components/settings/fonts.js:116
"Select font weight" => array( null, __("Select font weight", "forminator" ), ), // src/form/components/settings/fonts.js:117
"Failed to connect to the Google Maps API. Please ensure you have entered a valid API key in the {{link}}Settings page{{/link}}." => array( null, __("Failed to connect to the Google Maps API. Please ensure you have entered a valid API key in the {{link}}Settings page{{/link}}.", "forminator" ), ), // src/form/components/settings/geolocation.js:57
"Autocomplete" => array( null, __("Autocomplete", "forminator" ), ), // src/form/components/settings/geolocation.js:76
"Enable this option to integrate Google Maps' address auto-completion service into your addresses field. This powerful feature will simplify the address entry process for users by providing real-time suggestions as they type." => array( null, __("Enable this option to integrate Google Maps' address auto-completion service into your addresses field. This powerful feature will simplify the address entry process for users by providing real-time suggestions as they type.", "forminator" ), ), // src/form/components/settings/geolocation.js:78
"Display address on Map" => array( null, __("Display address on Map", "forminator" ), ), // src/form/components/settings/geolocation.js:97
"Use this option to display a Google Map next to your address field(s), showing the entered address. Users will be able to see their selected address on the map." => array( null, __("Use this option to display a Google Map next to your address field(s), showing the entered address. Users will be able to see their selected address on the map.", "forminator" ), ), // src/form/components/settings/geolocation.js:99
"Map position" => array( null, __("Map position", "forminator" ), ), // src/form/components/settings/geolocation.js:120
"The map is displayed at the bottom of the address field by default. You can also set it to be displayed above the address field below." => array( null, __("The map is displayed at the bottom of the address field by default. You can also set it to be displayed above the address field below.", "forminator" ), ), // src/form/components/settings/geolocation.js:122
"Above Address field(s)" => array( null, __("Above Address field(s)", "forminator" ), ), // src/form/components/settings/geolocation.js:137
"Below Address field(s)" => array( null, __("Below Address field(s)", "forminator" ), ), // src/form/components/settings/geolocation.js:138
"Map Size" => array( null, __("Map Size", "forminator" ), ), // src/form/components/settings/geolocation.js:164
"Set the size of your map." => array( null, __("Set the size of your map.", "forminator" ), ), // src/form/components/settings/geolocation.js:166
"Responsive" => array( null, __("Responsive", "forminator" ), ), // src/form/components/settings/geolocation.js:179
"Custom Size" => array( null, __("Custom Size", "forminator" ), ), // src/form/components/settings/geolocation.js:183
"Enter Height" => array( null, __("Enter Height", "forminator" ), ), // src/form/components/settings/geolocation.js:197
"Enter Width" => array( null, __("Enter Width", "forminator" ), ), // src/form/components/settings/geolocation.js:210
"Default map location" => array( null, __("Default map location", "forminator" ), ), // src/form/components/settings/geolocation.js:222
"By default we show a 0.0 latitude and longitude on the map, you can use the option below to specify a default geolocation to display on the Map." => array( null, __("By default we show a 0.0 latitude and longitude on the map, you can use the option below to specify a default geolocation to display on the Map.", "forminator" ), ), // src/form/components/settings/geolocation.js:224
"Default location" => array( null, __("Default location", "forminator" ), ), // src/form/components/settings/geolocation.js:237
"Custom location" => array( null, __("Custom location", "forminator" ), ), // src/form/components/settings/geolocation.js:241
"Enter coordinates" => array( null, __("Enter coordinates", "forminator" ), ), // src/form/components/settings/geolocation.js:252
"E.g., 1.234567, 9.876543" => array( null, __("E.g., 1.234567, 9.876543", "forminator" ), ), // src/form/components/settings/geolocation.js:253
"To get coordinates, visit {{link}}https://map.google.com{{/link}} navigate to your preferred location, and right-click on any point and click on the first option with digits." => array( null, __("To get coordinates, visit {{link}}https://map.google.com{{/link}} navigate to your preferred location, and right-click on any point and click on the first option with digits.", "forminator" ), ), // src/form/components/settings/geolocation.js:254
"Start & End date" => array( null, __("Start & End date", "forminator" ), ), // src/form/components/settings/limits.js:69
"Choose a start and end date limit for the calendar to restrict the date selection between a specific date range. Note that we will use the timezone set in your {{a}}WordPress Settings{{/a}}." => array( null, __("Choose a start and end date limit for the calendar to restrict the date selection between a specific date range. Note that we will use the timezone set in your {{a}}WordPress Settings{{/a}}.", "forminator" ), ), // src/form/components/settings/limits.js:73
"Start Date" => array( null, __("Start Date", "forminator" ), ), // src/form/components/settings/limits.js:96
"No limit" => array( null, __("No limit", "forminator" ), ), // src/form/components/settings/limits.js:101
"Specific date" => array( null, __("Specific date", "forminator" ), ), // src/form/components/settings/limits.js:102
"Date fields" => array( null, __("Date fields", "forminator" ), ), // src/form/components/settings/limits.js:105
"Offset (optional)" => array( null, __("Offset (optional)", "forminator" ), ), // src/form/components/settings/limits.js:141
"+" => array( null, __("+", "forminator" ), ), // src/form/components/settings/limits.js:155
"-" => array( null, __("-", "forminator" ), ), // src/form/components/settings/limits.js:156
"days" => array( null, __("days", "forminator" ), ), // src/form/components/settings/limits.js:176
"weeks" => array( null, __("weeks", "forminator" ), ), // src/form/components/settings/limits.js:177
"months" => array( null, __("months", "forminator" ), ), // src/form/components/settings/limits.js:178
"years" => array( null, __("years", "forminator" ), ), // src/form/components/settings/limits.js:179
"End Date" => array( null, __("End Date", "forminator" ), ), // src/form/components/settings/limits.js:197
"Days of the week" => array( null, __("Days of the week", "forminator" ), ), // src/form/components/settings/limits.js:295
"Choose which days of the week should be available on the calendar." => array( null, __("Choose which days of the week should be available on the calendar.", "forminator" ), ), // src/form/components/settings/limits.js:299
"All days" => array( null, __("All days", "forminator" ), ), // src/form/components/settings/limits.js:310
"Selected days" => array( null, __("Selected days", "forminator" ), ), // src/form/components/settings/limits.js:316
"Sunday" => array( null, __("Sunday", "forminator" ), ), // src/form/components/settings/limits.js:328
"Wednesday" => array( null, __("Wednesday", "forminator" ), ), // src/form/components/settings/limits.js:336
"Saturday" => array( null, __("Saturday", "forminator" ), ), // src/form/components/settings/limits.js:344
"Monday" => array( null, __("Monday", "forminator" ), ), // src/form/components/settings/limits.js:356
"Thursday" => array( null, __("Thursday", "forminator" ), ), // src/form/components/settings/limits.js:364
"Tuesday" => array( null, __("Tuesday", "forminator" ), ), // src/form/components/settings/limits.js:376
"Friday" => array( null, __("Friday", "forminator" ), ), // src/form/components/settings/limits.js:384
"Disable dates" => array( null, __("Disable dates", "forminator" ), ), // src/form/components/settings/limits.js:402
"Use this setting to disable specific dates on the calendar." => array( null, __("Use this setting to disable specific dates on the calendar.", "forminator" ), ), // src/form/components/settings/limits.js:404
"Disable date ranges" => array( null, __("Disable date ranges", "forminator" ), ), // src/form/components/settings/limits.js:419
"Use this setting to disable specific dates ranges on the calendar." => array( null, __("Use this setting to disable specific dates ranges on the calendar.", "forminator" ), ), // src/form/components/settings/limits.js:421
"Choose an error message to be used when visitor enters a date that is disabled." => array( null, __("Choose an error message to be used when visitor enters a date that is disabled.", "forminator" ), ), // src/form/components/settings/limits.js:438
"Select a Field" => array( null, __("Select a Field", "forminator" ), ), // src/form/components/settings/metadata-option.js:80
"Delete MetaData" => array( null, __("Delete MetaData", "forminator" ), ), // src/form/components/settings/metadata-option.js:99
"Add Custom Meta" => array( null, __("Add Custom Meta", "forminator" ), ), // src/form/components/settings/metadata-value.js:131
"No custom meta data created yet. Click on \"+ Add Custom to create custom meta and map form fields to it." => array( null, __("No custom meta data created yet. Click on \"+ Add Custom to create custom meta and map form fields to it.", "forminator" ), ), // src/form/components/settings/metadata-value.js:140
"Delete meta" => array( null, __("Delete meta", "forminator" ), ), // src/form/components/settings/multi-custom-field-option.js:110
"Default value" => array( null, __("Default value", "forminator" ), ), // src/form/components/settings/multi-name.js:54
"Mr." => array( null, __("Mr.", "forminator" ), ), // src/form/components/settings/multi-name.js:58
"Mrs." => array( null, __("Mrs.", "forminator" ), ), // src/form/components/settings/multi-name.js:59
"Ms." => array( null, __("Ms.", "forminator" ), ), // src/form/components/settings/multi-name.js:60
"Mx." => array( null, __("Mx.", "forminator" ), ), // src/form/components/settings/multi-name.js:61
"Miss" => array( null, __("Miss", "forminator" ), ), // src/form/components/settings/multi-name.js:62
"Dr." => array( null, __("Dr.", "forminator" ), ), // src/form/components/settings/multi-name.js:63
"Prof." => array( null, __("Prof.", "forminator" ), ), // src/form/components/settings/multi-name.js:64
"Delete option" => array( null, __("Delete option", "forminator" ), ), // src/form/components/settings/multi-option.js:212
"Toggle" => array( null, __("Toggle", "forminator" ), ), // src/form/components/settings/multi-option.js:216
"Submission limit" => array( null, __("Submission limit", "forminator" ), ), // src/form/components/settings/multi-option.js:242
"The File APIs are not fully supported in this browser. You may copy and paste your options on the text area above or switch to a modern browser to use the importer." => array( null, __("The File APIs are not fully supported in this browser. You may copy and paste your options on the text area above or switch to a modern browser to use the importer.", "forminator" ), ), // src/form/components/settings/multi-value.js:154
"Whoops, only .csv filetype is allowed." => array( null, __("Whoops, only .csv filetype is allowed.", "forminator" ), ), // src/form/components/settings/multi-value.js:187
"Importing this will replace your current options. Click import to continue." => array( null, __("Importing this will replace your current options. Click import to continue.", "forminator" ), ), // src/form/components/settings/multi-value.js:196
"This browser doesn't seem to support the `files` property of file inputs." => array( null, __("This browser doesn't seem to support the `files` property of file inputs.", "forminator" ), ), // src/form/components/settings/multi-value.js:225
"Option " => array( null, __("Option ", "forminator" ), ), // src/form/components/settings/multi-value.js:509
"Expand All" => array( null, __("Expand All", "forminator" ), ), // src/form/components/settings/multi-value.js:611
"Collapse All" => array( null, __("Collapse All", "forminator" ), ), // src/form/components/settings/multi-value.js:612
"Radio" => array( null, __("Radio", "forminator" ), ), // src/form/components/settings/multi-value.js:633
"Label; value; selection (0 or 1); image-url" => array( null, __("Label; value; selection (0 or 1); image-url", "forminator" ), ), // src/form/components/settings/multi-value.js:640
"Label; value; selection (0 or 1); submission limit" => array( null, __("Label; value; selection (0 or 1); submission limit", "forminator" ), ), // src/form/components/settings/multi-value.js:643
"Label; value; selection (0 or 1)" => array( null, __("Label; value; selection (0 or 1)", "forminator" ), ), // src/form/components/settings/multi-value.js:645
"Warning! You've added more than 1000 options. Switching back to the standard (non-bulk) editor could make your browser slow or unresponsive. Proceed with caution." => array( null, __("Warning! You've added more than 1000 options. Switching back to the standard (non-bulk) editor could make your browser slow or unresponsive. Proceed with caution.", "forminator" ), ), // src/form/components/settings/multi-value.js:672
"Options" => array( null, __("Options", "forminator" ), ), // src/form/components/settings/multi-value.js:690
"Enable Images" => array( null, __("Enable Images", "forminator" ), ), // src/form/components/settings/multi-value.js:707
"Bulk Edit" => array( null, __("Bulk Edit", "forminator" ), ), // src/form/components/settings/multi-value.js:717
"Loading" => array( null, __("Loading", "forminator" ), ), // src/form/components/settings/multi-value.js:728
"Add Option" => array( null, __("Add Option", "forminator" ), ), // src/form/components/settings/multi-value.js:755
"Enter field options (one per line)" => array( null, __("Enter field options (one per line)", "forminator" ), ), // src/form/components/settings/multi-value.js:772
"Type or paste options above (one per line and separated by semicolons) or click 
 {{b}}\"+ Predefined options\"{{/b}} link to select an option. Example: {{b}}false{{/b}}" => array( null, __("Type or paste options above (one per line and separated by semicolons) or click 
 {{b}}\"+ Predefined options\"{{/b}} link to select an option. Example: {{b}}false{{/b}}", "forminator" ), ), // src/form/components/settings/multi-value.js:774
"Import options from CSV" => array( null, __("Import options from CSV", "forminator" ), ), // src/form/components/settings/multi-value.js:790
"Upload file" => array( null, __("Upload file", "forminator" ), ), // src/form/components/settings/multi-value.js:798
"Import" => array( null, __("Import", "forminator" ), ), // src/form/components/settings/multi-value.js:813
"Choose a CSV (.csv) file to import field options and values." => array( null, __("Choose a CSV (.csv) file to import field options and values.", "forminator" ), ), // src/form/components/settings/multi-value.js:839
"Download csv template" => array( null, __("Download csv template", "forminator" ), ), // src/form/components/settings/multi-value.js:842
"Page" => array( null, __("Page", "forminator" ), ), // src/form/components/settings/pagination-custom-text.js:15
"No Previous button" => array( null, __("No Previous button", "forminator" ), ), // src/form/components/settings/pagination-custom-text.js:34
"Previous" => array( null, __("Previous", "forminator" ), ), // src/form/components/settings/pagination-custom-text.js:42
"Next" => array( null, __("Next", "forminator" ), ), // src/form/components/settings/pagination-custom-text.js:62
"No Next button" => array( null, __("No Next button", "forminator" ), ), // src/form/components/settings/pagination-custom-text.js:104
"{{strong}}Note:{{/strong}} Using WordPress Reserved Terms as query parameters may cause unexpected form behavior. Find the complete list of {{link}}{{icon/}} WordPress Reserved Terms here{{/link}}." => array( null, __("{{strong}}Note:{{/strong}} Using WordPress Reserved Terms as query parameters may cause unexpected form behavior. Find the complete list of {{link}}{{icon/}} WordPress Reserved Terms here{{/link}}.", "forminator" ), ), // src/form/components/settings/prefill.js:15
"Pre-populate" => array( null, __("Pre-populate", "forminator" ), ), // src/form/components/settings/prefill.js:37
"You can pre-populate this field dynamically using the query parameter passed in your form URL. Enter the query parameter key to fetch its value from your form URL below." => array( null, __("You can pre-populate this field dynamically using the query parameter passed in your form URL. Enter the query parameter key to fetch its value from your form URL below.", "forminator" ), ), // src/form/components/settings/prefill.js:39
"Query parameter (optional)" => array( null, __("Query parameter (optional)", "forminator" ), ), // src/form/components/settings/prefill.js:51
"radio button" => array( null, __("radio button", "forminator" ), ), // src/form/components/settings/radio-checkbox-visibility.js:22
"checkbox" => array( null, __("checkbox", "forminator" ), ), // src/form/components/settings/radio-checkbox-visibility.js:23
"visibility" => array( null, __("visibility", "forminator" ), ), // src/form/components/settings/radio-checkbox-visibility.js:34
"When using image options, you can hide or show the " => array( null, __("When using image options, you can hide or show the ", "forminator" ), ), // src/form/components/settings/radio-checkbox-visibility.js:41
"Require" => array( null, __("Require", "forminator" ), ), // src/form/components/settings/required.js:46
"Force users to fill out this field, otherwise it will be optional." => array( null, __("Force users to fill out this field, otherwise it will be optional.", "forminator" ), ), // src/form/components/settings/required.js:48
"Optional" => array( null, __("Optional", "forminator" ), ), // src/form/components/settings/required.js:60
"Required" => array( null, __("Required", "forminator" ), ), // src/form/components/settings/required.js:67
"Password error message" => array( null, __("Password error message", "forminator" ), ), // src/form/components/settings/required.js:86
"Confirm Password error message" => array( null, __("Confirm Password error message", "forminator" ), ), // src/form/components/settings/required.js:125
"Enter confirm password message" => array( null, __("Enter confirm password message", "forminator" ), ), // src/form/components/settings/required.js:131
"Options without a value will be treated as empty options" => array( null, __("Options without a value will be treated as empty options", "forminator" ), ), // src/form/components/settings/required.js:165
"Add classes that will be output on this field's container to aid your theme's default styling." => array( null, __("Add classes that will be output on this field's container to aid your theme's default styling.", "forminator" ), ), // src/form/components/settings/styling.js:20
"E.g. form-field" => array( null, __("E.g. form-field", "forminator" ), ), // src/form/components/settings/styling.js:29
"These will be output as you see them here." => array( null, __("These will be output as you see them here.", "forminator" ), ), // src/form/components/settings/styling.js:37
"{{strong}}\"%(label)s\"{{/strong}} when {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}" => array( null, __("{{strong}}\"%(label)s\"{{/strong}} when {{strong}}%(field)s{{/strong}} %(rule)s {{strong}}%(value)s{{/strong}}", "forminator" ), ), // src/form/components/settings/user-role-rule.js:196
"Condition (Required)" => array( null, __("Condition (Required)", "forminator" ), ), // src/form/components/settings/user-role-rule.js:274
"Select date" => array( null, __("Select date", "forminator" ), ), // src/form/components/settings/user-role-rule.js:461
"Number of days" => array( null, __("Number of days", "forminator" ), ), // src/form/components/settings/user-role-rule.js:487
"E.g. 10" => array( null, __("E.g. 10", "forminator" ), ), // src/form/components/settings/user-role-rule.js:488
"Add User Role" => array( null, __("Add User Role", "forminator" ), ), // src/form/components/settings/user-role.js:172
"Validate" => array( null, __("Validate", "forminator" ), ), // src/form/components/settings/validation.js:30
"Make sure the user has filled out this field correctly and warn them when they haven't." => array( null, __("Make sure the user has filled out this field correctly and warn them when they haven't.", "forminator" ), ), // src/form/components/settings/validation.js:32
"Validate Field" => array( null, __("Validate Field", "forminator" ), ), // src/form/components/settings/validation.js:50
"Is before" => array( null, __("Is before", "forminator" ), ), // src/form/components/settings/visibility-rule.js:279
"Is after" => array( null, __("Is after", "forminator" ), ), // src/form/components/settings/visibility-rule.js:282
"Is before n or more days" => array( null, __("Is before n or more days", "forminator" ), ), // src/form/components/settings/visibility-rule.js:285
"Is before less than n days" => array( null, __("Is before less than n days", "forminator" ), ), // src/form/components/settings/visibility-rule.js:288
"Is after n or more days" => array( null, __("Is after n or more days", "forminator" ), ), // src/form/components/settings/visibility-rule.js:291
"Is after less than n days" => array( null, __("Is after less than n days", "forminator" ), ), // src/form/components/settings/visibility-rule.js:294
"this field if" => array( null, __("this field if", "forminator" ), ), // src/form/components/settings/visibility.js:148
"Process this plan if" => array( null, __("Process this plan if", "forminator" ), ), // src/form/components/settings/visibility.js:176
"of the following conditions match:" => array( null, __("of the following conditions match:", "forminator" ), ), // src/form/components/settings/visibility.js:191
"You need more than one field to configure visibility conditions. Add more fields!" => array( null, __("You need more than one field to configure visibility conditions. Add more fields!", "forminator" ), ), // src/form/components/settings/visibility.js:217
"Rules" => array( null, __("Rules", "forminator" ), ), // src/form/components/settings/visibility.js:234
"Add conditions" => array( null, __("Add conditions", "forminator" ), ), // src/form/components/settings/visibility.js:244
"By default field will always be visible. If you want to hide or show fields based on user input you can add conditions." => array( null, __("By default field will always be visible. If you want to hide or show fields based on user input you can add conditions.", "forminator" ), ), // src/form/components/settings/visibility.js:250
"Add conditions for how this plan will be processed based on your form field data." => array( null, __("Add conditions for how this plan will be processed based on your form field data.", "forminator" ), ), // src/form/components/settings/visibility.js:257
"You have unsaved changes, are you sure want to leave this page" => array( null, __("You have unsaved changes, are you sure want to leave this page", "forminator" ), ), // src/form/containers/main.js:71
"Security" => array( null, __("Security", "forminator" ), ), // src/global/components/behaviour/security.js:27
"Added layers of security to prevent spam submissions." => array( null, __("Added layers of security to prevent spam submissions.", "forminator" ), ), // src/global/components/behaviour/security.js:29
"Enable Honeypot protection" => array( null, __("Enable Honeypot protection", "forminator" ), ), // src/global/components/behaviour/security.js:38
"Enabling this feature tricks spam bots by giving them a hidden challenge only bots will see. If the bot tries the challenge we know it's not a human and prevent the form being submitted." => array( null, __("Enabling this feature tricks spam bots by giving them a hidden challenge only bots will see. If the bot tries the challenge we know it's not a human and prevent the form being submitted.", "forminator" ), ), // src/global/components/behaviour/security.js:40
"Enable Akismet spam protection" => array( null, __("Enable Akismet spam protection", "forminator" ), ), // src/global/components/behaviour/security.js:50
"If you have installed the {{link}}Akismet anti-spam plugin{{/link}}, you can enable this option to tell Forminator how to handle submissions that Akismet flags as spam." => array( null, __("If you have installed the {{link}}Akismet anti-spam plugin{{/link}}, you can enable this option to tell Forminator how to handle submissions that Akismet flags as spam.", "forminator" ), ), // src/global/components/behaviour/security.js:53
"How should Forminator handle spam submissions?" => array( null, __("How should Forminator handle spam submissions?", "forminator" ), ), // src/global/components/behaviour/security.js:68
"Fail Submission" => array( null, __("Fail Submission", "forminator" ), ), // src/global/components/behaviour/security.js:73
"Custom error message" => array( null, __("Custom error message", "forminator" ), ), // src/global/components/behaviour/security.js:76
"Something went wrong." => array( null, __("Something went wrong.", "forminator" ), ), // src/global/components/behaviour/security.js:77
"Enter a custom error message to let your visitors know why the submission failed." => array( null, __("Enter a custom error message to let your visitors know why the submission failed.", "forminator" ), ), // src/global/components/behaviour/security.js:79
"Mark as Spam" => array( null, __("Mark as Spam", "forminator" ), ), // src/global/components/behaviour/security.js:86
"Entries marked as spam will be captured in the database, but not shown in Submissions. Additionally, Payments, Notification emails, and other automatic processes will be blocked." => array( null, __("Entries marked as spam will be captured in the database, but not shown in Submissions. Additionally, Payments, Notification emails, and other automatic processes will be blocked.", "forminator" ), ), // src/global/components/behaviour/security.js:101
"Enable logged in submission only" => array( null, __("Enable logged in submission only", "forminator" ), ), // src/global/components/behaviour/security.js:120
"Lock down your form submissions to registered users only." => array( null, __("Lock down your form submissions to registered users only.", "forminator" ), ), // src/global/components/behaviour/security.js:122
"Submissions limit per logged in user" => array( null, __("Submissions limit per logged in user", "forminator" ), ), // src/global/components/behaviour/security.js:129
"Enter the number of times a logged in user can submit this form. Leave blank or enter “0” for no limit." => array( null, __("Enter the number of times a logged in user can submit this form. Leave blank or enter “0” for no limit.", "forminator" ), ), // src/global/components/behaviour/security.js:130
"Message when user has already reached submissions limit" => array( null, __("Message when user has already reached submissions limit", "forminator" ), ), // src/global/components/behaviour/security.js:139
"You’ve already reached submissions limit." => array( null, __("You’ve already reached submissions limit.", "forminator" ), ), // src/global/components/behaviour/security.js:140
"Details" => array( null, __("Details", "forminator" ), ), // src/poll/components/appearance.js:55
"Use default colors" => array( null, __("Use default colors", "forminator" ), ), // src/poll/components/appearance/colors.js:50
"Poll Container" => array( null, __("Poll Container", "forminator" ), ), // src/poll/components/appearance/colors.js:66
"Poll Basics" => array( null, __("Poll Basics", "forminator" ), ), // src/poll/components/appearance/colors.js:73
"Answers - Radio Option" => array( null, __("Answers - Radio Option", "forminator" ), ), // src/poll/components/appearance/colors.js:81
"Radio Options" => array( null, __("Radio Options", "forminator" ), ), // src/poll/components/appearance/colors.js:82
"Answers - Radio Image" => array( null, __("Answers - Radio Image", "forminator" ), ), // src/poll/components/appearance/colors.js:91
"Custom Answer Input" => array( null, __("Custom Answer Input", "forminator" ), ), // src/poll/components/appearance/colors.js:99
"View Results Link" => array( null, __("View Results Link", "forminator" ), ), // src/poll/components/appearance/colors.js:113
"Results Chart" => array( null, __("Results Chart", "forminator" ), ), // src/poll/components/appearance/colors.js:135
"Basics" => array( null, __("Basics", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:25
"Chart grid lines" => array( null, __("Chart grid lines", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:30
"Legend text color" => array( null, __("Legend text color", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:38
"Chart labels color" => array( null, __("Chart labels color", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:39
"Legends are always displayed on top of the chart." => array( null, __("Legends are always displayed on top of the chart.", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:42
"Votes count" => array( null, __("Votes count", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:51
"Text displayed inside bars." => array( null, __("Text displayed inside bars.", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:53
"Tooltips" => array( null, __("Tooltips", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:62
"Answers" => array( null, __("Answers", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:81
"Choose the graph colors for each poll answers below." => array( null, __("Choose the graph colors for each poll answers below.", "forminator" ), ), // src/poll/components/appearance/colors/chart.js:84
"Box shadow" => array( null, __("Box shadow", "forminator" ), ), // src/poll/components/appearance/colors/container.js:31
"Question color" => array( null, __("Question color", "forminator" ), ), // src/poll/components/appearance/colors/content.js:17
"Description color" => array( null, __("Description color", "forminator" ), ), // src/poll/components/appearance/colors/content.js:23
"\"No votes yet\" text color" => array( null, __("\"No votes yet\" text color", "forminator" ), ), // src/poll/components/appearance/colors/content.js:29
"Users see this text next to submit button when \"link on poll\" submission is enabled." => array( null, __("Users see this text next to submit button when \"link on poll\" submission is enabled.", "forminator" ), ), // src/poll/components/appearance/colors/content.js:32
"Link color" => array( null, __("Link color", "forminator" ), ), // src/poll/components/appearance/colors/links.js:28
"Error response message will be displayed after poll vote submission fails." => array( null, __("Error response message will be displayed after poll vote submission fails.", "forminator" ), ), // src/poll/components/appearance/colors/response-error.js:16
"Successful response message will be displayed after poll submission succeeds." => array( null, __("Successful response message will be displayed after poll submission succeeds.", "forminator" ), ), // src/poll/components/appearance/colors/response-success.js:16
"Choose how much spacing you want between each poll option." => array( null, __("Choose how much spacing you want between each poll option.", "forminator" ), ), // src/poll/components/appearance/container.js:65
"Enclosed" => array( null, __("Enclosed", "forminator" ), ), // src/poll/components/appearance/container.js:72
"Choose a pre-made style for your poll and further customize it's appearance below." => array( null, __("Choose a pre-made style for your poll and further customize it's appearance below.", "forminator" ), ), // src/poll/components/appearance/design-style.js:27
"Adjust the answers layout and overall poll alignment." => array( null, __("Adjust the answers layout and overall poll alignment.", "forminator" ), ), // src/poll/components/appearance/options-layout.js:18
"Choose whether the poll answers should appear in a list or a grid." => array( null, __("Choose whether the poll answers should appear in a list or a grid.", "forminator" ), ), // src/poll/components/appearance/options-layout.js:49
"List" => array( null, __("List", "forminator" ), ), // src/poll/components/appearance/options-layout.js:61
"Grid" => array( null, __("Grid", "forminator" ), ), // src/poll/components/appearance/options-layout.js:69
"Choose the number of columns to fit in one row. Note that grid layout changes to two columns on smaller screens so this won't affect the smaller screens." => array( null, __("Choose the number of columns to fit in one row. Note that grid layout changes to two columns on smaller screens so this won't affect the smaller screens.", "forminator" ), ), // src/poll/components/appearance/options-layout.js:76
"Columns per row" => array( null, __("Columns per row", "forminator" ), ), // src/poll/components/appearance/options-layout.js:88
"Answer Type" => array( null, __("Answer Type", "forminator" ), ), // src/poll/components/appearance/options-layout.js:132
"Choose how your poll answers should be displayed on the frontend." => array( null, __("Choose how your poll answers should be displayed on the frontend.", "forminator" ), ), // src/poll/components/appearance/options-layout.js:133
"Image and Radio Button" => array( null, __("Image and Radio Button", "forminator" ), ), // src/poll/components/appearance/options-layout.js:139
"Image only" => array( null, __("Image only", "forminator" ), ), // src/poll/components/appearance/options-layout.js:143
"Voting Limit" => array( null, __("Voting Limit", "forminator" ), ), // src/poll/components/behaviour/limits.js:24
"Choose whether you want to limit the number of votes per users and how do you want to impose that limit. " => array( null, __("Choose whether you want to limit the number of votes per users and how do you want to impose that limit. ", "forminator" ), ), // src/poll/components/behaviour/limits.js:28
"Votes per user" => array( null, __("Votes per user", "forminator" ), ), // src/poll/components/behaviour/limits.js:39
"By default, a user can only vote once on a poll. However, you can allow the users to vote multiple times and also specify the time after which a user can vote again." => array( null, __("By default, a user can only vote once on a poll. However, you can allow the users to vote multiple times and also specify the time after which a user can vote again.", "forminator" ), ), // src/poll/components/behaviour/limits.js:47
"Once" => array( null, __("Once", "forminator" ), ), // src/poll/components/behaviour/limits.js:63
"Allow Multiple" => array( null, __("Allow Multiple", "forminator" ), ), // src/poll/components/behaviour/limits.js:69
"minute(s)" => array( null, __("minute(s)", "forminator" ), ), // src/poll/components/behaviour/limits.js:90
"hour(s)" => array( null, __("hour(s)", "forminator" ), ), // src/poll/components/behaviour/limits.js:91
"Choose the method you want to use to limit the number of votes." => array( null, __("Choose the method you want to use to limit the number of votes.", "forminator" ), ), // src/poll/components/behaviour/limits.js:109
"User IP" => array( null, __("User IP", "forminator" ), ), // src/poll/components/behaviour/limits.js:117
"Browser Cookie" => array( null, __("Browser Cookie", "forminator" ), ), // src/poll/components/behaviour/limits.js:118
"Vote Opening" => array( null, __("Vote Opening", "forminator" ), ), // src/poll/components/behaviour/opening.js:23
"Choose when you want to open and close voting" => array( null, __("Choose when you want to open and close voting", "forminator" ), ), // src/poll/components/behaviour/opening.js:27
"Choose the status of voting" => array( null, __("Choose the status of voting", "forminator" ), ), // src/poll/components/behaviour/opening.js:39
"Open" => array( null, __("Open", "forminator" ), ), // src/poll/components/behaviour/opening.js:52
"Pause" => array( null, __("Pause", "forminator" ), ), // src/poll/components/behaviour/opening.js:56
"Close" => array( null, __("Close", "forminator" ), ), // src/poll/components/behaviour/opening.js:60
"Open from" => array( null, __("Open from", "forminator" ), ), // src/poll/components/behaviour/opening.js:67
"Choose when voting will be opened" => array( null, __("Choose when voting will be opened", "forminator" ), ), // src/poll/components/behaviour/opening.js:70
"Now" => array( null, __("Now", "forminator" ), ), // src/poll/components/behaviour/opening.js:83
"Specific Date Time" => array( null, __("Specific Date Time", "forminator" ), ), // src/poll/components/behaviour/opening.js:88
"Open until" => array( null, __("Open until", "forminator" ), ), // src/poll/components/behaviour/opening.js:104
"Choose how long voting will remain open" => array( null, __("Choose how long voting will remain open", "forminator" ), ), // src/poll/components/behaviour/opening.js:107
"Forever" => array( null, __("Forever", "forminator" ), ), // src/poll/components/behaviour/opening.js:120
"Custom messages" => array( null, __("Custom messages", "forminator" ), ), // src/poll/components/behaviour/opening.js:141
"Message when voting is closed" => array( null, __("Message when voting is closed", "forminator" ), ), // src/poll/components/behaviour/opening.js:147
"E.g. Voting is closed" => array( null, __("E.g. Voting is closed", "forminator" ), ), // src/poll/components/behaviour/opening.js:150
"Message when voting is paused" => array( null, __("Message when voting is paused", "forminator" ), ), // src/poll/components/behaviour/opening.js:155
"E.g. Voting is paused, check again later" => array( null, __("E.g. Voting is paused, check again later", "forminator" ), ), // src/poll/components/behaviour/opening.js:158
"Message before voting open from time" => array( null, __("Message before voting open from time", "forminator" ), ), // src/poll/components/behaviour/opening.js:163
"E.g. Voting has not been started yet" => array( null, __("E.g. Voting has not been started yet", "forminator" ), ), // src/poll/components/behaviour/opening.js:166
"Choose how you want your poll to be rendered for users." => array( null, __("Choose how you want your poll to be rendered for users.", "forminator" ), ), // src/poll/components/behaviour/render.js:14
"Load poll using AJAX" => array( null, __("Load poll using AJAX", "forminator" ), ), // src/poll/components/behaviour/render.js:22
"Enabling this feature will load the poll via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your poll." => array( null, __("Enabling this feature will load the poll via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your poll.", "forminator" ), ), // src/poll/components/behaviour/render.js:23
"Prevent page caching on poll pages" => array( null, __("Prevent page caching on poll pages", "forminator" ), ), // src/poll/components/behaviour/render.js:34
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic polls. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this poll on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic polls. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this poll on it from being cached.", "forminator" ), ), // src/poll/components/behaviour/render.js:35
"Pie Chart" => array( null, __("Pie Chart", "forminator" ), ), // src/poll/components/behaviour/results-display.js:34
"Bar Graph" => array( null, __("Bar Graph", "forminator" ), ), // src/poll/components/behaviour/results-display.js:40
"Results Display" => array( null, __("Results Display", "forminator" ), ), // src/poll/components/behaviour/results-display.js:48
"Choose how you want to display poll results to new submissions. You can customise colors in the {{link}}Appearance{{/link}} tab." => array( null, __("Choose how you want to display poll results to new submissions. You can customise colors in the {{link}}Appearance{{/link}} tab.", "forminator" ), ), // src/poll/components/behaviour/results-display.js:49
"Link on poll" => array( null, __("Link on poll", "forminator" ), ), // src/poll/components/behaviour/results-display.js:70
"Show after voted" => array( null, __("Show after voted", "forminator" ), ), // src/poll/components/behaviour/results-display.js:79
"Do not show" => array( null, __("Do not show", "forminator" ), ), // src/poll/components/behaviour/results-display.js:87
"Submission Method" => array( null, __("Submission Method", "forminator" ), ), // src/poll/components/behaviour/submission-method.js:15
"By default, submissions don't require the page to reload. If you are having issues you might want use the traditional method of reloading the page." => array( null, __("By default, submissions don't require the page to reload. If you are having issues you might want use the traditional method of reloading the page.", "forminator" ), ), // src/poll/components/behaviour/submission-method.js:18
"Reload Page" => array( null, __("Reload Page", "forminator" ), ), // src/poll/components/behaviour/submission-method.js:32
"Vote Count" => array( null, __("Vote Count", "forminator" ), ), // src/poll/components/behaviour/vote-count.js:15
"Display the numbers of votes on bar chart results" => array( null, __("Display the numbers of votes on bar chart results", "forminator" ), ), // src/poll/components/behaviour/vote-count.js:16
"Delete answer" => array( null, __("Delete answer", "forminator" ), ), // src/poll/components/builder/answer-row.js:142
"Answer options" => array( null, __("Answer options", "forminator" ), ), // src/poll/components/builder/answer-row.js:150
"Enable custom input" => array( null, __("Enable custom input", "forminator" ), ), // src/poll/components/builder/answer-row.js:157
"Remove custom input" => array( null, __("Remove custom input", "forminator" ), ), // src/poll/components/builder/answer-row.js:164
"Add Answer" => array( null, __("Add Answer", "forminator" ), ), // src/poll/components/builder/answers.js:74
"A poll without answers isn’t going to be very useful… Add your answers above!" => array( null, __("A poll without answers isn’t going to be very useful… Add your answers above!", "forminator" ), ), // src/poll/components/builder/answers.js:80
"Question" => array( null, __("Question", "forminator" ), ), // src/poll/components/builder/details.js:23
"Start by adding the question you will be asking poll visitors to vote on." => array( null, __("Start by adding the question you will be asking poll visitors to vote on.", "forminator" ), ), // src/poll/components/builder/details.js:26
"What is your main question?" => array( null, __("What is your main question?", "forminator" ), ), // src/poll/components/builder/details.js:38
"E.g. Why did the chicken cross the road?" => array( null, __("E.g. Why did the chicken cross the road?", "forminator" ), ), // src/poll/components/builder/details.js:40
"Feature Image (optional)" => array( null, __("Feature Image (optional)", "forminator" ), ), // src/poll/components/builder/details.js:47
"This image will appear under your main question and can be used to create polls based on an image." => array( null, __("This image will appear under your main question and can be used to create polls based on an image.", "forminator" ), ), // src/poll/components/builder/details.js:50
"Enter an optional description" => array( null, __("Enter an optional description", "forminator" ), ), // src/poll/components/builder/details.js:60
"This will appear below the main question and can be used to further explain the main question." => array( null, __("This will appear below the main question and can be used to further explain the main question.", "forminator" ), ), // src/poll/components/builder/details.js:62
"Now add answers to your question that your users will use to vote with. Add as many as you like, just be careful to make sure each one is unique!" => array( null, __("Now add answers to your question that your users will use to vote with. Add as many as you like, just be careful to make sure each one is unique!", "forminator" ), ), // src/poll/components/builder/details.js:82
"Customize the button label used for submitting the users answer." => array( null, __("Customize the button label used for submitting the users answer.", "forminator" ), ), // src/poll/components/builder/details.js:113
"Button Text" => array( null, __("Button Text", "forminator" ), ), // src/poll/components/builder/details.js:124
"E.g. Vote" => array( null, __("E.g. Vote", "forminator" ), ), // src/poll/components/builder/details.js:126
"Edit Poll" => array( null, __("Edit Poll", "forminator" ), ), // src/poll/components/header.js:13
"Name your poll" => array( null, __("Name your poll", "forminator" ), ), // src/poll/components/header/title.js:38
"Give your poll a name" => array( null, __("Give your poll a name", "forminator" ), ), // src/poll/components/header/title.js:43
"You need to save this poll before using integrations." => array( null, __("You need to save this poll before using integrations.", "forminator" ), ), // src/poll/components/integrations.js:122
"Poll answers can not be empty." => array( null, __("Poll answers can not be empty.", "forminator" ), ), // src/poll/components/meta.js:101
"Please enter valid voting limit." => array( null, __("Please enter valid voting limit.", "forminator" ), ), // src/poll/components/meta.js:114
"Delete Answer" => array( null, __("Delete Answer", "forminator" ), ), // src/poll/components/modals/delete.js:44
"Deleting this answer will remove its value from the existing submissions as well." => array( null, __("Deleting this answer will remove its value from the existing submissions as well.", "forminator" ), ), // src/poll/components/modals/delete.js:48
"Publishing poll…" => array( null, __("Publishing poll…", "forminator" ), ), // src/poll/components/modals/publish.js:29
"Your poll is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your poll is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator" ), ), // src/poll/components/modals/shortcode.js:49
"Copy Shortcode" => array( null, __("Copy Shortcode", "forminator" ), ), // src/poll/components/modals/shortcode.js:77
"Notifications" => array( null, __("Notifications", "forminator" ), ), // src/poll/components/navigation/menu.js:47
"Optionally, you can send a notification email to nominated email accounts when poll submissions come in." => array( null, __("Optionally, you can send a notification email to nominated email accounts when poll submissions come in.", "forminator" ), ), // src/poll/components/notifications/admin-email.js:291
"Poll Name" => array( null, __("Poll Name", "forminator" ), ), // src/poll/components/notifications/admin-email.js:401
"Poll Answer" => array( null, __("Poll Answer", "forminator" ), ), // src/poll/components/notifications/admin-email.js:402
"Poll Result" => array( null, __("Poll Result", "forminator" ), ), // src/poll/components/notifications/admin-email.js:403
"By default we'll store all submissions in your database." => array( null, __("By default we'll store all submissions in your database.", "forminator" ), ), // src/poll/components/settings/data-storage.js:16
"Choose how you want to handle this poll's data storage. By default we'll use the configuration you've set in your {{link}}global privacy settings{{/link}}." => array( null, __("Choose how you want to handle this poll's data storage. By default we'll use the configuration you've set in your {{link}}global privacy settings{{/link}}.", "forminator" ), ), // src/poll/components/settings/privacy.js:46
"How long do you want to retain this poll's submissions for?" => array( null, __("How long do you want to retain this poll's submissions for?", "forminator" ), ), // src/poll/components/settings/privacy.js:68
"Your default setting value is to keep the submissions %s." => array( null, __("Your default setting value is to keep the submissions %s.", "forminator" ), ), // src/poll/components/settings/privacy.js:90
"IP Retention" => array( null, __("IP Retention", "forminator" ), ), // src/poll/components/settings/privacy.js:156
"Choose how long to retain IP address before a submission is anonymized. Keep in mind that the IP address is being used in checking multiple votes from same user." => array( null, __("Choose how long to retain IP address before a submission is anonymized. Keep in mind that the IP address is being used in checking multiple votes from same user.", "forminator" ), ), // src/poll/components/settings/privacy.js:160
"Your default setting keep the IPs %s." => array( null, __("Your default setting keep the IPs %s.", "forminator" ), ), // src/poll/components/settings/privacy.js:181
"Leave the field blank to keep IPs forever." => array( null, __("Leave the field blank to keep IPs forever.", "forminator" ), ), // src/poll/components/settings/privacy.js:230
"Disabled" => array( null, __("Disabled", "forminator" ), ), // src/quiz/global/components/appearance/colors/navigation-button.js:84
"Choose a pre-made style for your quiz and further customize it's appearance below." => array( null, __("Choose a pre-made style for your quiz and further customize it's appearance below.", "forminator" ), ), // src/quiz/global/components/appearance/design-style.js:19
"Question text?" => array( null, __("Question text?", "forminator" ), ), // src/quiz/global/components/appearance/design-style/basic.js:14
"Option Unselected" => array( null, __("Option Unselected", "forminator" ), ), // src/quiz/global/components/appearance/design-style/basic.js:20
"Option Selected" => array( null, __("Option Selected", "forminator" ), ), // src/quiz/global/components/appearance/design-style/basic.js:32
"You have opted for no stylesheet to be enqueued. The quiz will inherit styles from your theme's CSS." => array( null, __("You have opted for no stylesheet to be enqueued. The quiz will inherit styles from your theme's CSS.", "forminator" ), ), // src/quiz/global/components/appearance/design-style/none.js:16
"Customize your quiz layout by adjusting the answers layout and overall quiz alignment." => array( null, __("Customize your quiz layout by adjusting the answers layout and overall quiz alignment.", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:19
"Choose whether the quiz answers should appear in a list or a grid." => array( null, __("Choose whether the quiz answers should appear in a list or a grid.", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:51
"Choose the number of columns to fit in one row. Note that grid layout changes to list on smaller screens so this won't affect the smaller screens." => array( null, __("Choose the number of columns to fit in one row. Note that grid layout changes to list on smaller screens so this won't affect the smaller screens.", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:78
"Quiz Alignment" => array( null, __("Quiz Alignment", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:108
"Choose the overall alignment of your quiz. This setting affects everything, including title, description, questions and answers, buttons, and social share message." => array( null, __("Choose the overall alignment of your quiz. This setting affects everything, including title, description, questions and answers, buttons, and social share message.", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:109
"Center" => array( null, __("Center", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:121
"Question Item Ordering" => array( null, __("Question Item Ordering", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:132
"Choose the order of items (Questions, Images, and Descriptions) from {{strong}}Top{{/strong}} to {{strong}}Bottom{{/strong}} in this quiz." => array( null, __("Choose the order of items (Questions, Images, and Descriptions) from {{strong}}Top{{/strong}} to {{strong}}Bottom{{/strong}} in this quiz.", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:138
"Image" => array( null, __("Image", "forminator" ), ), // src/quiz/global/components/appearance/options-layout.js:166
"Quiz Container" => array( null, __("Quiz Container", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:20
"Customize the quiz container as per your liking." => array( null, __("Customize the quiz container as per your liking.", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:21
"By default the quiz will fill the available space where you insert it. You can add some padding here to better suit your theme." => array( null, __("By default the quiz will fill the available space where you insert it. You can add some padding here to better suit your theme.", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:31
"Add an optional border around the quiz." => array( null, __("Add an optional border around the quiz.", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:56
"Choose how much spacing you want between each quiz question." => array( null, __("Choose how much spacing you want between each quiz question.", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:79
"Maximum Width" => array( null, __("Maximum Width", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:105
"Choose the maximum container width for your quiz. Full Width means quiz container will fill the 100% available space where you insert it, and the Custom option lets you define a maximum container width." => array( null, __("Choose the maximum container width for your quiz. Full Width means quiz container will fill the 100% available space where you insert it, and the Custom option lets you define a maximum container width.", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:106
"Full Width" => array( null, __("Full Width", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container.js:115
"Maximum width" => array( null, __("Maximum width", "forminator" ), ), // src/quiz/global/components/appearance/quiz-container/size.js:19
"By default this quiz will always be available for submissions. However you can lock down if need be." => array( null, __("By default this quiz will always be available for submissions. However you can lock down if need be.", "forminator" ), ), // src/quiz/global/components/behaviour/lifespan.js:20
"Whoops! This quiz has expired." => array( null, __("Whoops! This quiz has expired.", "forminator" ), ), // src/quiz/global/components/behaviour/lifespan.js:54
"Add some custom message for users to see when your quiz stops appearing or leave empty to show nothing (just an empty space)." => array( null, __("Add some custom message for users to see when your quiz stops appearing or leave empty to show nothing (just an empty space).", "forminator" ), ), // src/quiz/global/components/behaviour/lifespan.js:56
"Messages" => array( null, __("Messages", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:12
"Choose the copy of the messages for the correct and wrong answers and also for the final score count." => array( null, __("Choose the copy of the messages for the correct and wrong answers and also for the final score count.", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:15
"Correct Answer Message" => array( null, __("Correct Answer Message", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:22
"Use {{strong}}%UserAnswer%{{/strong}} and {{strong}}%CorrectAnswer%{{/strong}} to display the answer chosen by the user and the correct answer for each question respectively." => array( null, __("Use {{strong}}%UserAnswer%{{/strong}} and {{strong}}%CorrectAnswer%{{/strong}} to display the answer chosen by the user and the correct answer for each question respectively.", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:24
"Incorrect Answer Message" => array( null, __("Incorrect Answer Message", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:40
"Final Count Message" => array( null, __("Final Count Message", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:57
"Final count message will appear after the quiz is complete. Use {{strong}}%YourNum%{{/strong}} to display number of correct answers and {{strong}}%Total%{{/strong}} for total number of questions." => array( null, __("Final count message will appear after the quiz is complete. Use {{strong}}%YourNum%{{/strong}} to display number of correct answers and {{strong}}%Total%{{/strong}} for total number of questions.", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:59
"Quiz Name" => array( null, __("Quiz Name", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:73
"Quiz Answer" => array( null, __("Quiz Answer", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:74
"Quiz Result" => array( null, __("Quiz Result", "forminator" ), ), // src/quiz/global/components/behaviour/messages.js:75
"Questions" => array( null, __("Questions", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:15
"Choose how questions will be presented in the quiz." => array( null, __("Choose how questions will be presented in the quiz.", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:17
"Question Presentation" => array( null, __("Question Presentation", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:29
"Use this option to set how questions in this quiz will be presented. Paginated questions will display a number of questions to users at a time." => array( null, __("Use this option to set how questions in this quiz will be presented. Paginated questions will display a number of questions to users at a time.", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:30
"No Pagination" => array( null, __("No Pagination", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:39
"Paginated Quiz" => array( null, __("Paginated Quiz", "forminator" ), ), // src/quiz/global/components/behaviour/questions.js:45
"Number of questions per page" => array( null, __("Number of questions per page", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:22
"Enter the number of questions to be displayed per page." => array( null, __("Enter the number of questions to be displayed per page.", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:25
"Start quiz button text" => array( null, __("Start quiz button text", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:37
"Enter your start quiz button text. This button will not be shown If the lead generation is enabled and set to show before the quiz." => array( null, __("Enter your start quiz button text. This button will not be shown If the lead generation is enabled and set to show before the quiz.", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:39
"Start Quiz" => array( null, __("Start Quiz", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:45
"Previous button text" => array( null, __("Previous button text", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:57
"Next button text" => array( null, __("Next button text", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:66
"By default, quiz navigation button texts are set to “Next”, and “Previous”, you can use the fields above to set a custom texts for these buttons." => array( null, __("By default, quiz navigation button texts are set to “Next”, and “Previous”, you can use the fields above to set a custom texts for these buttons.", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:72
"Show page indicator" => array( null, __("Show page indicator", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:84
"Display current, and total page indicator" => array( null, __("Display current, and total page indicator", "forminator" ), ), // src/quiz/global/components/behaviour/questions/pagination-settings.js:93
"Choose how you want your quiz to be rendered for users." => array( null, __("Choose how you want your quiz to be rendered for users.", "forminator" ), ), // src/quiz/global/components/behaviour/render.js:14
"Load quiz using AJAX" => array( null, __("Load quiz using AJAX", "forminator" ), ), // src/quiz/global/components/behaviour/render.js:22
"Enabling this feature will load the quiz via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your quiz." => array( null, __("Enabling this feature will load the quiz via AJAX after the page has loaded up, effectively speeding up your page load time. This method can also (in most cases) avoid page caching issues with your quiz.", "forminator" ), ), // src/quiz/global/components/behaviour/render.js:23
"Prevent page caching on quiz pages" => array( null, __("Prevent page caching on quiz pages", "forminator" ), ), // src/quiz/global/components/behaviour/render.js:34
"Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic quizzes. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this quiz on it from being cached." => array( null, __("Page caching plugins serve a static HTML version of the page which can cause issues to your dynamic quizzes. By enabling this, we'll use {{strong}}DONOTCACHEPAGE{{/strong}} constant to prevent pages with this quiz on it from being cached.", "forminator" ), ), // src/quiz/global/components/behaviour/render.js:35
"Results" => array( null, __("Results", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:19
"Choose how do you want to show quiz results to the participants." => array( null, __("Choose how do you want to show quiz results to the participants.", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:21
"Display Method" => array( null, __("Display Method", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:33
"Choose whether to display the correct answer as the user answers each question or after the quiz is submitted." => array( null, __("Choose whether to display the correct answer as the user answers each question or after the quiz is submitted.", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:34
"Real Time" => array( null, __("Real Time", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:44
"On Submission" => array( null, __("On Submission", "forminator" ), ), // src/quiz/global/components/behaviour/results.js:49
"Note: Participants can only choose one answer with \"Real Time\" method." => array( null, __("Note: Participants can only choose one answer with \"Real Time\" method.", "forminator" ), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:24
"Evaluation Loader" => array( null, __("Evaluation Loader", "forminator" ), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:35
"Choose whether you want to show a loader while evaluating the selected answer in real-time. We recommend using this on long quizzes since evaluating an answer might take a bit longer." => array( null, __("Choose whether you want to show a loader while evaluating the selected answer in real-time. We recommend using this on long quizzes since evaluating an answer might take a bit longer.", "forminator" ), ), // src/quiz/global/components/behaviour/results/evaluation-loader.js:38
"Note: You can change the color of the loader in the Appearance tab." => array( null, __("Note: You can change the color of the loader in the Appearance tab.", "forminator" ), ), // src/quiz/global/components/behaviour/results/show-loader.js:14
"Social Sharing" => array( null, __("Social Sharing", "forminator" ), ), // src/quiz/global/components/behaviour/share.js:14
"Choose whether you want to allow the quiz participants to share their results on social media." => array( null, __("Choose whether you want to allow the quiz participants to share their results on social media.", "forminator" ), ), // src/quiz/global/components/behaviour/share.js:15
"Social Sharing Platforms" => array( null, __("Social Sharing Platforms", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:21
"Facebook" => array( null, __("Facebook", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:27
"Facebook no longer supports passing the Social Share Message that you enter below. Your users will need to enter their own messages in the share box." => array( null, __("Facebook no longer supports passing the Social Share Message that you enter below. Your users will need to enter their own messages in the share box.", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:30
"Twitter" => array( null, __("Twitter", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:36
"LinkedIn" => array( null, __("LinkedIn", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:44
"I got {quiz_result} on {quiz_name} quiz!" => array( null, __("I got {quiz_result} on {quiz_name} quiz!", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:55
"Social Share Message" => array( null, __("Social Share Message", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:56
"Page/Post Title" => array( null, __("Page/Post Title", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:68
"Page/Post URL" => array( null, __("Page/Post URL", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:71
"Site URL" => array( null, __("Site URL", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:74
"Want to enhance how the result will look when shared on Social Media? {{link}}SmartCrawl{{/link}} OpenGraph and Twitter Card support lets you choose how your content looks when it's shared on social media." => array( null, __("Want to enhance how the result will look when shared on Social Media? {{link}}SmartCrawl{{/link}} OpenGraph and Twitter Card support lets you choose how your content looks when it's shared on social media.", "forminator" ), ), // src/quiz/global/components/behaviour/social-sharing/social-enable.js:87
"Correct Answer" => array( null, __("Correct Answer", "forminator" ), ), // src/quiz/global/components/builder/answer.js:105
"Select Personality" => array( null, __("Select Personality", "forminator" ), ), // src/quiz/global/components/builder/answer.js:116
"Add Question" => array( null, __("Add Question", "forminator" ), ), // src/quiz/global/components/builder/questions.js:102
"A quiz without questions is not going to be very useful… Add your questions above!" => array( null, __("A quiz without questions is not going to be very useful… Add your questions above!", "forminator" ), ), // src/quiz/global/components/builder/questions.js:108
"Edit Quiz" => array( null, __("Edit Quiz", "forminator" ), ), // src/quiz/global/components/header.js:13
"Give your quiz a name" => array( null, __("Give your quiz a name", "forminator" ), ), // src/quiz/global/components/header/title.js:43
"You need to save this quiz before using integrations." => array( null, __("You need to save this quiz before using integrations.", "forminator" ), ), // src/quiz/global/components/integrations.js:122
"TRY AGAIN" => array( null, __("TRY AGAIN", "forminator" ), ), // src/quiz/global/components/integrations.js:125
"Intro" => array( null, __("Intro", "forminator" ), ), // src/quiz/global/components/intro.js:33
"Start by adding a title for your quiz to let your visitors know what this quiz is all about." => array( null, __("Start by adding a title for your quiz to let your visitors know what this quiz is all about.", "forminator" ), ), // src/quiz/global/components/intro.js:44
"Which superhero are you?" => array( null, __("Which superhero are you?", "forminator" ), ), // src/quiz/global/components/intro.js:59
"Choose a title to grab the attention of your visitors." => array( null, __("Choose a title to grab the attention of your visitors.", "forminator" ), ), // src/quiz/global/components/intro.js:60
"Feature Image" => array( null, __("Feature Image", "forminator" ), ), // src/quiz/global/components/intro.js:72
"Upload a nice feature image for your quiz." => array( null, __("Upload a nice feature image for your quiz.", "forminator" ), ), // src/quiz/global/components/intro.js:75
"Upload Feature Image" => array( null, __("Upload Feature Image", "forminator" ), ), // src/quiz/global/components/intro.js:88
"Provide your visitors with more information about your quiz." => array( null, __("Provide your visitors with more information about your quiz.", "forminator" ), ), // src/quiz/global/components/intro.js:104
"Personalities" => array( null, __("Personalities", "forminator" ), ), // src/quiz/global/components/intro.js:148
"Leads" => array( null, __("Leads", "forminator" ), ), // src/quiz/global/components/leads.js:32
"Capture Leads" => array( null, __("Capture Leads", "forminator" ), ), // src/quiz/global/components/leads.js:38
"Collect participants' details (e.g. name, email, etc.) by integrating a lead generation form in your quiz." => array( null, __("Collect participants' details (e.g. name, email, etc.) by integrating a lead generation form in your quiz.", "forminator" ), ), // src/quiz/global/components/leads.js:39
"Lead generation form" => array( null, __("Lead generation form", "forminator" ), ), // src/quiz/global/components/leads.js:49
"Customize the default lead generation form using the edit button below. Note that this lead generation form has limited settings only, and the rest of them are either automatically set by this quiz or they are shared between this quiz and the lead generation form (such as Email Notifications, Integrations, etc.)." => array( null, __("Customize the default lead generation form using the edit button below. Note that this lead generation form has limited settings only, and the rest of them are either automatically set by this quiz or they are shared between this quiz and the lead generation form (such as Email Notifications, Integrations, etc.).", "forminator" ), ), // src/quiz/global/components/leads.js:57
"%s - Leads form" => array( null, __("%s - Leads form", "forminator" ), ), // src/quiz/global/components/leads.js:74
"Form Placement" => array( null, __("Form Placement", "forminator" ), ), // src/quiz/global/components/leads.js:109
"Where do you want to embed the lead generation form in your quiz?" => array( null, __("Where do you want to embed the lead generation form in your quiz?", "forminator" ), ), // src/quiz/global/components/leads.js:110
"Beginning of quiz" => array( null, __("Beginning of quiz", "forminator" ), ), // src/quiz/global/components/leads.js:117
"Before showing results" => array( null, __("Before showing results", "forminator" ), ), // src/quiz/global/components/leads.js:121
"Skip Form" => array( null, __("Skip Form", "forminator" ), ), // src/quiz/global/components/leads.js:131
"Enable this option if you want to allow your participants to skip the form." => array( null, __("Enable this option if you want to allow your participants to skip the form.", "forminator" ), ), // src/quiz/global/components/leads.js:132
"Link text" => array( null, __("Link text", "forminator" ), ), // src/quiz/global/components/leads.js:144
"Skip and continue" => array( null, __("Skip and continue", "forminator" ), ), // src/quiz/global/components/leads.js:145
"Delete personality %s" => array( null, __("Delete personality %s", "forminator" ), ), // src/quiz/global/components/modals/delete-personality.js:48
"Are you sure you wish to delete this personality?" => array( null, __("Are you sure you wish to delete this personality?", "forminator" ), ), // src/quiz/global/components/modals/delete-personality.js:69
"Edit Question" => array( null, __("Edit Question", "forminator" ), ), // src/quiz/global/components/modals/delete-personality.js:110
"%s can't be deleted" => array( null, __("%s can't be deleted", "forminator" ), ), // src/quiz/global/components/modals/delete-personality.js:120
"Please remove the reference of this Personality from the questions in your quiz and then delete this." => array( null, __("Please remove the reference of this Personality from the questions in your quiz and then delete this.", "forminator" ), ), // src/quiz/global/components/modals/delete-personality.js:142
"Delete Question" => array( null, __("Delete Question", "forminator" ), ), // src/quiz/global/components/modals/delete.js:28
"Deleting this question will remove its value from the existing submissions as well." => array( null, __("Deleting this question will remove its value from the existing submissions as well.", "forminator" ), ), // src/quiz/global/components/modals/delete.js:41
"Quiz data" => array( null, __("Quiz data", "forminator" ), ), // src/quiz/global/components/modals/notification.js:398
"Lead data" => array( null, __("Lead data", "forminator" ), ), // src/quiz/global/components/modals/notification.js:405
"Misc data" => array( null, __("Misc data", "forminator" ), ), // src/quiz/global/components/modals/notification.js:419
"Quiz Data" => array( null, __("Quiz Data", "forminator" ), ), // src/quiz/global/components/modals/notification.js:446
"Add Personality" => array( null, __("Add Personality", "forminator" ), ), // src/quiz/global/components/modals/personality.js:64
"Edit Personality" => array( null, __("Edit Personality", "forminator" ), ), // src/quiz/global/components/modals/personality.js:65
"E.g. Iron Man" => array( null, __("E.g. Iron Man", "forminator" ), ), // src/quiz/global/components/modals/personality.js:94
"Please validate your fields!" => array( null, __("Please validate your fields!", "forminator" ), ), // src/quiz/global/components/modals/personality.js:162
"Publishing quiz…" => array( null, __("Publishing quiz…", "forminator" ), ), // src/quiz/global/components/modals/publish.js:29
"Great work! Please hold tight a few moments while we publish your quiz to the world." => array( null, __("Great work! Please hold tight a few moments while we publish your quiz to the world.", "forminator" ), ), // src/quiz/global/components/modals/publish.js:33
"Options cannot be empty. You either need to enter answer text or upload an image for the empty options." => array( null, __("Options cannot be empty. You either need to enter answer text or upload an image for the empty options.", "forminator" ), ), // src/quiz/global/components/modals/question.js:89
"You need to select at least one correct answer before you can add this question." => array( null, __("You need to select at least one correct answer before you can add this question.", "forminator" ), ), // src/quiz/global/components/modals/question.js:105
"You need to select an associated personality for every option." => array( null, __("You need to select an associated personality for every option.", "forminator" ), ), // src/quiz/global/components/modals/question.js:122
"Description (Optional)" => array( null, __("Description (Optional)", "forminator" ), ), // src/quiz/global/components/modals/question.js:213
"Users can select one answer with the {{b}}Real Time{{/b}} display method. To allow multiple answers, you can switch to the {{b}}On Submission{{/b}} display method in {{a}}Behaviour → Display Method{{/a}}." => array( null, __("Users can select one answer with the {{b}}Real Time{{/b}} display method. To allow multiple answers, you can switch to the {{b}}On Submission{{/b}} display method in {{a}}Behaviour → Display Method{{/a}}.", "forminator" ), ), // src/quiz/global/components/modals/question.js:225
"Note that user's selection will be considered as correct when any of the correct answers is selected." => array( null, __("Note that user's selection will be considered as correct when any of the correct answers is selected.", "forminator" ), ), // src/quiz/global/components/modals/question.js:251
"Note: For questions with multiple correct answers, user's selection will be considered as correct only when all correct answers are selected." => array( null, __("Note: For questions with multiple correct answers, user's selection will be considered as correct only when all correct answers are selected.", "forminator" ), ), // src/quiz/global/components/modals/question.js:267
"Add answers to your question and choose an associated personality. Multiple answers can be associated with a single personality as well." => array( null, __("Add answers to your question and choose an associated personality. Multiple answers can be associated with a single personality as well.", "forminator" ), ), // src/quiz/global/components/modals/question.js:279
"Please, validate your fields!" => array( null, __("Please, validate your fields!", "forminator" ), ), // src/quiz/global/components/modals/question.js:331
"Your quiz is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!" => array( null, __("Your quiz is now ready to be embedded into a page or template of your choice. Simply copy and paste the shortcode below to display it!", "forminator" ), ), // src/quiz/global/components/modals/shortcode.js:47
"close this dialog window" => array( null, __("close this dialog window", "forminator" ), ), // src/quiz/global/components/modals/submit.js:42
"Button Processing Text" => array( null, __("Button Processing Text", "forminator" ), ), // src/quiz/global/components/modals/submit.js:66
"Sending…" => array( null, __("Sending…", "forminator" ), ), // src/quiz/global/components/modals/submit.js:67
"This text will appear as button text while the quiz is being submitted." => array( null, __("This text will appear as button text while the quiz is being submitted.", "forminator" ), ), // src/quiz/global/components/modals/submit.js:69
"Custom CSS Classes" => array( null, __("Custom CSS Classes", "forminator" ), ), // src/quiz/global/components/modals/submit.js:79
"E.g. form-submit-btn" => array( null, __("E.g. form-submit-btn", "forminator" ), ), // src/quiz/global/components/modals/submit.js:80
"These will be output as you see them here. To add multiple classes, separate them with a space. For example, \"form-submit-btn button\" will add two classes \"form-submit-btn\" and \"button\"." => array( null, __("These will be output as you see them here. To add multiple classes, separate them with a space. For example, \"form-submit-btn button\" will add two classes \"form-submit-btn\" and \"button\".", "forminator" ), ), // src/quiz/global/components/modals/submit.js:82
"You can send customized email notifications to your site admins and participant on successful quiz submission. Use advanced features such as email routing, and conditions to have granular control over them." => array( null, __("You can send customized email notifications to your site admins and participant on successful quiz submission. Use advanced features such as email routing, and conditions to have granular control over them.", "forminator" ), ), // src/quiz/global/components/notifications.js:32
"Optionally, you can send a notification email to nominated email accounts when quiz submissions come in." => array( null, __("Optionally, you can send a notification email to nominated email accounts when quiz submissions come in.", "forminator" ), ), // src/quiz/global/components/notifications/admin-email.js:244
"Add as many emails as you like" => array( null, __("Add as many emails as you like", "forminator" ), ), // src/quiz/global/components/notifications/admin-email.js:297
"Final Score" => array( null, __("Final Score", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:90
"Form Data" => array( null, __("Form Data", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:185
"Personality Result" => array( null, __("Personality Result", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:206
"Is correct" => array( null, __("Is correct", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:233
"Is incorrect" => array( null, __("Is incorrect", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:236
"Is final result" => array( null, __("Is final result", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:244
"Is not final result" => array( null, __("Is not final result", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:247
"greater than" => array( null, __("greater than", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:258
"less than" => array( null, __("less than", "forminator" ), ), // src/quiz/global/components/notifications/conditions-rule.js:261
"e.g., 0.75em" => array( null, __("e.g., 0.75em", "forminator" ), ), // src/quiz/global/components/settings/fonts.js:114
"Choose how you want to handle this quiz's data storage. By default we'll use the configuration you've set in your {{link}}global privacy settings{{/link}}." => array( null, __("Choose how you want to handle this quiz's data storage. By default we'll use the configuration you've set in your {{link}}global privacy settings{{/link}}.", "forminator" ), ), // src/quiz/global/components/settings/privacy.js:34
"How long do you want to retain this quiz's submissions for?" => array( null, __("How long do you want to retain this quiz's submissions for?", "forminator" ), ), // src/quiz/global/components/settings/privacy.js:52
"Evaluation loader icon" => array( null, __("Evaluation loader icon", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/answer-checkbox.js:71
"This picker works only when \"Evaluation Loader\" is set to \"Show Loader\"." => array( null, __("This picker works only when \"Evaluation Loader\" is set to \"Show Loader\".", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/answer-checkbox.js:72
"Wrong" => array( null, __("Wrong", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/answer-checkbox.js:119
"Answer text color" => array( null, __("Answer text color", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/answer-text.js:28
"Answer result message" => array( null, __("Answer result message", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/answer-text.js:34
"Main Container" => array( null, __("Main Container", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/basic.js:20
"Page Indicator color" => array( null, __("Page Indicator color", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/basic.js:51
"Quiz result color" => array( null, __("Quiz result color", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/basic.js:66
"Skip form button" => array( null, __("Skip form button", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/basic.js:94
"Basic" => array( null, __("Basic", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:28
"Answer - Container" => array( null, __("Answer - Container", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:35
"Answer - Checkbox" => array( null, __("Answer - Checkbox", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:42
"Answer - Text" => array( null, __("Answer - Text", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:49
"Start Quiz Button" => array( null, __("Start Quiz Button", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:57
"Quiz Navigation Button" => array( null, __("Quiz Navigation Button", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:66
"Back to Answers Button" => array( null, __("Back to Answers Button", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:75
"Retake Button" => array( null, __("Retake Button", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:90
"Social Share" => array( null, __("Social Share", "forminator" ), ), // src/quiz/knowledge/components/appearance/colors/colors-table.js:97
"By default this quiz will inherit the fonts your theme uses. You can override these fonts with custom ones from {{link}}Bunny Fonts{{/link}}." => array( null, __("By default this quiz will inherit the fonts your theme uses. You can override these fonts with custom ones from {{link}}Bunny Fonts{{/link}}.", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts.js:15
"Quiz Title" => array( null, __("Quiz Title", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:36
"Quiz Description" => array( null, __("Quiz Description", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:43
"Page Indicator" => array( null, __("Page Indicator", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:51
"Question Description" => array( null, __("Question Description", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:66
"Answer" => array( null, __("Answer", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:73
"Quiz Navigation Buttons" => array( null, __("Quiz Navigation Buttons", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:90
"Answer Result Message" => array( null, __("Answer Result Message", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:98
"Social Share Title" => array( null, __("Social Share Title", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:119
"Social Share Icons" => array( null, __("Social Share Icons", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:126
"Skip Form Button" => array( null, __("Skip Form Button", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/fonts-table.js:134
"Icon size" => array( null, __("Icon size", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/social-icons.js:18
"Choose one of the pre-defined sizes we have for social share icons." => array( null, __("Choose one of the pre-defined sizes we have for social share icons.", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/social-icons.js:19
"Regular" => array( null, __("Regular", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/social-icons.js:24
"Medium" => array( null, __("Medium", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/social-icons.js:25
"Large" => array( null, __("Large", "forminator" ), ), // src/quiz/knowledge/components/appearance/fonts/social-icons.js:26
"Question description color" => array( null, __("Question description color", "forminator" ), ), // src/quiz/personality/components/appearance/colors/basic.js:65
"Main" => array( null, __("Main", "forminator" ), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:24
"Container background" => array( null, __("Container background", "forminator" ), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:42
"Content background" => array( null, __("Content background", "forminator" ), ), // src/quiz/personality/components/appearance/colors/quiz-result.js:98
"Retake" => array( null, __("Retake", "forminator" ), ), // src/quiz/personality/components/appearance/fonts/quiz-result.js:38
"Let's add the different personalities. Each of the following personality is a possible outcome of your quiz. In case of a tie, the personality is chosen as per their order below." => array( null, __("Let's add the different personalities. Each of the following personality is a possible outcome of your quiz. In case of a tie, the personality is chosen as per their order below.", "forminator" ), ), // src/quiz/personality/components/personalities.js:33
"Reorder the personalities to set the priority order." => array( null, __("Reorder the personalities to set the priority order.", "forminator" ), ), // src/quiz/personality/components/personalities.js:50
"Define the different personalities possible as the outcome of your quiz here." => array( null, __("Define the different personalities possible as the outcome of your quiz here.", "forminator" ), ), // src/quiz/personality/components/personalities/personalities.js:105
"Loading Preset data..." => array( null, __("Loading Preset data...", "forminator" ), ), // src/settings-page/index.js:116
"Unsaved Changes" => array( null, __("Unsaved Changes", "forminator" ), ), // src/settings-page/index.js:186
"Open form options" => array( null, __("Open form options", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:19
"Open poll options" => array( null, __("Open poll options", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:30
"Open quiz options" => array( null, __("Open quiz options", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:41
"Create New Form" => array( null, __("Create New Form", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:103
"Create New Poll" => array( null, __("Create New Poll", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:106
"Create New Quiz" => array( null, __("Create New Quiz", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:110
"View Submissions" => array( null, __("View Submissions", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:164
"Duplicate isn't supported at the moment for the quizzes with lead capturing enabled." => array( null, __("Duplicate isn't supported at the moment for the quizzes with lead capturing enabled.", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:184
"Reset Tracking Data" => array( null, __("Reset Tracking Data", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:218
"Export isn't supported at the moment for the quizzes with lead capturing enabled." => array( null, __("Export isn't supported at the moment for the quizzes with lead capturing enabled.", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:228
"Export" => array( null, __("Export", "forminator" ), ), // src/settings/containers/layout/meta-dropdown.js:235
"Basic selectors" => array( null, __("Basic selectors", "forminator" ), ), // src/settings/inputs/ace-editor.js:67
"Form" => array( null, __("Form", "forminator" ), ), // src/settings/inputs/ace-editor.js:72
"Field Description" => array( null, __("Field Description", "forminator" ), ), // src/settings/inputs/ace-editor.js:100
"Input" => array( null, __("Input", "forminator" ), ), // src/settings/inputs/ace-editor.js:107
"Textarea" => array( null, __("Textarea", "forminator" ), ), // src/settings/inputs/ace-editor.js:114
"Poll" => array( null, __("Poll", "forminator" ), ), // src/settings/inputs/ace-editor.js:127
"Answer Input" => array( null, __("Answer Input", "forminator" ), ), // src/settings/inputs/ace-editor.js:137
"Answer Label" => array( null, __("Answer Label", "forminator" ), ), // src/settings/inputs/ace-editor.js:142
"Quiz" => array( null, __("Quiz", "forminator" ), ), // src/settings/inputs/ace-editor.js:168
"Answer Container" => array( null, __("Answer Container", "forminator" ), ), // src/settings/inputs/ace-editor.js:188
"Answer Text" => array( null, __("Answer Text", "forminator" ), ), // src/settings/inputs/ace-editor.js:195
"PDF selectors" => array( null, __("PDF selectors", "forminator" ), ), // src/settings/inputs/ace-editor.js:203
"PDF Header" => array( null, __("PDF Header", "forminator" ), ), // src/settings/inputs/ace-editor.js:215
"Logo" => array( null, __("Logo", "forminator" ), ), // src/settings/inputs/ace-editor.js:222
"Field Value" => array( null, __("Field Value", "forminator" ), ), // src/settings/inputs/ace-editor.js:243
"%s does not exist in your form. Please insert a valid field from the merged tags option." => array( null, __("%s does not exist in your form. Please insert a valid field from the merged tags option.", "forminator" ), ), // src/settings/inputs/calculation.js:159
"Infinity calculation result." => array( null, __("Infinity calculation result.", "forminator" ), ), // src/settings/inputs/calculation.js:195
" (all)" => array( null, __(" (all)", "forminator" ), ), // src/settings/inputs/calculation.js:247
"Calculation Formula" => array( null, __("Calculation Formula", "forminator" ), ), // src/settings/inputs/calculation.js:287
"Add Form Fields" => array( null, __("Add Form Fields", "forminator" ), ), // src/settings/inputs/calculation.js:301
"Open list of fields" => array( null, __("Open list of fields", "forminator" ), ), // src/settings/inputs/calculation.js:305
"Sum" => array( null, __("Sum", "forminator" ), ), // src/settings/inputs/calculation.js:319
"Minus" => array( null, __("Minus", "forminator" ), ), // src/settings/inputs/calculation.js:329
"Multiply" => array( null, __("Multiply", "forminator" ), ), // src/settings/inputs/calculation.js:339
"Divide" => array( null, __("Divide", "forminator" ), ), // src/settings/inputs/calculation.js:349
"Exponentiate" => array( null, __("Exponentiate", "forminator" ), ), // src/settings/inputs/calculation.js:359
"Modulus" => array( null, __("Modulus", "forminator" ), ), // src/settings/inputs/calculation.js:369
"Open parenthesis" => array( null, __("Open parenthesis", "forminator" ), ), // src/settings/inputs/calculation.js:379
"Close parenthesis" => array( null, __("Close parenthesis", "forminator" ), ), // src/settings/inputs/calculation.js:389
"Comma" => array( null, __("Comma", "forminator" ), ), // src/settings/inputs/calculation.js:399
"PI constant" => array( null, __("PI constant", "forminator" ), ), // src/settings/inputs/calculation.js:409
"Add Function" => array( null, __("Add Function", "forminator" ), ), // src/settings/inputs/calculation.js:416
"Open function list" => array( null, __("Open function list", "forminator" ), ), // src/settings/inputs/calculation.js:420
"You can preview your form and check if the formula is generating expected results." => array( null, __("You can preview your form and check if the formula is generating expected results.", "forminator" ), ), // src/settings/inputs/calculation.js:450
"Formula Preview" => array( null, __("Formula Preview", "forminator" ), ), // src/settings/inputs/calculation.js:459
"Remove this date range" => array( null, __("Remove this date range", "forminator" ), ), // src/settings/inputs/date-picker.js:118
"10 January 2020" => array( null, __("10 January 2020", "forminator" ), ), // src/settings/inputs/date-time-picker.js:166
"AM/PM" => array( null, __("AM/PM", "forminator" ), ), // src/settings/inputs/date-time-picker.js:210
"This field is required!" => array( null, __("This field is required!", "forminator" ), ), // src/settings/inputs/input.js:39
"Please enter valid number." => array( null, __("Please enter valid number.", "forminator" ), ), // src/settings/inputs/input.js:130
"Click here to add a date range..." => array( null, __("Click here to add a date range...", "forminator" ), ), // src/settings/inputs/sui-tags-date-range.js:24
"Click here to add a date…" => array( null, __("Click here to add a date…", "forminator" ), ), // src/settings/inputs/sui-tags-datepicker.js:24
"+ Predefined options" => array( null, __("+ Predefined options", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:104
"My Label; my-value; 0; https://mysite.com/my-image-url.jpg" => array( null, __("My Label; my-value; 0; https://mysite.com/my-image-url.jpg", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:118
"My Label; my-value; 0" => array( null, __("My Label; my-value; 0", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:119
"New option" => array( null, __("New option", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:137
"New option with image" => array( null, __("New option with image", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:142
"Under 1 year
1-17
18-24
25-34
35-44
45-54
55-64
65 and Above" => array( null, __("Under 1 year
1-17
18-24
25-34
35-44
45-54
55-64
65 and Above", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:147
"Age" => array( null, __("Age", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:153
"Male\\nFemale\\nNon-binary\\nOther" => array( null, __("Male\\nFemale\\nNon-binary\\nOther", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:156
"Gender" => array( null, __("Gender", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:157
"Primary School
High School
Some College
Associate's Degree
Bachelor's Degree
Master's degree
Professional degree
Doctoral degree
Other" => array( null, __("Primary School
High School
Some College
Associate's Degree
Bachelor's Degree
Master's degree
Professional degree
Doctoral degree
Other", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:161
"Educational Attainment" => array( null, __("Educational Attainment", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:167
"Full-time employed
Part-time employed
Self-employed
Contract Worker
Homemaker
Retired
Student
Unemployed" => array( null, __("Full-time employed
Part-time employed
Self-employed
Contract Worker
Homemaker
Retired
Student
Unemployed", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:171
"Employment Status" => array( null, __("Employment Status", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:177
"Architecture and Engineering
Arts, Design, Entertainment, Sports, and Media
Building and Grounds Cleaning and Maintenance
Business and Financial Operations
Community and Social Services
Computer and Mathematical
Construction and Extraction
Educational Instruction and Library
Farming, Fishing, and Forestry
Food Preparation and Serving Related
Healthcare Practitioners and Technical
Healthcare Support
Installation, Maintenance, and Repair
Legal
Life, Physical, and Social Science
Management
Office and Administrative Support
Personal Care and Services
Production/Manufacturing
Protective Service
Sales and Related
Transportation and Material Moving" => array( null, __("Architecture and Engineering
Arts, Design, Entertainment, Sports, and Media
Building and Grounds Cleaning and Maintenance
Business and Financial Operations
Community and Social Services
Computer and Mathematical
Construction and Extraction
Educational Instruction and Library
Farming, Fishing, and Forestry
Food Preparation and Serving Related
Healthcare Practitioners and Technical
Healthcare Support
Installation, Maintenance, and Repair
Legal
Life, Physical, and Social Science
Management
Office and Administrative Support
Personal Care and Services
Production/Manufacturing
Protective Service
Sales and Related
Transportation and Material Moving", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:181
"Occupation" => array( null, __("Occupation", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:198
"Single\\nMarried\\nDivorced\\nSeparated\\nWidowed" => array( null, __("Single\\nMarried\\nDivorced\\nSeparated\\nWidowed", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:202
"Marital Status" => array( null, __("Marital Status", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:204
"Africa\\nAntarctica\\nAsia\\nAustralia\\nEurope\\nNorth America\\nSouth America" => array( null, __("Africa\\nAntarctica\\nAsia\\nAustralia\\nEurope\\nNorth America\\nSouth America", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:208
"Continents" => array( null, __("Continents", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:212
"Afghanistan
Åland Islands
Albania
Algeria
American Samoa
Andorra
Angola
Anguilla
Antarctica
Antigua and Barbuda
Argentina
Armenia
Aruba
Australia
Austria
Azerbaijan
Bahamas
Bahrain
Bangladesh
Barbados
Belarus
Belgium
Belize
Benin
Bermuda
Bhutan
Bolivia
Bonaire, Sint Eustatius and Saba
Bosnia and Herzegovina
Botswana
Bouvet Island
Brazil
British Indian Ocean Territory
Brunei Darussalam
Bulgaria
Burkina Faso
Burundi
Cabo Verde
Cambodia
Cameroon
Canada
Cayman Islands
Central African Republic
Chad
Chile
China
Christmas Island
Cocos Islands
Colombia
Comoros
Congo, Democratic Republic of the
Congo, Republic of the
Cook Islands
Costa Rica
Côte d'Ivoire
Croatia
Cuba
Curaçao
Cyprus
Czech Republic
Denmark
Djibouti
Dominica
Dominican Republic
Ecuador
Egypt
El Salvador
Equatorial Guinea
Eritrea
Estonia
Eswatini
Ethiopia
Falkland Islands
Faroe Islands
Fiji
Finland
France
French Guiana
French Polynesia
French Southern Territories
Gabon
Gambia
Georgia
Germany
Ghana
Gibraltar
Greece
Greenland
Grenada
Guadeloupe
Guam
Guatemala
Guernsey
Guinea
Guinea-Bissau
Guyana
Haiti
Heard and McDonald Islands
Holy See
Honduras
Hong Kong
Hungary
Iceland
India
Indonesia
Iran
Iraq
Ireland
Isle of Man
Israel
Italy
Jamaica
Japan
Jersey
Jordan
Kazakhstan
Kenya
Kiribati
Kuwait
Kyrgyzstan
Lao People's Democratic Republic
Latvia
Lebanon
Lesotho
Liberia
Libya
Liechtenstein
Lithuania
Luxembourg
Macau
Madagascar
Malawi
Malaysia
Maldives
Mali
Malta
Marshall Islands
Martinique
Mauritania
Mauritius
Mayotte
Mexico
Micronesia
Moldova
Monaco
Mongolia
Montenegro
Montserrat
Morocco
Mozambique
Myanmar
Namibia
Nauru
Nepal
Netherlands
New Caledonia
New Zealand
Nicaragua
Niger
Nigeria
Niue
Norfolk Island
North Korea
North Macedonia
Northern Mariana Islands
Norway
Oman
Pakistan
Palau
Palestine, State of
Panama
Papua New Guinea
Paraguay
Peru
Philippines
Pitcairn
Poland
Portugal
Puerto Rico
Qatar
Réunion
Romania
Russia
Rwanda
Saint Barthélemy
Saint Helena, Ascension and Tristan da Cunha
Saint Kitts and Nevis
Saint Lucia
Saint Martin
Saint Pierre and Miquelon
Saint Vincent and the Grenadines
Samoa
San Marino
Sao Tome and Principe
Saudi Arabia
Senegal
Serbia
Seychelles
Sierra Leone
Singapore
Sint Maarten
Slovakia
Slovenia
Solomon Islands
Somalia
South Africa
South Georgia and the South Sandwich Islands
South Korea
South Sudan
Spain
Sri Lanka
Sudan
Suriname
Svalbard and Jan Mayen Islands
Sweden
Switzerland
Syria
Taiwan
Tajikistan
Tanzania
Thailand
Timor-Leste
Togo
Tokelau
Tonga
Trinidad and Tobago
Tunisia
Turkey
Turkmenistan
Turks and Caicos Islands
Tuvalu
Uganda
Ukraine
United Arab Emirates
United Kingdom
United States
Uruguay
US Minor Outlying Islands
Uzbekistan
Vanuatu
Venezuela
Vietnam
Virgin Islands, British
Virgin Islands, U.S.
Wallis and Futuna
Western Sahara
Yemen
Zambia
Zimbabwe" => array( null, __("Afghanistan
Åland Islands
Albania
Algeria
American Samoa
Andorra
Angola
Anguilla
Antarctica
Antigua and Barbuda
Argentina
Armenia
Aruba
Australia
Austria
Azerbaijan
Bahamas
Bahrain
Bangladesh
Barbados
Belarus
Belgium
Belize
Benin
Bermuda
Bhutan
Bolivia
Bonaire, Sint Eustatius and Saba
Bosnia and Herzegovina
Botswana
Bouvet Island
Brazil
British Indian Ocean Territory
Brunei Darussalam
Bulgaria
Burkina Faso
Burundi
Cabo Verde
Cambodia
Cameroon
Canada
Cayman Islands
Central African Republic
Chad
Chile
China
Christmas Island
Cocos Islands
Colombia
Comoros
Congo, Democratic Republic of the
Congo, Republic of the
Cook Islands
Costa Rica
Côte d'Ivoire
Croatia
Cuba
Curaçao
Cyprus
Czech Republic
Denmark
Djibouti
Dominica
Dominican Republic
Ecuador
Egypt
El Salvador
Equatorial Guinea
Eritrea
Estonia
Eswatini
Ethiopia
Falkland Islands
Faroe Islands
Fiji
Finland
France
French Guiana
French Polynesia
French Southern Territories
Gabon
Gambia
Georgia
Germany
Ghana
Gibraltar
Greece
Greenland
Grenada
Guadeloupe
Guam
Guatemala
Guernsey
Guinea
Guinea-Bissau
Guyana
Haiti
Heard and McDonald Islands
Holy See
Honduras
Hong Kong
Hungary
Iceland
India
Indonesia
Iran
Iraq
Ireland
Isle of Man
Israel
Italy
Jamaica
Japan
Jersey
Jordan
Kazakhstan
Kenya
Kiribati
Kuwait
Kyrgyzstan
Lao People's Democratic Republic
Latvia
Lebanon
Lesotho
Liberia
Libya
Liechtenstein
Lithuania
Luxembourg
Macau
Madagascar
Malawi
Malaysia
Maldives
Mali
Malta
Marshall Islands
Martinique
Mauritania
Mauritius
Mayotte
Mexico
Micronesia
Moldova
Monaco
Mongolia
Montenegro
Montserrat
Morocco
Mozambique
Myanmar
Namibia
Nauru
Nepal
Netherlands
New Caledonia
New Zealand
Nicaragua
Niger
Nigeria
Niue
Norfolk Island
North Korea
North Macedonia
Northern Mariana Islands
Norway
Oman
Pakistan
Palau
Palestine, State of
Panama
Papua New Guinea
Paraguay
Peru
Philippines
Pitcairn
Poland
Portugal
Puerto Rico
Qatar
Réunion
Romania
Russia
Rwanda
Saint Barthélemy
Saint Helena, Ascension and Tristan da Cunha
Saint Kitts and Nevis
Saint Lucia
Saint Martin
Saint Pierre and Miquelon
Saint Vincent and the Grenadines
Samoa
San Marino
Sao Tome and Principe
Saudi Arabia
Senegal
Serbia
Seychelles
Sierra Leone
Singapore
Sint Maarten
Slovakia
Slovenia
Solomon Islands
Somalia
South Africa
South Georgia and the South Sandwich Islands
South Korea
South Sudan
Spain
Sri Lanka
Sudan
Suriname
Svalbard and Jan Mayen Islands
Sweden
Switzerland
Syria
Taiwan
Tajikistan
Tanzania
Thailand
Timor-Leste
Togo
Tokelau
Tonga
Trinidad and Tobago
Tunisia
Turkey
Turkmenistan
Turks and Caicos Islands
Tuvalu
Uganda
Ukraine
United Arab Emirates
United Kingdom
United States
Uruguay
US Minor Outlying Islands
Uzbekistan
Vanuatu
Venezuela
Vietnam
Virgin Islands, British
Virgin Islands, U.S.
Wallis and Futuna
Western Sahara
Yemen
Zambia
Zimbabwe", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:216
"Countries" => array( null, __("Countries", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:279
"Alabama\\nAlaska\\nArizona\\nArkansas\\nCalifornia\\nColorado\\nConnecticut\\nDelaware\\nDistrict of Columbia\\nFlorida\\nGeorgia\\nHawaii\\nIdaho\\nIllinois\\nIndiana\\nIowa\\nKansas\\nKentucky\\nLouisiana\\nMaine\\nMaryland\\nMassachusetts\\nMichigan\\nMinnesota\\nMississippi\\nMissouri\\nMontana\\nNebraska\\nNevada\\nNew Hampshire\\nNew Jersey\\nNew Mexico\\nNew York\\nNorth Carolina\\nNorth Dakota\\nOhio\\nOklahoma\\nOregon\\nPennsylvania\\nRhode Island\\nSouth Carolina\\nSouth Dakota\\nTennessee\\nTexas\\nUtah\\nVermont\\nVirginia\\nWashington\\nWest Virginia\\nWisconsin\\nWyoming" => array( null, __("Alabama\\nAlaska\\nArizona\\nArkansas\\nCalifornia\\nColorado\\nConnecticut\\nDelaware\\nDistrict of Columbia\\nFlorida\\nGeorgia\\nHawaii\\nIdaho\\nIllinois\\nIndiana\\nIowa\\nKansas\\nKentucky\\nLouisiana\\nMaine\\nMaryland\\nMassachusetts\\nMichigan\\nMinnesota\\nMississippi\\nMissouri\\nMontana\\nNebraska\\nNevada\\nNew Hampshire\\nNew Jersey\\nNew Mexico\\nNew York\\nNorth Carolina\\nNorth Dakota\\nOhio\\nOklahoma\\nOregon\\nPennsylvania\\nRhode Island\\nSouth Carolina\\nSouth Dakota\\nTennessee\\nTexas\\nUtah\\nVermont\\nVirginia\\nWashington\\nWest Virginia\\nWisconsin\\nWyoming", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:283
"American States" => array( null, __("American States", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:284
"Alberta\\nBritish Columbia\\nManitoba\\nNew Brunswick\\nNewfoundland and Labrador\\nNorthwest Territories\\nNova Scotia\\nNunavut\\nOntario\\nPrince Edward Island\\nQuebec\\nSaskatchewan\\nYukon" => array( null, __("Alberta\\nBritish Columbia\\nManitoba\\nNew Brunswick\\nNewfoundland and Labrador\\nNorthwest Territories\\nNova Scotia\\nNunavut\\nOntario\\nPrince Edward Island\\nQuebec\\nSaskatchewan\\nYukon", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:288
"Canadian Provinces" => array( null, __("Canadian Provinces", "forminator" ), ), // src/settings/inputs/sui-variables-bulk-editor.js:289
"+ Insert form fields" => array( null, __("+ Insert form fields", "forminator" ), ), // src/settings/inputs/sui-variables.js:75
"No available options" => array( null, __("No available options", "forminator" ), ), // src/settings/inputs/sui-variables.js:147
"Select image" => array( null, __("Select image", "forminator" ), ), // src/settings/inputs/uploads.js:36
"Upload image" => array( null, __("Upload image", "forminator" ), ), // src/settings/inputs/uploads.js:149
"Remove uploaded image" => array( null, __("Remove uploaded image", "forminator" ), ), // src/settings/inputs/uploads.js:159
"Remove uploaded file" => array( null, __("Remove uploaded file", "forminator" ), ), // src/settings/inputs/uploads.js:160
"Required Fields" => array( null, __("Required Fields", "forminator" ), ), // src/settings/inputs/wp-editor.js:220
"Payment Data" => array( null, __("Payment Data", "forminator" ), ), // src/settings/inputs/wp-editor.js:271
"Form Name" => array( null, __("Form Name", "forminator" ), ), // src/settings/inputs/wp-editor.js:300
"All Form Fields" => array( null, __("All Form Fields", "forminator" ), ), // src/settings/inputs/wp-editor.js:310
"All Non Empty Fields" => array( null, __("All Non Empty Fields", "forminator" ), ), // src/settings/inputs/wp-editor.js:320
"Add form data" => array( null, __("Add form data", "forminator" ), ), // src/settings/inputs/wp-editor.js:383
"Insert form fields" => array( null, __("Insert form fields", "forminator" ), ), // src/settings/inputs/wp-editor.js:387
"Don't Miss Out On Subscription / Recurring Payment Support" => array( null, __("Don't Miss Out On Subscription / Recurring Payment Support", "forminator" ), ), // src/shared/discount.js:31
"Don't worry, only admin users can see this message" => array( null, __("Don't worry, only admin users can see this message", "forminator" ), ), // src/shared/discount.js:32
"Get 60% OFF Forminator Pro" => array( null, __("Get 60% OFF Forminator Pro", "forminator" ), ), // src/shared/discount.js:37
"Pay only" => array( null, __("Pay only", "forminator" ), ), // src/shared/discount.js:41
"year" => array( null, __("year", "forminator" ), ), // src/shared/discount.js:42
"Start collecting subscription payments in Forminator Pro with the new Stripe Subscription add-on! Upgrade now and get 60% OFF all annual plans." => array( null, __("Start collecting subscription payments in Forminator Pro with the new Stripe Subscription add-on! Upgrade now and get 60% OFF all annual plans.", "forminator" ), ), // src/shared/discount.js:44
"Hosting by the Same People Behind Forminator!" => array( null, __("Hosting by the Same People Behind Forminator!", "forminator" ), ), // src/shared/hosting-banner.js:34
"Only admin users can see this message" => array( null, __("Only admin users can see this message", "forminator" ), ), // src/shared/hosting-banner.js:37
"Claim Your 50% Off Hosting Now!" => array( null, __("Claim Your 50% Off Hosting Now!", "forminator" ), ), // src/shared/hosting-banner.js:38
"Unleash the Full Power of Your Site with WPMU DEV Hosting! Lightning-Fast Speed, Robust Security, 24/7 Expert Support, and Effortless Ease of Use. Take Your Sites to the Next Level Today {{b}}with 50% off the First Month!{{/b}}" => array( null, __("Unleash the Full Power of Your Site with WPMU DEV Hosting! Lightning-Fast Speed, Robust Security, 24/7 Expert Support, and Effortless Ease of Use. Take Your Sites to the Next Level Today {{b}}with 50% off the First Month!{{/b}}", "forminator" ), ), // src/shared/hosting-banner.js:43
"Add-ons" => array( null, __("Add-ons", "forminator" ), ), // src/shared/shared-header.js:34
"Click to connect" => array( null, __("Click to connect", "forminator" ), ), // src/shared/shared-header.js:36
"Forminator isn't connected to a WPMU DEV account. Connect to unlock additional free features." => array( null, __("Forminator isn't connected to a WPMU DEV account. Connect to unlock additional free features.", "forminator" ), ), // src/shared/shared-header.js:37
"Connect Forminator to your WPMU DEV account" => array( null, __("Connect Forminator to your WPMU DEV account", "forminator" ), ), // src/shared/shared-header.js:45
"Connect to WPMU DEV to unlock features for free." => array( null, __("Connect to WPMU DEV to unlock features for free.", "forminator" ), ), // src/shared/shared-header.js:46
"Documentation" => array( null, __("Documentation", "forminator" ), ), // src/shared/shared-header.js:50
"Unlock Forminator PDF Generator Add-on" => array( null, __("Unlock Forminator PDF Generator Add-on", "forminator" ), ), // src/shared/shared-header.js:70
"Generate and send PDF files (e.g., form entries, receipts, invoices, quotations) to users after form submission." => array( null, __("Generate and send PDF files (e.g., form entries, receipts, invoices, quotations) to users after form submission.", "forminator" ), ), // src/shared/shared-header.js:73
"Create free Account" => array( null, __("Create free Account", "forminator" ), ), // src/shared/shared-header.js:84
"Already have an account?" => array( null, __("Already have an account?", "forminator" ), ), // src/shared/shared-header.js:87
"Connect site" => array( null, __("Connect site", "forminator" ), ), // src/shared/shared-header.js:87
"Plus unlock other WPMU DEV perks and benefits!" => array( null, __("Plus unlock other WPMU DEV perks and benefits!", "forminator" ), ), // src/shared/shared-header.js:90
"WPMU DEV Hub" => array( null, __("WPMU DEV Hub", "forminator" ), ), // src/shared/shared-header.js:94
"Effortlessly  manage unlimited sites from one dashboard." => array( null, __("Effortlessly  manage unlimited sites from one dashboard.", "forminator" ), ), // src/shared/shared-header.js:96
"Auto Updates" => array( null, __("Auto Updates", "forminator" ), ), // src/shared/shared-header.js:101
"Schedule safe updates for all your plugins and themes." => array( null, __("Schedule safe updates for all your plugins and themes.", "forminator" ), ), // src/shared/shared-header.js:103
"Uptime Monitor" => array( null, __("Uptime Monitor", "forminator" ), ), // src/shared/shared-header.js:108
"Instant downtime alerts and helpful site analytics." => array( null, __("Instant downtime alerts and helpful site analytics.", "forminator" ), ), // src/shared/shared-header.js:110
"One Click SSO" => array( null, __("One Click SSO", "forminator" ), ), // src/shared/shared-header.js:115
"Access all your sites from one place with one click." => array( null, __("Access all your sites from one place with one click.", "forminator" ), ), // src/shared/shared-header.js:117
"White Label Reports" => array( null, __("White Label Reports", "forminator" ), ), // src/shared/shared-header.js:122
"Custom website health reports for clients." => array( null, __("Custom website health reports for clients.", "forminator" ), ), // src/shared/shared-header.js:124
"Secure Site Backups" => array( null, __("Secure Site Backups", "forminator" ), ), // src/shared/shared-header.js:129
"Including 1GB free WPMU DEV storage." => array( null, __("Including 1GB free WPMU DEV storage.", "forminator" ), ), // src/shared/shared-header.js:131
"Client Billing" => array( null, __("Client Billing", "forminator" ), ), // src/shared/shared-header.js:136
"A full payment solution for your business." => array( null, __("A full payment solution for your business.", "forminator" ), ), // src/shared/shared-header.js:138
"Many More Benefits" => array( null, __("Many More Benefits", "forminator" ), ), // src/shared/shared-header.js:143
"Many more membership perks and benefits." => array( null, __("Many more membership perks and benefits.", "forminator" ), ), // src/shared/shared-header.js:145
"Inline Message" => array( null, __("Inline Message", "forminator" ), ), // src/utils.js:110
"Redirect user to a URL" => array( null, __("Redirect user to a URL", "forminator" ), ), // src/utils.js:111
"Hide form" => array( null, __("Hide form", "forminator" ), ), // src/utils.js:112
"is" => array( null, __("is", "forminator" ), ), // src/utils.js:1041
"is not" => array( null, __("is not", "forminator" ), ), // src/utils.js:1043
"day is" => array( null, __("day is", "forminator" ), ), // src/utils.js:1045
"day is not" => array( null, __("day is not", "forminator" ), ), // src/utils.js:1047
"month is not" => array( null, __("month is not", "forminator" ), ), // src/utils.js:1049
"month is" => array( null, __("month is", "forminator" ), ), // src/utils.js:1051
"is before" => array( null, __("is before", "forminator" ), ), // src/utils.js:1053
"is after" => array( null, __("is after", "forminator" ), ), // src/utils.js:1055
"is before %s or more days from current date" => array( null, __("is before %s or more days from current date", "forminator" ), ), // src/utils.js:1057
"is before less than %s days from current date" => array( null, __("is before less than %s days from current date", "forminator" ), ), // src/utils.js:1059
"is after %s or more days from current date" => array( null, __("is after %s or more days from current date", "forminator" ), ), // src/utils.js:1061
"is after less than %s days from current date" => array( null, __("is after less than %s days from current date", "forminator" ), ), // src/utils.js:1063
"is greater than" => array( null, __("is greater than", "forminator" ), ), // src/utils.js:1065
"is less than" => array( null, __("is less than", "forminator" ), ), // src/utils.js:1067
"contains" => array( null, __("contains", "forminator" ), ), // src/utils.js:1069
"starts with" => array( null, __("starts with", "forminator" ), ), // src/utils.js:1071
"ends with" => array( null, __("ends with", "forminator" ), ), // src/utils.js:1073
"is correct" => array( null, __("is correct", "forminator" ), ), // src/utils.js:1075
"is incorrect" => array( null, __("is incorrect", "forminator" ), ), // src/utils.js:1077
"is final result" => array( null, __("is final result", "forminator" ), ), // src/utils.js:1080
"is not final result" => array( null, __("is not final result", "forminator" ), ), // src/utils.js:1082
"Please fix the error(s) in the SETTINGS tab." => array( null, __("Please fix the error(s) in the SETTINGS tab.", "forminator" ), ), // src/utils.js:1386
"Billing frequency should be greater than or equal to 1" => array( null, __("Billing frequency should be greater than or equal to 1", "forminator" ), ), // src/utils.js:1431
);
return $forminator_admin_locale;
/* THIS IS THE END OF THE GENERATED FILE */