<?php

/**
 * Class Forminator_Addon_Hooks_Abstract
 */
abstract class Forminator_Addon_Hooks_Abstract {

}
