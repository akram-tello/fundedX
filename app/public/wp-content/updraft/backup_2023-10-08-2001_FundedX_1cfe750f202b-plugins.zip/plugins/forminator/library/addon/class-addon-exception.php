<?php

/**
 * Class Forminator_Addon_Exception
 * Exception used for Addon
 *
 * @since 1.1
 */
class Forminator_Addon_Exception extends Exception {
}
