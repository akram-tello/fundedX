<?php return array('dependencies' => array('wp-polyfill'), 'version' => '254f53596a14e57a4759');
