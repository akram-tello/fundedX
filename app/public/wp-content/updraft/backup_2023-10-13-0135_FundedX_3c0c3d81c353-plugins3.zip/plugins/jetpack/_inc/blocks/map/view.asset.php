<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '49c57943646bbc761c9b');
