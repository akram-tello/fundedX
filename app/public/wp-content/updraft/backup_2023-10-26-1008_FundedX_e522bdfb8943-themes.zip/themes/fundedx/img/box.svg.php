<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="338" height="342.002" viewBox="0 0 338 342.002">
  <defs>
    <filter id="Box" x="0" y="4.002" width="338" height="338" filterUnits="userSpaceOnUse">
      <feOffset dy="3" input="SourceAlpha"/>
      <feGaussianBlur stdDeviation="13" result="blur"/>
      <feFlood flood-opacity="0.161"/>
      <feComposite operator="in" in2="blur"/>
    </filter>
    <filter id="Box-2" x="0" y="4.002" width="338" height="338" filterUnits="userSpaceOnUse">
      <feOffset dy="3" input="SourceAlpha"/>
      <feGaussianBlur stdDeviation="29" result="blur-2"/>
      <feFlood flood-opacity="0.161" result="color"/>
      <feComposite operator="out" in="SourceGraphic" in2="blur-2"/>
      <feComposite operator="in" in="color"/>
      <feComposite operator="in" in2="SourceGraphic"/>
    </filter>
    <filter id="Slash" x="7" y="0" width="207.654" height="318.002" filterUnits="userSpaceOnUse">
      <feOffset dx="7" dy="9" input="SourceAlpha"/>
      <feGaussianBlur stdDeviation="3" result="blur-3"/>
      <feFlood flood-opacity="0.161"/>
      <feComposite operator="in" in2="blur-3"/>
      <feComposite in="SourceGraphic"/>
    </filter>
  </defs>
  <g id="Box-3" data-name="Box" transform="translate(-205 -1191.998)">
    <g data-type="innerShadowGroup">
      <g transform="matrix(1, 0, 0, 1, 205, 1192)" filter="url(#Box)">
        <g id="Box-4" data-name="Box" transform="translate(39 40)" fill="#fff" stroke="#141414" stroke-width="12">
          <rect width="260" height="260" rx="20" stroke="none"/>
          <rect x="6" y="6" width="248" height="248" rx="14" fill="none"/>
        </g>
      </g>
      <rect id="Box-5" data-name="Box" width="260" height="260" rx="20" transform="translate(244 1232)" fill="#fff"/>
      <g transform="matrix(1, 0, 0, 1, 205, 1192)" filter="url(#Box-2)">
        <rect id="Box-6" data-name="Box" width="260" height="260" rx="20" transform="translate(39 40)" fill="#fff"/>
      </g>
      <g id="Box-7" data-name="Box" transform="translate(244 1232)" fill="none" stroke="#141414" stroke-width="12">
        <rect width="260" height="260" rx="20" stroke="none"/>
        <rect x="6" y="6" width="248" height="248" rx="14" fill="none"/>
      </g>
    </g>
    <g transform="matrix(1, 0, 0, 1, 205, 1192)" filter="url(#Slash)">
      <path id="Slash-2" data-name="Slash" d="M15801.465,9919.373h189.654c-16.684,46.764-42.963,105.2-84.057,168.395a840.454,840.454,0,0,1-105.6,131.607Z" transform="translate(-15792.46 -9919.37)" fill="#fff"/>
    </g>
  </g>
</svg>
